package com.sangmin.seoulreturncall;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class FloatingService extends Service {
    private static final String CHANNEL_ID = "floating_quick_controls";
    private static final int NOTIFICATION_ID = 1801;
    private static final int ACCENT = Color.rgb(246, 201, 69);
    // v1.8.1: floating bubble is 70% lighter via 30% opacity.
    private static final int FLOATING_ACCENT = Color.argb(77, 246, 201, 69);
    private static final int PANEL = Color.rgb(25, 28, 34);
    private static final int TEXT = Color.rgb(244, 246, 248);
    private static final int MUTED = Color.rgb(167, 175, 186);

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private LinearLayout overlayRoot;
    private LinearLayout panel;
    private TextView stateText;
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("pricing_adjust", MODE_PRIVATE);
        createNotificationChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("콜지가격 미니 플로팅")
                .setContentText("빠른 모드 전환과 재복사가 켜져 있어")
                .setOngoing(true)
                .build();
        startForeground(NOTIFICATION_ID, notification);
        showOverlay();
        prefs.edit().putBoolean("floating_enabled", true).apply();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlayRoot != null && windowManager != null) {
            try { windowManager.removeView(overlayRoot); } catch (Exception ignored) {}
        }
        prefs.edit().putBoolean("floating_enabled", false).apply();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "미니 플로팅", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("콜지가격 미니 플로팅 유지 알림");
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
    }

    private void showOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = prefs.getInt("floating_x", dp(12));
        params.y = prefs.getInt("floating_y", dp(220));

        overlayRoot = new LinearLayout(this);
        overlayRoot.setOrientation(LinearLayout.VERTICAL);
        overlayRoot.setGravity(Gravity.START);

        // Keep a generous invisible touch target so the visually smaller button is still easy to drag/tap.
        FrameLayout bubbleTouchTarget = new FrameLayout(this);
        overlayRoot.addView(bubbleTouchTarget, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView bubble = new TextView(this);
        bubble.setText("콜");
        bubble.setTextSize(8);
        bubble.setTextColor(Color.argb(190, 0, 0, 0));
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(circle(FLOATING_ACCENT));
        FrameLayout.LayoutParams bubbleLp = new FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER);
        bubbleTouchTarget.addView(bubble, bubbleLp);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(8), dp(8), dp(8));
        panel.setBackground(rounded(PANEL, 14));
        panel.setVisibility(View.GONE);
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(dp(168), WindowManager.LayoutParams.WRAP_CONTENT);
        panelLp.topMargin = dp(6);
        overlayRoot.addView(panel, panelLp);

        stateText = new TextView(this);
        stateText.setTextSize(11);
        stateText.setTextColor(ACCENT);
        stateText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stateText.setPadding(dp(4), dp(2), dp(4), dp(6));
        panel.addView(stateText, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        Button ret = miniButton("복귀");
        Button run = miniButton("달려");
        Button happy = miniButton("해피");
        modeRow.addView(ret, weightButtonLp());
        LinearLayout.LayoutParams middle = weightButtonLp(); middle.leftMargin = dp(3); middle.rightMargin = dp(3);
        modeRow.addView(run, middle);
        modeRow.addView(happy, weightButtonLp());
        panel.addView(modeRow, new LinearLayout.LayoutParams(-1, dp(38)));

        Button time = miniButton("시간대 전환");
        Button recopy = miniButton("마지막 가격표 재복사");
        Button gps = miniButton("GPS 재계산");
        Button open = miniButton("앱 열기");
        Button close = miniButton("플로팅 닫기");
        addPanelButton(time); addPanelButton(recopy); addPanelButton(gps); addPanelButton(open); addPanelButton(close);

        ret.setOnClickListener(v -> setMode("return"));
        run.setOnClickListener(v -> setMode("run"));
        happy.setOnClickListener(v -> setMode("happy"));
        time.setOnClickListener(v -> cyclePreset());
        recopy.setOnClickListener(v -> recopyLast());
        gps.setOnClickListener(v -> openMain(true));
        open.setOnClickListener(v -> openMain(false));
        close.setOnClickListener(v -> stopSelf());

        bubbleTouchTarget.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x; startY = params.y;
                        downX = event.getRawX(); downY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downX);
                        int dy = (int) (event.getRawY() - downY);
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        params.x = Math.max(0, startX + dx);
                        params.y = Math.max(0, startY + dy);
                        try { windowManager.updateViewLayout(overlayRoot, params); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        prefs.edit().putInt("floating_x", params.x).putInt("floating_y", params.y).apply();
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });

        refreshState();
        windowManager.addView(overlayRoot, params);
    }

    private void togglePanel() {
        if (panel.getVisibility() == View.VISIBLE) panel.setVisibility(View.GONE);
        else {
            refreshState();
            panel.setVisibility(View.VISIBLE);
        }
        try { windowManager.updateViewLayout(overlayRoot, params); } catch (Exception ignored) {}
    }

    private void setMode(String mode) {
        prefs.edit().putString("currentMode", mode).apply();
        refreshState();
        Toast.makeText(this, modeName(mode) + " 적용", Toast.LENGTH_SHORT).show();
    }

    private void cyclePreset() {
        String current = prefs.getString("currentPreset", "weekday");
        String next;
        if ("weekday".equals(current)) next = "frisat";
        else if ("frisat".equals(current)) next = "latenight";
        else if ("latenight".equals(current)) next = "dawn";
        else next = "weekday";
        prefs.edit().putString("currentPreset", next).apply();
        refreshState();
        Toast.makeText(this, presetName(next) + " 프리셋 적용", Toast.LENGTH_SHORT).show();
    }

    private void recopyLast() {
        String value = prefs.getString("lastCopiedValue", "");
        String label = prefs.getString("lastCopiedLabel", "최근 가격표");
        if (value.isEmpty()) {
            Toast.makeText(this, "아직 복사한 가격표가 없어", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
        recordRecent(label, value);
        Toast.makeText(this, label + " 재복사 완료", Toast.LENGTH_SHORT).show();
    }

    private void recordRecent(String label, String value) {
        try {
            JSONArray old = new JSONArray(prefs.getString("recent_usage_json", "[]"));
            JSONArray next = new JSONArray();
            JSONObject item = new JSONObject();
            item.put("time", System.currentTimeMillis());
            item.put("label", label);
            item.put("value", value);
            String modeId = prefs.getString("currentMode", "run");
            String presetId = prefs.getString("currentPreset", "weekday");
            item.put("mode", modeName(modeId));
            item.put("modeId", modeId);
            item.put("modeK", modeDelta(modeId));
            item.put("preset", presetName(presetId));
            item.put("presetId", presetId);
            item.put("presetK", presetDelta(presetId));
            item.put("cardDelta", prefs.getInt("section_delta_" + label, 0));
            next.put(item);
            for (int i = 0; i < old.length() && next.length() < 20; i++) next.put(old.getJSONObject(i));
            prefs.edit().putString("recent_usage_json", next.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void openMain(boolean refreshGps) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (refreshGps) intent.putExtra("refreshGps", true);
        startActivity(intent);
        panel.setVisibility(View.GONE);
    }

    private void refreshState() {
        if (stateText == null) return;
        String mode = prefs.getString("currentMode", "run");
        String preset = prefs.getString("currentPreset", "weekday");
        stateText.setText(modeName(mode) + " · " + presetName(preset));
    }


    private int modeDelta(String mode) {
        if ("return".equals(mode)) return prefs.getInt("returnK", -5);
        if ("happy".equals(mode)) return prefs.getInt("happyK", 5);
        return prefs.getInt("runK", 0);
    }

    private int presetDelta(String preset) {
        if ("frisat".equals(preset)) return prefs.getInt("preset_frisatK", 2);
        if ("latenight".equals(preset)) return prefs.getInt("preset_latenightK", 3);
        if ("dawn".equals(preset)) return prefs.getInt("preset_dawnK", 1);
        return prefs.getInt("preset_weekdayK", 0);
    }

    private String modeName(String mode) {
        if ("return".equals(mode)) return "복귀콜";
        if ("happy".equals(mode)) return "해피타임";
        return "달려콜";
    }

    private String presetName(String preset) {
        if ("frisat".equals(preset)) return "금토";
        if ("latenight".equals(preset)) return "심야";
        if ("dawn".equals(preset)) return "새벽";
        return "평일";
    }

    private Button miniButton(String text) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(10);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setMinWidth(0);
        b.setBackground(rounded(Color.rgb(42, 47, 56), 10));
        return b;
    }

    private void addPanelButton(Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(38));
        lp.topMargin = dp(4);
        panel.addView(b, lp);
    }

    private LinearLayout.LayoutParams weightButtonLp() {
        return new LinearLayout.LayoutParams(0, dp(38), 1f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
