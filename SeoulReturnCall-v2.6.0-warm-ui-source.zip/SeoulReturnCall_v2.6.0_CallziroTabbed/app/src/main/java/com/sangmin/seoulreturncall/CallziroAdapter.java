package com.sangmin.seoulreturncall;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;

/**
 * 콜지로 연동 전용 계층.
 *
 * MainActivity가 콜지로 서버 주소/응답 필드에 직접 의존하지 않도록 네트워크 요청과
 * 응답 파싱을 이 파일에 모았다. 서버 경로나 JSON 형식이 바뀌면 우선 이 클래스만
 * 수정하는 것을 목표로 한다. 카카오톡 로그인/인증 우회 로직은 포함하지 않는다.
 */
class CallziroAdapter {
    private static final String API_BASE = "https://calljiro.mycafe24.com/api";
    private static final String USER_AGENT = "SeoulReturnCall/2.6.0 Callziro-Adapter";

    ArrayList<Point> fetchNearby(double fromLat, double fromLon, int distanceKm) throws AdapterException {
        HttpURLConnection con = null;
        try {
            String url = API_BASE + "/map/list?wr_lat="
                    + URLEncoder.encode(String.format(Locale.US, "%.7f", fromLat), "UTF-8")
                    + "&wr_lng=" + URLEncoder.encode(String.format(Locale.US, "%.7f", fromLon), "UTF-8")
                    + "&distance=" + distanceKm;
            con = open(url);
            int code = con.getResponseCode();
            String body = readBody(con, code);
            ensureSuccess(code, body);
            return parsePoints(body, fromLat, fromLon);
        } catch (AdapterException e) {
            throw e;
        } catch (Exception e) {
            throw new AdapterException(messageOf(e), -1, false, e);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    ArrayList<Notice> fetchNotices() throws AdapterException {
        HttpURLConnection con = null;
        try {
            con = open(API_BASE + "/board/list?bo_table=notice");
            int code = con.getResponseCode();
            String body = readBody(con, code);
            ensureSuccess(code, body);
            return parseNotices(body);
        } catch (AdapterException e) {
            throw e;
        } catch (Exception e) {
            throw new AdapterException(messageOf(e), -1, false, e);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private HttpURLConnection open(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setRequestMethod("GET");
        con.setConnectTimeout(8000);
        con.setReadTimeout(10000);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", USER_AGENT);
        return con;
    }

    private void ensureSuccess(int code, String body) throws AdapterException {
        if (code == 401 || code == 403) {
            throw new AdapterException("인증 필요", code, true, null);
        }
        if (code < 200 || code >= 300) {
            String suffix = body == null || body.trim().isEmpty() ? "" : " · " + compact(body, 120);
            throw new AdapterException("HTTP " + code + suffix, code, false, null);
        }
    }

    private String readBody(HttpURLConnection con, int code) throws Exception {
        InputStream in = (code >= 200 && code < 300) ? con.getInputStream() : con.getErrorStream();
        if (in == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private ArrayList<Point> parsePoints(String body, double fromLat, double fromLon) throws Exception {
        ArrayList<JSONObject> objects = new ArrayList<>();
        String t = body == null ? "" : body.trim();
        if (t.startsWith("[")) collectPointObjects(new JSONArray(t), objects, 0);
        else if (t.startsWith("{")) collectPointObjects(new JSONObject(t), objects, 0);
        else return new ArrayList<>();

        LinkedHashMap<String, Point> unique = new LinkedHashMap<>();
        for (JSONObject o : objects) {
            double lat = flexibleDouble(o.opt("wr_lat"));
            double lon = flexibleDouble(o.opt("wr_lng"));
            if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) continue;

            String id = clean(o.optString("wr_id", ""));
            String name = clean(o.optString("wr_call_name", ""));
            String subject = clean(o.optString("wr_subject", ""));
            if (name.isEmpty()) name = subject.isEmpty() ? "콜밭" : subject;

            String addr = clean(o.optString("wr_addr", ""));
            String jibun = clean(o.optString("wr_jibun", ""));
            String sido = clean(o.optString("wr_sido", ""));
            String sigungu = clean(o.optString("wr_sigungu", ""));
            String station = clean(o.optString("wr_station", ""));
            String stationLine = clean(o.optString("wr_station_line", ""));
            String rank = clean(o.optString("wr_rank", ""));
            String spot = clean(o.optString("wr_spot", ""));
            String price = clean(o.optString("wr_price", ""));
            String frequency = clean(o.optString("wr_frequency", ""));
            String callTime = clean(o.optString("wr_call_time", ""));
            String callType = clean(o.optString("wr_call_type", ""));
            String competition = clean(o.optString("wr_competition", ""));
            String main = clean(o.optString("wr_main", ""));
            String size = clean(o.optString("wr_size", ""));
            String content = stripSimpleHtml(o.optString("wr_content", ""));
            double roadKm = haversineKm(fromLat, fromLon, lat, lon) * 1.18;

            String key = !id.isEmpty() ? "id:" + id : name + "|" + String.format(Locale.US, "%.5f|%.5f", lat, lon);
            unique.put(key, new Point(id, name, lat, lon, addr, jibun, sido, sigungu, station, stationLine,
                    rank, spot, price, frequency, callTime, callType, competition, main, size, subject, content, roadKm));
        }
        return new ArrayList<>(unique.values());
    }

    private ArrayList<Notice> parseNotices(String body) throws Exception {
        ArrayList<JSONObject> objects = new ArrayList<>();
        String t = body == null ? "" : body.trim();
        if (t.startsWith("[")) collectNoticeObjects(new JSONArray(t), objects, 0);
        else if (t.startsWith("{")) collectNoticeObjects(new JSONObject(t), objects, 0);

        ArrayList<Notice> out = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        for (JSONObject o : objects) {
            String id = clean(o.optString("wr_id", o.optString("wr_num", "")));
            String subject = clean(o.optString("wr_subject", o.optString("subject", "")));
            if (subject.isEmpty()) continue;
            String content = stripSimpleHtml(o.optString("wr_content", o.optString("content", "")));
            String date = clean(o.optString("wr_datetime", o.optString("datetime", "")));
            String key = id.isEmpty() ? subject : id;
            if (seen.add(key)) out.add(new Notice(id, subject, content, date));
        }
        return out;
    }

    private void collectPointObjects(Object node, ArrayList<JSONObject> out, int depth) {
        if (node == null || depth > 8) return;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if (o.has("wr_lat") && o.has("wr_lng")
                    && (o.has("wr_call_name") || o.has("wr_addr") || o.has("wr_jibun") || o.has("wr_subject"))) {
                out.add(o);
            }
            JSONArray names = o.names();
            if (names == null) return;
            for (int i = 0; i < names.length(); i++) {
                Object v = o.opt(names.optString(i, ""));
                if (v instanceof JSONObject || v instanceof JSONArray) collectPointObjects(v, out, depth + 1);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                Object v = a.opt(i);
                if (v instanceof JSONObject || v instanceof JSONArray) collectPointObjects(v, out, depth + 1);
            }
        }
    }

    private void collectNoticeObjects(Object node, ArrayList<JSONObject> out, int depth) {
        if (node == null || depth > 8) return;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if (o.has("wr_subject") || o.has("subject")) out.add(o);
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    Object v = o.opt(names.optString(i, ""));
                    if (v instanceof JSONObject || v instanceof JSONArray) collectNoticeObjects(v, out, depth + 1);
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                Object v = a.opt(i);
                if (v instanceof JSONObject || v instanceof JSONArray) collectNoticeObjects(v, out, depth + 1);
            }
        }
    }

    private double flexibleDouble(Object v) {
        if (v == null || v == JSONObject.NULL) return Double.NaN;
        if (v instanceof Number) return ((Number) v).doubleValue();
        try { return Double.parseDouble(String.valueOf(v).trim()); }
        catch (Exception e) { return Double.NaN; }
    }

    private String stripSimpleHtml(String s) {
        if (s == null) return "";
        return s.replaceAll("(?is)<br\\s*/?>", "\n")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replaceAll("[ \\t]+", " ").replaceAll("\n{3,}", "\n\n").trim();
    }

    private String clean(String s) { return s == null ? "" : s.trim(); }

    private String compact(String s, int max) {
        String one = s.replace('\n', ' ').replace('\r', ' ').trim();
        return one.length() <= max ? one : one.substring(0, max) + "…";
    }

    private String messageOf(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0088;
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1);
        double dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    static class AdapterException extends Exception {
        final int httpCode;
        final boolean authRequired;

        AdapterException(String message, int httpCode, boolean authRequired, Throwable cause) {
            super(message, cause);
            this.httpCode = httpCode;
            this.authRequired = authRequired;
        }
    }

    static class Notice {
        final String id, subject, content, date;
        Notice(String id, String subject, String content, String date) {
            this.id = id;
            this.subject = subject;
            this.content = content;
            this.date = date;
        }
    }

    static class Point {
        final String id, name, addr, jibun, sido, sigungu, station, stationLine;
        final String rank, spot, price, frequency, callTime, callType, competition, main, size, subject, content;
        final double lat, lon, roadKm;

        Point(String id, String name, double lat, double lon, String addr, String jibun,
              String sido, String sigungu, String station, String stationLine,
              String rank, String spot, String price, String frequency, String callTime, String callType,
              String competition, String main, String size, String subject, String content, double roadKm) {
            this.id = id;
            this.name = name;
            this.lat = lat;
            this.lon = lon;
            this.addr = addr;
            this.jibun = jibun;
            this.sido = sido;
            this.sigungu = sigungu;
            this.station = station;
            this.stationLine = stationLine;
            this.rank = rank;
            this.spot = spot;
            this.price = price;
            this.frequency = frequency;
            this.callTime = callTime;
            this.callType = callType;
            this.competition = competition;
            this.main = main;
            this.size = size;
            this.subject = subject;
            this.content = content;
            this.roadKm = roadKm;
        }
    }
}
