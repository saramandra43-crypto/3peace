package com.sangmin.seoulreturncall;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_BACKUP_CREATE = 2001;
    private static final int REQ_BACKUP_OPEN = 2002;
    private static final double REF_LAT = 37.5689;
    private static final double REF_LON = 126.8408;
    private static final double ROAD_FACTOR = 1.22;
    private static final double WON_PER_KM_DELTA = 700.0;

    // Warm minimal palette: ivory background, clean cards, deep blue-green text.
    private static final int BG = Color.rgb(255, 249, 240);
    private static final int CARD = Color.rgb(255, 255, 255);
    private static final int TEXT = Color.rgb(36, 49, 58);
    private static final int MUTED = Color.rgb(118, 126, 130);
    private static final int ACCENT = Color.rgb(244, 185, 66);
    private static final int SOFT = Color.rgb(247, 238, 220);
    private static final int BORDER = Color.rgb(235, 225, 207);

    private double currentLat = REF_LAT;
    private double currentLon = REF_LON;
    private String currentMode = "run";
    private int returnDeltaK = -5;
    private int runDeltaK = 0;
    private int happyDeltaK = 5;
    private int modeDeltaK = 0;

    // 시간대 프리셋 보정(천원 단위)
    private String currentPreset = "weekday";
    private int weekdayPresetK = 0;
    private int friSatPresetK = 2;
    private int lateNightPresetK = 3;
    private int dawnPresetK = 1;
    private int presetDeltaK = 0;
    private SharedPreferences prefs;
    private SharedPreferences apiPrefs;
    private EditText nationwideQueryInput;
    private TextView nationwideApiStateText;
    private LinearLayout favoritesContainer;
    private TextView favoritesHeader;
    private LinearLayout recentPreviewContainer;
    private Button floatingToggleButton;
    private boolean overlayRequestPending = false;

    private TextView locationText;
    private TextView callziroLocationText;
    private Button homePriceTabButton;
    private Button homeCallziroTabButton;
    private View homePricePage;
    private View homeCallziroPage;
    private TextView modeStateText;
    private Button returnButton;
    private Button runButton;
    private Button happyButton;
    private TextView returnDeltaText;
    private TextView runDeltaText;
    private TextView happyDeltaText;

    private Button weekdayPresetButton;
    private Button friSatPresetButton;
    private Button lateNightPresetButton;
    private Button dawnPresetButton;
    private TextView presetStateText;
    private TextView presetAdjustValueText;

    private final Map<String, Section> sections = new LinkedHashMap<>();
    // v2.3: 공개자료 기반 서울·수도권 콜포인트 시드 DB(116개)를 앱 내부 assets에서 로드
    private final ArrayList<SeedCallpoint> seedCallpoints = new ArrayList<>();

    // v2.6: 콜지로 담당자 허락 범위(카카오톡 로그인 제외) 안에서 콜밭/공지/상세 기능을 통합.
    // 앱 화면에 "콜지로와 공유한다" 문구를 고정 표기한다.
    private CallziroAdapter callziroAdapter;
    private int callziroDistanceKm = 20;
    private final ArrayList<CallziroAdapter.Point> callziroPoints = new ArrayList<>();
    private final ArrayList<CallziroAdapter.Notice> callziroNotices = new ArrayList<>();
    private TextView callziroStateText;
    private TextView callziroCountText;

    private final Target[] seoulTargets = new Target[] {
        // 강서
        t("마곡",37.5509,126.8495,22), t("발산",37.5509,126.8495,22), t("가양",37.5509,126.8495,22),
        t("등촌",37.5509,126.8495,22), t("화곡",37.5509,126.8495,23), t("염창",37.5509,126.8495,23), t("방화",37.5509,126.8495,24),
        // 양천
        t("목동",37.5169,126.8665,22), t("신정",37.5169,126.8665,23), t("신월",37.5169,126.8665,24),
        // 마포
        t("상암",37.5663,126.9018,22), t("성산",37.5663,126.9018,23), t("망원",37.5663,126.9018,23), t("합정",37.5663,126.9018,23),
        t("서교",37.5663,126.9018,24), t("공덕",37.5663,126.9018,25), t("도화",37.5663,126.9018,25),
        // 영등포
        t("양평",37.5264,126.8963,23), t("당산",37.5264,126.8963,23), t("문래",37.5264,126.8963,24), t("영등포",37.5264,126.8963,24),
        t("신길",37.5264,126.8963,25), t("대림",37.5264,126.8963,26), t("여의도",37.5264,126.8963,27),
        // 서대문
        t("북가좌",37.5791,126.9368,26), t("남가좌",37.5791,126.9368,26), t("연희",37.5791,126.9368,27), t("신촌",37.5791,126.9368,29), t("충정로",37.5791,126.9368,30),
        // 동작
        t("노량진",37.5124,126.9393,28), t("대방",37.5124,126.9393,28), t("신대방",37.5124,126.9393,29), t("상도",37.5124,126.9393,29), t("흑석",37.5124,126.9393,30), t("사당",37.5124,126.9393,31),
        // 종로
        t("종로",37.5735,126.9790,30), t("혜화",37.5735,126.9790,32),
        // 용산
        t("원효로",37.5326,126.9905,31), t("용산",37.5326,126.9905,33), t("이촌",37.5326,126.9905,34), t("한남",37.5326,126.9905,35),
        // 중구
        t("충무로",37.5636,126.9976,34), t("을지로",37.5636,126.9976,34), t("신당",37.5636,126.9976,35), t("약수",37.5636,126.9976,35),
        // 성동
        t("금호",37.5633,127.0368,36), t("옥수",37.5633,127.0368,36), t("왕십리",37.5633,127.0368,37), t("행당",37.5633,127.0368,37), t("성수",37.5633,127.0368,39), t("서울숲",37.5633,127.0368,39),
        // 동대문
        t("신설",37.5744,127.0396,37), t("청량리",37.5744,127.0396,39), t("답십리",37.5744,127.0396,40), t("장안",37.5744,127.0396,41),
        // 강남
        t("논현",37.5172,127.0473,39), t("강남신사",37.5172,127.0473,39), t("역삼",37.5172,127.0473,40), t("압구정",37.5172,127.0473,40),
        t("청담",37.5172,127.0473,41), t("삼성",37.5172,127.0473,41), t("대치",37.5172,127.0473,42), t("도곡",37.5172,127.0473,42),
        // 서초
        t("반포",37.4837,127.0324,38), t("잠원",37.4837,127.0324,39), t("서초",37.4837,127.0324,40), t("방배",37.4837,127.0324,40), t("양재",37.4837,127.0324,42),
        // 광진
        t("자양",37.5385,127.0823,42), t("구의",37.5385,127.0823,43), t("화양",37.5385,127.0823,44), t("군자",37.5385,127.0823,45),
        // 송파
        t("잠실",37.5145,127.1059,46), t("신천",37.5145,127.1059,47), t("삼전",37.5145,127.1059,47), t("석촌",37.5145,127.1059,48),
        t("송파",37.5145,127.1059,48), t("가락",37.5145,127.1059,49), t("문정",37.5145,127.1059,50), t("방이",37.5145,127.1059,50), t("오금",37.5145,127.1059,51),
        // 강동
        t("천호",37.5301,127.1238,49), t("성내",37.5301,127.1238,49), t("암사",37.5301,127.1238,50), t("길동",37.5301,127.1238,51),
        t("둔촌",37.5301,127.1238,52), t("명일",37.5301,127.1238,52), t("고덕",37.5301,127.1238,54)
    };

    private final Target[] metroTargets = new Target[] {
        t("인천",37.4563,126.7052,32), t("김포",37.6152,126.7156,28), t("고양",37.6584,126.8320,30), t("파주",37.7599,126.7800,38),
        t("양주",37.7853,127.0458,48), t("의정부",37.7381,127.0337,45), t("남양주",37.6360,127.2165,52), t("구리",37.5943,127.1296,44),
        t("광주",37.4095,127.2550,55), t("하남",37.5393,127.2148,48), t("이천",37.2720,127.4350,70), t("안성",37.0080,127.2790,75),
        t("평택",36.9921,127.1129,70), t("화성",37.1995,126.8312,58), t("오산",37.1498,127.0772,58), t("의왕",37.3447,126.9683,43),
        t("군포",37.3617,126.9352,42), t("과천",37.4292,126.9876,38), t("시흥",37.3802,126.8029,36), t("광명",37.4786,126.8644,28), t("부천",37.5034,126.7660,25)
    };

    private final Target[] suwonBundleTargets = new Target[] {
        // 수원
        t("구운",37.2636,127.0286,45), t("서둔",37.2636,127.0286,46), t("화서",37.2636,127.0286,46), t("매산",37.2636,127.0286,46),
        t("매교",37.2636,127.0286,47), t("세류",37.2636,127.0286,47), t("권선",37.2636,127.0286,48), t("인계",37.2636,127.0286,48),
        t("우만",37.2636,127.0286,48), t("지동",37.2636,127.0286,48), t("매탄",37.2636,127.0286,49), t("망포",37.2636,127.0286,50),
        t("영통",37.2636,127.0286,50), t("원천",37.2636,127.0286,50), t("광교",37.2636,127.0286,52), t("호매실",37.2636,127.0286,50), t("금곡",37.2636,127.0286,50),
        // 분당
        t("야탑",37.3828,127.1189,50), t("이매",37.3828,127.1189,51), t("서현",37.3828,127.1189,52), t("수내",37.3828,127.1189,52),
        t("정자",37.3828,127.1189,53), t("판교",37.3828,127.1189,52), t("백현",37.3828,127.1189,52), t("삼평",37.3828,127.1189,52),
        t("미금",37.3828,127.1189,54), t("구미",37.3828,127.1189,54), t("오리",37.3828,127.1189,55),
        // 용인 수지권
        t("수지",37.3222,127.0976,55), t("풍덕천",37.3222,127.0976,55), t("성복",37.3222,127.0976,56), t("상현",37.3222,127.0976,56), t("죽전",37.3222,127.0976,57),
        // 용인 기흥권
        t("보정",37.2740,127.1158,57), t("구성",37.2740,127.1158,58), t("마북",37.2740,127.1158,58), t("신갈",37.2740,127.1158,58),
        t("구갈",37.2740,127.1158,59), t("상갈",37.2740,127.1158,59), t("기흥",37.2740,127.1158,59), t("동백",37.2740,127.1158,61),
        t("중동",37.2740,127.1158,61), t("서천",37.2740,127.1158,60), t("흥덕",37.2740,127.1158,60),
        // 용인 처인권 주요지만
        t("역북",37.2342,127.2013,64), t("김량장",37.2342,127.2013,65), t("삼가",37.2342,127.2013,64)
    };

    private final Target[] anyangBundleTargets = new Target[] {
        // 안양
        t("안양",37.3943,126.9568,38), t("명학",37.3943,126.9568,39), t("비산",37.3943,126.9568,39), t("관양",37.3943,126.9568,40),
        t("인덕원",37.3943,126.9568,40), t("평촌",37.3943,126.9568,40), t("범계",37.3943,126.9568,40), t("호계",37.3943,126.9568,41),
        t("석수",37.3943,126.9568,39), t("박달",37.3943,126.9568,40),
        // 안산
        t("고잔",37.3219,126.8309,44), t("중앙",37.3219,126.8309,44), t("초지",37.3219,126.8309,45), t("선부",37.3219,126.8309,45),
        t("와동",37.3219,126.8309,46), t("월피",37.3219,126.8309,46), t("성포",37.3219,126.8309,45), t("사동",37.3219,126.8309,46),
        t("본오",37.3219,126.8309,47), t("상록수",37.3219,126.8309,47)
    };

    private final Target[] chungcheongTargets = new Target[] {
        t("천안",36.8151,127.1139,85), t("아산",36.7898,127.0018,90), t("진천",36.8554,127.4356,95),
        t("청주",36.6424,127.4890,100), t("세종",36.4800,127.2890,110), t("대전",36.3504,127.3845,120)
    };

    private final Target[] gangwonTargets = new Target[] {
        t("춘천",37.8813,127.7298,95), t("원주",37.3422,127.9202,105), t("홍천",37.6972,127.8886,110),
        t("횡성",37.4917,127.9850,115), t("평창",37.3705,128.3903,135), t("강릉",37.7519,128.8761,155), t("속초",38.2070,128.5918,160)
    };


    // 세부 지역: 기존 권역표는 그대로 두고 앱별로 필요한 지역만 따로 복사할 수 있게 분리
    private final Target[] seoulGuTargets = new Target[] {
        t("강서",37.5509,126.8495,23), t("양천",37.5169,126.8665,23), t("마포",37.5663,126.9018,23),
        t("영등포",37.5264,126.8963,24), t("서대문",37.5791,126.9368,28), t("은평",37.6027,126.9291,28),
        t("동작",37.5124,126.9393,29), t("종로",37.5735,126.9790,30), t("용산",37.5326,126.9905,33),
        t("중구",37.5636,126.9976,34), t("성동",37.5633,127.0368,38), t("동대문",37.5744,127.0396,39),
        t("강남",37.5172,127.0473,40), t("서초",37.4837,127.0324,40), t("광진",37.5385,127.0823,44),
        t("중랑",37.6063,127.0927,46), t("송파",37.5145,127.1059,49), t("강동",37.5301,127.1238,51)
    };

    private final Target[] gimpoTargets = new Target[] {
        t("고촌",37.6030,126.7705,27), t("풍무",37.6060,126.7240,28), t("사우",37.6200,126.7200,29),
        t("걸포",37.6320,126.7040,29), t("운양",37.6530,126.6840,30), t("장기",37.6440,126.6700,30),
        t("구래",37.6450,126.6290,32), t("마산",37.6400,126.6450,32)
    };

    private final Target[] goyangPajuTargets = new Target[] {
        t("능곡",37.6200,126.8200,28), t("행신",37.6150,126.8340,29), t("화정",37.6350,126.8320,30),
        t("원흥",37.6500,126.8750,31), t("삼송",37.6530,126.8950,31), t("백석",37.6430,126.7870,32),
        t("마두",37.6530,126.7770,32), t("정발산",37.6600,126.7730,33), t("주엽",37.6700,126.7580,33),
        t("대화",37.6750,126.7470,34), t("야당",37.7120,126.7610,36), t("운정",37.7150,126.7440,36),
        t("금촌",37.7590,126.7730,39)
    };

    private final Target[] incheonBucheonTargets = new Target[] {
        t("부천",37.5034,126.7660,25), t("중동",37.5010,126.7750,25), t("상동",37.5050,126.7530,26),
        t("송내",37.4870,126.7540,26), t("역곡",37.4850,126.8110,26), t("부평",37.4930,126.7240,31),
        t("구월",37.4490,126.7020,32), t("주안",37.4630,126.6800,32), t("간석",37.4670,126.7070,32),
        t("계산",37.5430,126.7280,33), t("작전",37.5300,126.7220,33), t("청라",37.5330,126.6450,34),
        t("송도",37.3820,126.6560,36)
    };

    private final Target[] anyangTargets = new Target[] {
        t("안양",37.3943,126.9568,38), t("명학",37.3943,126.9568,39), t("비산",37.3943,126.9568,39),
        t("석수",37.3943,126.9568,39), t("박달",37.3943,126.9568,40), t("관양",37.3943,126.9568,40),
        t("인덕원",37.3943,126.9568,40), t("평촌",37.3943,126.9568,40), t("범계",37.3943,126.9568,40),
        t("호계",37.3943,126.9568,41)
    };

    private final Target[] ansanTargets = new Target[] {
        t("고잔",37.3219,126.8309,44), t("중앙",37.3219,126.8309,44), t("초지",37.3219,126.8309,45),
        t("선부",37.3219,126.8309,45), t("성포",37.3219,126.8309,45), t("와동",37.3219,126.8309,46),
        t("월피",37.3219,126.8309,46), t("사동",37.3219,126.8309,46), t("본오",37.3219,126.8309,47),
        t("상록수",37.3219,126.8309,47)
    };

    private final Target[] suwonTargets = new Target[] {
        t("구운",37.2636,127.0286,45), t("서둔",37.2636,127.0286,46), t("화서",37.2636,127.0286,46),
        t("매산",37.2636,127.0286,46), t("매교",37.2636,127.0286,47), t("세류",37.2636,127.0286,47),
        t("권선",37.2636,127.0286,48), t("인계",37.2636,127.0286,48), t("우만",37.2636,127.0286,48),
        t("지동",37.2636,127.0286,48), t("매탄",37.2636,127.0286,49), t("망포",37.2636,127.0286,50),
        t("영통",37.2636,127.0286,50), t("원천",37.2636,127.0286,50), t("호매실",37.2636,127.0286,50),
        t("금곡",37.2636,127.0286,50), t("광교",37.2636,127.0286,52)
    };

    private final Target[] seongnamTargets = new Target[] {
        t("모란",37.4310,127.1290,48), t("수진",37.4370,127.1290,49), t("신흥",37.4400,127.1450,49),
        t("태평",37.4400,127.1270,49), t("단대",37.4500,127.1550,50), t("하대원",37.4280,127.1480,50),
        t("상대원",37.4330,127.1640,50)
    };

    private final Target[] bundangTargets = new Target[] {
        t("야탑",37.3828,127.1189,50), t("이매",37.3828,127.1189,51), t("서현",37.3828,127.1189,52),
        t("수내",37.3828,127.1189,52), t("판교",37.3828,127.1189,52), t("백현",37.3828,127.1189,52),
        t("삼평",37.3828,127.1189,52), t("정자",37.3828,127.1189,53), t("미금",37.3828,127.1189,54),
        t("구미",37.3828,127.1189,54), t("오리",37.3828,127.1189,55)
    };

    private final Target[] yonginTargets = new Target[] {
        t("수지",37.3222,127.0976,55), t("풍덕천",37.3222,127.0976,55), t("성복",37.3222,127.0976,56),
        t("상현",37.3222,127.0976,56), t("죽전",37.3222,127.0976,57), t("보정",37.2740,127.1158,57),
        t("구성",37.2740,127.1158,58), t("마북",37.2740,127.1158,58), t("신갈",37.2740,127.1158,58),
        t("구갈",37.2740,127.1158,59), t("상갈",37.2740,127.1158,59), t("기흥",37.2740,127.1158,59),
        t("서천",37.2740,127.1158,60), t("흥덕",37.2740,127.1158,60), t("동백",37.2740,127.1158,61),
        t("중동",37.2740,127.1158,61), t("역북",37.2342,127.2013,64), t("삼가",37.2342,127.2013,64),
        t("김량장",37.2342,127.2013,65)
    };

    private final Target[] namyangjuGuriTargets = new Target[] {
        t("구리",37.5943,127.1296,44), t("갈매",37.6340,127.1180,45), t("다산",37.6260,127.1550,48),
        t("별내",37.6500,127.1160,50), t("평내",37.6480,127.2380,53), t("호평",37.6540,127.2440,53),
        t("진접",37.7260,127.1900,55)
    };

    private final Target[] hanamGwangjuTargets = new Target[] {
        t("미사",37.5600,127.1900,48), t("덕풍",37.5520,127.2040,49), t("신장",37.5380,127.2050,49),
        t("감일",37.5080,127.1620,50), t("광주",37.4095,127.2550,55), t("경안",37.4100,127.2580,55),
        t("태전",37.3890,127.2290,56), t("오포",37.3660,127.2280,56)
    };

    private final Target[] uijeongbuYangjuTargets = new Target[] {
        t("의정부",37.7381,127.0337,45), t("가능",37.7480,127.0420,46), t("호원",37.7100,127.0470,46),
        t("민락",37.7450,127.0950,47), t("신곡",37.7310,127.0570,47), t("양주",37.7853,127.0458,48),
        t("옥정",37.8200,127.0940,50), t("덕정",37.8430,127.0610,51)
    };

    private final Target[] pyeongtaekAnseongTargets = new Target[] {
        t("평택",36.9921,127.1129,70), t("비전",36.9900,127.1030,70), t("소사벌",36.9950,127.1210,71),
        t("공도",36.9980,127.1720,72), t("고덕",37.0430,127.0490,72), t("송탄",37.0810,127.0550,72),
        t("안중",36.9860,126.9310,74), t("안성",37.0080,127.2790,75)
    };

    private final Target[] hwaseongOsanTargets = new Target[] {
        t("병점",37.2060,127.0340,55), t("동탄",37.2000,127.0720,56), t("반월",37.2240,127.0600,56),
        t("봉담",37.2200,126.9490,58), t("오산",37.1498,127.0772,58), t("세교",37.1810,127.0440,59),
        t("향남",37.1320,126.9200,60)
    };


    // 도착 후 추천 콜포인트: 실시간 호출량이 아니라 거리 + 고정 매력도 기반 참고용 후보
    private final Hotspot[] hotspots = new Hotspot[] {
        // 서울 서부/도심
        h("발산역",37.5586,126.8377,5,"장거리·서울복귀"),
        h("마곡나루역",37.5668,126.8274,5,"장거리·공항권"),
        h("등촌역",37.5507,126.8656,4,"중거리·서울권"),
        h("목동역",37.5261,126.8643,4,"중거리·서울권"),
        h("홍대입구역",37.5572,126.9254,5,"콜밀집·장거리"),
        h("합정역",37.5495,126.9137,5,"콜밀집·장거리"),
        h("공덕역",37.5440,126.9516,4,"도심·서울복귀"),
        h("여의도역",37.5216,126.9243,5,"업무·장거리"),
        h("영등포역",37.5155,126.9076,5,"콜밀집·장거리"),
        h("용산역",37.5299,126.9648,4,"도심·장거리"),
        h("종각역",37.5702,126.9831,4,"도심·심야"),
        h("을지로입구역",37.5660,126.9820,4,"도심·심야"),
        h("왕십리역",37.5615,127.0378,4,"동부·장거리"),
        h("성수역",37.5446,127.0559,5,"콜밀집·심야"),
        h("건대입구역",37.5404,127.0692,5,"콜밀집·심야"),
        // 강남/송파/강동
        h("신사역",37.5163,127.0203,5,"장거리·심야"),
        h("논현역",37.5112,127.0214,5,"콜밀집·장거리"),
        h("강남역",37.4979,127.0276,5,"콜밀집·장거리"),
        h("역삼역",37.5006,127.0365,5,"업무·장거리"),
        h("선릉역",37.5045,127.0490,5,"업무·장거리"),
        h("삼성역",37.5088,127.0632,5,"업무·장거리"),
        h("잠실새내역",37.5116,127.0860,5,"콜밀집·심야"),
        h("잠실역",37.5133,127.1001,5,"장거리·동부권"),
        h("천호역",37.5386,127.1233,4,"동부·장거리"),
        // 김포/고양/파주/인천/부천
        h("김포 구래역",37.6454,126.6287,4,"김포·장거리"),
        h("김포 장기역",37.6441,126.6696,4,"김포·중장거리"),
        h("일산 정발산역",37.6595,126.7734,5,"일산·콜밀집"),
        h("일산 백석역",37.6431,126.7880,4,"일산·서울복귀"),
        h("파주 야당역",37.7127,126.7610,4,"운정·서울복귀"),
        h("부천 상동역",37.5058,126.7532,5,"부천·콜밀집"),
        h("부천 중동",37.5020,126.7750,4,"부천·서울복귀"),
        h("인천 부평역",37.4895,126.7245,5,"인천·콜밀집"),
        h("인천 구월동",37.4497,126.7019,5,"인천·심야"),
        h("인천 송도",37.3825,126.6565,4,"인천·장거리"),
        // 안양/안산/수원/성남/분당/용인
        h("범계역",37.3898,126.9507,5,"안양·콜밀집"),
        h("평촌역",37.3943,126.9638,4,"안양·서울복귀"),
        h("안산 중앙역",37.3161,126.8385,5,"안산·콜밀집"),
        h("수원 인계동",37.2636,127.0327,5,"수원·콜밀집"),
        h("수원 영통역",37.2515,127.0714,4,"수원·중장거리"),
        h("광교중앙역",37.2883,127.0517,4,"수원·서울복귀"),
        h("성남 모란역",37.4321,127.1291,5,"성남·콜밀집"),
        h("분당 야탑역",37.4112,127.1287,4,"분당·서울복귀"),
        h("분당 서현역",37.3851,127.1231,5,"분당·콜밀집"),
        h("분당 정자역",37.3652,127.1081,5,"분당·장거리"),
        h("판교역",37.3948,127.1112,5,"판교·업무"),
        h("용인 죽전역",37.3248,127.1074,4,"용인·서울복귀"),
        h("용인 기흥역",37.2755,127.1158,4,"용인·중장거리"),
        h("동탄 북광장",37.2067,127.0728,5,"동탄·콜밀집"),
        h("오산역",37.1450,127.0670,4,"오산·중장거리"),
        // 동북/동남 수도권
        h("구리 돌다리",37.5990,127.1390,4,"구리·서울복귀"),
        h("남양주 다산",37.6249,127.1525,4,"남양주·서울복귀"),
        h("하남 미사역",37.5609,127.1934,5,"하남·서울복귀"),
        h("경기광주역",37.3998,127.2523,4,"광주·서울복귀"),
        h("의정부역",37.7381,127.0459,4,"의정부·서울복귀"),
        h("의정부 민락",37.7450,127.0950,4,"민락·콜밀집"),
        h("평택역",36.9909,127.0850,5,"평택·콜밀집"),
        h("평택 고덕",37.0430,127.0490,4,"고덕·장거리"),
        // 충청/강원 주요 도착지 대응
        h("천안 두정역",36.8337,127.1489,5,"천안·콜밀집"),
        h("천안 불당",36.8150,127.1070,5,"천안·장거리"),
        h("아산 배방",36.7730,127.0520,4,"아산·천안연결"),
        h("청주 복대동",36.6420,127.4320,5,"청주·콜밀집"),
        h("대전 둔산동",36.3510,127.3780,5,"대전·콜밀집"),
        h("대전 유성",36.3620,127.3560,4,"대전·장거리"),
        h("춘천 퇴계동",37.8530,127.7380,4,"춘천·콜밀집"),
        h("원주 단계동",37.3500,127.9280,5,"원주·콜밀집"),
        h("강릉 교동",37.7640,128.8760,4,"강릉·콜밀집")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("pricing_adjust", MODE_PRIVATE);
        apiPrefs = getSharedPreferences("naver_api_private", MODE_PRIVATE);
        callziroAdapter = new CallziroAdapter();
        loadSeedCallpoints();
        returnDeltaK = prefs.getInt("returnK", -5);
        runDeltaK = prefs.getInt("runK", 0);
        happyDeltaK = prefs.getInt("happyK", 5);
        currentPreset = prefs.getString("currentPreset", "weekday");
        weekdayPresetK = prefs.getInt("preset_weekdayK", 0);
        friSatPresetK = prefs.getInt("preset_frisatK", 2);
        lateNightPresetK = prefs.getInt("preset_latenightK", 3);
        dawnPresetK = prefs.getInt("preset_dawnK", 1);
        currentMode = prefs.getString("currentMode", "run");
        currentLat = Double.longBitsToDouble(prefs.getLong("lastLatBits", Double.doubleToLongBits(REF_LAT)));
        currentLon = Double.longBitsToDouble(prefs.getLong("lastLonBits", Double.doubleToLongBits(REF_LON)));
        callziroDistanceKm = prefs.getInt("callziro_distance_km", 20);
        if (callziroDistanceKm < 5 || callziroDistanceKm > 50) callziroDistanceKm = 20;
        modeDeltaK = deltaForMode(currentMode);
        presetDeltaK = deltaForPreset(currentPreset);
        setContentView(buildUi());
        recalculateAll();
        refreshRecentPreview();
        handleLaunchIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleLaunchIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs != null && returnButton != null) {
            String savedMode = prefs.getString("currentMode", currentMode);
            String savedPreset = prefs.getString("currentPreset", currentPreset);
            boolean changed = !savedMode.equals(currentMode) || !savedPreset.equals(currentPreset);
            currentMode = savedMode;
            currentPreset = savedPreset;
            modeDeltaK = deltaForMode(currentMode);
            presetDeltaK = deltaForPreset(currentPreset);
            refreshModeUi();
            refreshPresetUi();
            if (changed) recalculateAll();
        }
        refreshFloatingUi();
        if (overlayRequestPending && Settings.canDrawOverlays(this)) {
            overlayRequestPending = false;
            startFloatingService();
        }
    }

    private void handleLaunchIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("refreshGps", false)) {
            intent.removeExtra("refreshGps");
            if (locationText != null) locationText.post(this::requestCurrentLocation);
        }
    }

    private View buildUi() {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(18), dp(16), dp(10));
        header.addView(text("콜지가격", 28, TEXT, true));
        TextView sub = text("가격과 콜밭을 분리해서 필요한 화면만 빠르게", 13, MUTED, false);
        sub.setPadding(0, dp(4), 0, 0);
        header.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        homePriceTabButton = secondaryButton("💰 콜가격");
        homeCallziroTabButton = secondaryButton("📍 콜밭지역");
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        p2.leftMargin = dp(8);
        tabs.addView(homePriceTabButton, p1);
        tabs.addView(homeCallziroTabButton, p2);
        header.addView(tabs, topMargin(12));
        shell.addView(header);

        FrameLayout host = new FrameLayout(this);
        homePricePage = buildPricePage();
        homeCallziroPage = buildCallziroPage();
        host.addView(homePricePage, new FrameLayout.LayoutParams(-1, -1));
        host.addView(homeCallziroPage, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        shell.addView(host, hostLp);

        homePriceTabButton.setOnClickListener(v -> showHomeTab("price"));
        homeCallziroTabButton.setOnClickListener(v -> showHomeTab("callziro"));
        showHomeTab(prefs.getString("home_tab", "price"));
        return shell;
    }

    private View buildPricePage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(4), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout locCard = card();
        locCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        locCard.addView(text("현재 출발 위치", 12, MUTED, false));
        locationText = text("강서로 490 · 기준 위치", 18, TEXT, true);
        locationText.setPadding(0, dp(4), 0, 0);
        locCard.addView(locationText);
        Button gps = primaryButton("GPS 새로고침 · 전 권역 재계산");
        LinearLayout.LayoutParams gpsLp = new LinearLayout.LayoutParams(-1, dp(50));
        gpsLp.topMargin = dp(12);
        locCard.addView(gps, gpsLp);
        gps.setOnClickListener(v -> requestCurrentLocation());
        root.addView(locCard, topMargin(4));

        TextView modeTitle = text("운행 모드", 17, TEXT, true);
        root.addView(modeTitle, topMargin(16));
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        returnButton = modeButton("복귀콜\n-5천");
        runButton = modeButton("달려콜\n기준");
        happyButton = modeButton("해피타임\n+5천");
        modes.addView(returnButton, weightLp(1));
        LinearLayout.LayoutParams mid = weightLp(1); mid.leftMargin = dp(6); mid.rightMargin = dp(6);
        modes.addView(runButton, mid);
        modes.addView(happyButton, weightLp(1));
        root.addView(modes, topMargin(8));
        modeStateText = text("현재: 달려콜 · 기준", 13, ACCENT, true);
        root.addView(modeStateText, topMargin(6));
        returnButton.setOnClickListener(v -> setMode("return"));
        runButton.setOnClickListener(v -> setMode("run"));
        happyButton.setOnClickListener(v -> setMode("happy"));
        refreshModeUi();

        addAdjustmentCard(root);
        addTimePresetCard(root);
        addFloatingCard(root);
        addRecentUsageCard(root);
        addBackupRestoreCard(root);

        favoritesHeader = text("★ 즐겨찾기", 20, TEXT, true);
        favoritesHeader.setVisibility(View.GONE);
        root.addView(favoritesHeader, topMargin(18));
        favoritesContainer = new LinearLayout(this);
        favoritesContainer.setOrientation(LinearLayout.VERTICAL);
        favoritesContainer.setVisibility(View.GONE);
        root.addView(favoritesContainer);

        addSection(root, "서울", "서울 복사", seoulTargets);
        addSection(root, "수도권", "수도권 복사", metroTargets);
        addSection(root, "수원 · 분당 · 용인", "수원세트 복사", suwonBundleTargets);
        addSection(root, "안양 · 안산", "안양세트 복사", anyangBundleTargets);
        addSection(root, "충청권", "충청권 복사", chungcheongTargets);
        addSection(root, "강원권", "강원권 복사", gangwonTargets);

        TextView detailTitle = text("세부 지역", 20, TEXT, true);
        detailTitle.setPadding(0, dp(10), 0, 0);
        root.addView(detailTitle, topMargin(18));
        TextView detailSub = text("앱마다 적용 방식이 다를 때 필요한 지역만 골라서 복사", 12, MUTED, false);
        detailSub.setPadding(0, dp(3), 0, dp(2));
        root.addView(detailSub);

        addSection(root, "서울(구)", "서울(구) 복사", seoulGuTargets);
        addSection(root, "김포 · 고양 · 파주 · 인천 · 부천", "이 묶음 복사",
                combineTargets(gimpoTargets, goyangPajuTargets, incheonBucheonTargets));
        addSection(root, "안양 · 안산 · 수원 · 용인 · 화성 · 오산", "이 묶음 복사",
                combineTargets(anyangTargets, ansanTargets, suwonTargets, yonginTargets, hwaseongOsanTargets));
        addSection(root, "성남 · 분당 · 남양주 · 구리", "이 묶음 복사",
                combineTargets(seongnamTargets, bundangTargets, namyangjuGuriTargets));
        addSection(root, "하남 · 광주 · 의정부 · 양주 · 평택 · 안성", "이 묶음 복사",
                combineTargets(hanamGwangjuTargets, uijeongbuYangjuTargets, pyeongtaekAnseongTargets));

        TextView foot = text("※ 강서로 490 기준표에 현재 GPS와 목적지 거리 차이를 보정하는 개인용 최소수락가 계산표야. 실시간 플랫폼 제시가가 아니야.", 11, MUTED, false);
        foot.setLineSpacing(0, 1.25f);
        root.addView(foot, topMargin(16));
        return scroll;
    }

    private View buildCallziroPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(4), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView pageTitle = text("콜밭지역", 22, TEXT, true);
        root.addView(pageTitle, topMargin(4));
        TextView pageSub = text("콜밭·지역·공지·즐겨찾기만 모아둔 독립 화면", 12, MUTED, false);
        pageSub.setPadding(0, dp(3), 0, 0);
        root.addView(pageSub);

        LinearLayout shareCard = card();
        shareCard.setPadding(dp(14), dp(13), dp(14), dp(13));
        shareCard.addView(text("콜지로와 공유한다", 16, ACCENT, true));
        TextView shareSub = text("콜밭/위치 정보 제공 및 연동: 콜지로 · 카카오톡 로그인은 포함하지 않음", 11, MUTED, false);
        shareSub.setPadding(0, dp(4), 0, 0);
        shareSub.setLineSpacing(0, 1.2f);
        shareCard.addView(shareSub);
        root.addView(shareCard, topMargin(10));

        LinearLayout locCard = card();
        locCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        locCard.addView(text("콜밭 검색 기준 위치", 12, MUTED, false));
        callziroLocationText = text(String.format(Locale.KOREA, "현재 좌표 · %.5f, %.5f", currentLat, currentLon), 17, TEXT, true);
        callziroLocationText.setPadding(0, dp(4), 0, 0);
        locCard.addView(callziroLocationText);
        Button gps = primaryButton("GPS 새로고침");
        LinearLayout.LayoutParams gpsLp = new LinearLayout.LayoutParams(-1, dp(48));
        gpsLp.topMargin = dp(10);
        locCard.addView(gps, gpsLp);
        gps.setOnClickListener(v -> requestCurrentLocation());
        root.addView(locCard, topMargin(10));

        addCallziroLocationCard(root);
        addArrivalHotspotCard(root);
        addNationwideCallpointCard(root);

        LinearLayout updateCard = card();
        updateCard.setPadding(dp(14), dp(13), dp(14), dp(13));
        updateCard.addView(text("업데이트 연동 구조", 15, TEXT, true));
        TextView updateText = text("콜지로 서버의 콜밭/공지 데이터 변경은 새로고침으로 반영하고, 앱 구조나 응답 형식이 바뀌면 Callziro Adapter만 교체하도록 분리했어.", 11, MUTED, false);
        updateText.setPadding(0, dp(4), 0, 0);
        updateText.setLineSpacing(0, 1.25f);
        updateCard.addView(updateText);
        root.addView(updateCard, topMargin(12));
        return scroll;
    }

    private void showHomeTab(String tab) {
        boolean callziro = "callziro".equals(tab);
        if (homePricePage != null) homePricePage.setVisibility(callziro ? View.GONE : View.VISIBLE);
        if (homeCallziroPage != null) homeCallziroPage.setVisibility(callziro ? View.VISIBLE : View.GONE);
        if (homePriceTabButton != null) {
            homePriceTabButton.setBackground(rounded(callziro ? SOFT : ACCENT, 12));
            homePriceTabButton.setTextColor(callziro ? TEXT : Color.rgb(48, 40, 25));
        }
        if (homeCallziroTabButton != null) {
            homeCallziroTabButton.setBackground(rounded(callziro ? ACCENT : SOFT, 12));
            homeCallziroTabButton.setTextColor(callziro ? Color.rgb(48, 40, 25) : TEXT);
        }
        prefs.edit().putString("home_tab", callziro ? "callziro" : "price").apply();
    }



    private void addArrivalHotspotCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("도착 후 어디로?", 18, TEXT, true));
        TextView helper = text("현재 GPS 주변의 내장 콜포인트 DB를 우선 추천 · 좌표 미확인 지점은 길찾기 누를 때 자동 확인", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        helper.setLineSpacing(0, 1.2f);
        c.addView(helper);
        Button open = primaryButton("📍 추천 콜포인트 보기");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        c.addView(open, lp);
        open.setOnClickListener(v -> showSeedAwareHotspotRecommendations());
        root.addView(c, topMargin(12));
    }

    private void showHotspotRecommendations() {
        List<HotspotRank> ranked = new ArrayList<>();
        for (Hotspot h : hotspots) {
            double roadKm = haversineKm(currentLat, currentLon, h.lat, h.lon) * 1.18;
            // 가까움의 가치를 크게 두되, 고정 매력도(3~5성)가 높은 곳은 조금 더 우대
            double score = h.stars * 20.0 - Math.min(roadKm, 80.0) * 1.65;
            ranked.add(new HotspotRank(h, roadKm, score));
        }
        Collections.sort(ranked, (a, b) -> Double.compare(b.score, a.score));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(2), dp(4), dp(8));

        TextView from = text("현재: " + (locationText == null ? "GPS 위치" : locationText.getText().toString()), 12, MUTED, false);
        from.setPadding(dp(8), dp(4), dp(8), dp(8));
        body.addView(from);

        int count = Math.min(5, ranked.size());
        for (int i = 0; i < count; i++) {
            HotspotRank rr = ranked.get(i);
            Hotspot hp = rr.hotspot;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(11), dp(12), dp(11));
            item.setBackground(rounded(Color.rgb(35, 39, 47), 12));

            TextView name = text((i + 1) + ". " + hp.name + "  " + starText(hp.stars), 16, TEXT, true);
            item.addView(name);
            TextView meta = text(String.format(Locale.KOREA, "약 %.1fkm · %s", rr.roadKm, hp.tag), 12, MUTED, false);
            meta.setPadding(0, dp(4), 0, 0);
            item.addView(meta);

            Button nav = primaryButton("네이버지도 길찾기");
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, dp(44));
            nlp.topMargin = dp(8);
            item.addView(nav, nlp);
            nav.setOnClickListener(v -> openNaverRoute(hp));

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) ilp.topMargin = dp(8);
            body.addView(item, ilp);
        }

        TextView note = text("※ 추천순위는 현재 위치와 미리 등록한 콜포인트의 거리/매력도를 조합한 개인용 참고값이야. 플랫폼 실시간 콜 수요를 읽는 기능은 아니야.", 11, MUTED, false);
        note.setPadding(dp(8), dp(10), dp(8), dp(2));
        note.setLineSpacing(0, 1.2f);
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle("도착 후 어디로? · 추천 TOP 5")
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private String starText(int stars) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) sb.append(i < stars ? "★" : "☆");
        return sb.toString();
    }

    private void openNaverRoute(Hotspot hp) {
        try {
            Uri uri = Uri.parse("nmap://route/car").buildUpon()
                    .appendQueryParameter("slat", String.format(Locale.US, "%.7f", currentLat))
                    .appendQueryParameter("slng", String.format(Locale.US, "%.7f", currentLon))
                    .appendQueryParameter("sname", "현재위치")
                    .appendQueryParameter("dlat", String.format(Locale.US, "%.7f", hp.lat))
                    .appendQueryParameter("dlng", String.format(Locale.US, "%.7f", hp.lon))
                    .appendQueryParameter("dname", hp.name)
                    .appendQueryParameter("appname", getPackageName())
                    .build();
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.nhn.android.nmap");
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.nhn.android.nmap")));
            } catch (Exception ignored) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.nhn.android.nmap")));
            }
            Toast.makeText(this, "네이버지도가 없어서 설치 화면을 열었어", Toast.LENGTH_LONG).show();
        }
    }


    private void addCallziroLocationCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("콜지로 통합 허브", 18, TEXT, true));

        TextView share = text("위치 및 콜밭 정보는 콜지로와 공유한다 · 콜지로 제공 기능/데이터 사용", 12, ACCENT, true);
        share.setPadding(0, dp(4), 0, 0);
        share.setLineSpacing(0, 1.2f);
        c.addView(share);

        TextView scope = text("담당자 허락 범위로 통합 · 카카오톡 로그인 기능은 포함하지 않음. 서버 인증을 우회하지 않고 정상 응답만 사용해.", 11, MUTED, false);
        scope.setPadding(0, dp(5), 0, 0);
        scope.setLineSpacing(0, 1.2f);
        c.addView(scope);

        Button refresh = primaryButton("📡 주변 콜밭 새로고침");
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, dp(50));
        rlp.topMargin = dp(10);
        c.addView(refresh, rlp);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button map = secondaryButton("🗺 콜밭 지도");
        Button list = secondaryButton("📋 콜밭 목록");
        row1.addView(map, weightLp(1));
        LinearLayout.LayoutParams lpList = weightLp(1); lpList.leftMargin = dp(6);
        row1.addView(list, lpList);
        c.addView(row1, topMargin(7));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button search = secondaryButton("🔎 지역 검색");
        Button notices = secondaryButton("📣 콜지로 공지");
        row2.addView(search, weightLp(1));
        LinearLayout.LayoutParams lpNotice = weightLp(1); lpNotice.leftMargin = dp(6);
        row2.addView(notices, lpNotice);
        c.addView(row2, topMargin(7));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        Button radius = secondaryButton("반경 " + callziroDistanceKm + "km");
        Button favorite = secondaryButton("★ 즐겨찾기만");
        row3.addView(radius, weightLp(1));
        LinearLayout.LayoutParams lpFav = weightLp(1); lpFav.leftMargin = dp(6);
        row3.addView(favorite, lpFav);
        c.addView(row3, topMargin(7));

        Button originalApp = secondaryButton("↗ 콜지로 원본 앱 열기");
        c.addView(originalApp, topMargin(7));

        callziroCountText = text("콜밭 0개 · 즐겨찾기 0개", 12, TEXT, true);
        callziroCountText.setPadding(0, dp(8), 0, 0);
        c.addView(callziroCountText);

        callziroStateText = text("아직 불러오지 않음 · 반경 " + callziroDistanceKm + "km · 기존 내장 DB는 그대로 유지", 11, MUTED, false);
        callziroStateText.setPadding(0, dp(4), 0, 0);
        c.addView(callziroStateText);

        refresh.setOnClickListener(v -> fetchCallziroNearby(true));
        map.setOnClickListener(v -> ensureCallziroLoadedThen(this::showCallziroMapDialog));
        list.setOnClickListener(v -> ensureCallziroLoadedThen(() -> showCallziroPointsDialog(false)));
        search.setOnClickListener(v -> ensureCallziroLoadedThen(this::showCallziroSearchDialog));
        notices.setOnClickListener(v -> fetchCallziroNotices());
        favorite.setOnClickListener(v -> ensureCallziroLoadedThen(() -> showCallziroPointsDialog(true)));
        originalApp.setOnClickListener(v -> openCallziroOriginalApp());
        radius.setOnClickListener(v -> {
            int[] values = new int[]{5, 10, 20, 30, 50};
            int next = 20;
            for (int i = 0; i < values.length; i++) {
                if (values[i] == callziroDistanceKm) { next = values[(i + 1) % values.length]; break; }
            }
            callziroDistanceKm = next;
            prefs.edit().putInt("callziro_distance_km", next).apply();
            radius.setText("반경 " + next + "km");
            callziroStateText.setText("반경을 " + next + "km로 바꿨어 · 새로고침하면 적용");
            callziroStateText.setTextColor(MUTED);
        });
        root.addView(c, topMargin(12));
    }

    private void ensureCallziroLoadedThen(Runnable after) {
        if (!callziroPoints.isEmpty()) {
            after.run();
            return;
        }
        fetchCallziroNearby(false, after);
    }

    private void fetchCallziroNearby(boolean showWhenDone) {
        fetchCallziroNearby(showWhenDone, null);
    }

    private void fetchCallziroNearby(boolean showWhenDone, Runnable after) {
        final double lat = currentLat;
        final double lon = currentLon;
        final int distance = callziroDistanceKm;
        if (callziroStateText != null) {
            callziroStateText.setText("콜지로에서 주변 콜밭 불러오는 중…");
            callziroStateText.setTextColor(ACCENT);
        }

        new Thread(() -> {
            try {
                ArrayList<CallziroAdapter.Point> parsed = callziroAdapter.fetchNearby(lat, lon, distance);
                runOnUiThread(() -> {
                    callziroPoints.clear();
                    callziroPoints.addAll(parsed);
                    sortCallziroPoints();
                    refreshCallziroCounts();
                    if (callziroStateText != null) {
                        callziroStateText.setText("콜지로 콜밭 " + parsed.size() + "개 불러옴 · 반경 " + distance + "km");
                        callziroStateText.setTextColor(parsed.isEmpty() ? MUTED : Color.rgb(113, 210, 147));
                    }
                    if (parsed.isEmpty()) {
                        Toast.makeText(this, "주변 콜밭이 없거나 응답 형식이 달라. 기존 내장 DB는 그대로 쓸 수 있어.", Toast.LENGTH_LONG).show();
                    } else if (after != null) {
                        after.run();
                    } else if (showWhenDone) {
                        showCallziroPointsDialog(false);
                    }
                });
            } catch (CallziroAdapter.AdapterException e) {
                final boolean auth = e.authRequired;
                final String msg = e.getMessage() == null ? "연결 오류" : e.getMessage();
                runOnUiThread(() -> {
                    if (callziroStateText != null) {
                        callziroStateText.setText(auth
                                ? "콜지로 서버 인증이 필요해 자동 연동은 중지 · 인증 우회 안 함"
                                : "콜지로 연결 실패 · 기존 내장 DB 사용 중 (" + msg + ")");
                        callziroStateText.setTextColor(MUTED);
                    }
                    Toast.makeText(this, auth
                            ? "서버 인증이 필요한 기능은 건드리지 않아. 기존 기능은 정상 사용 가능해."
                            : "콜지로 연결 실패. 기존 콜포인트 DB는 그대로 사용해.", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                runOnUiThread(() -> {
                    if (callziroStateText != null) {
                        callziroStateText.setText("콜지로 연결 실패 · 기존 내장 DB 사용 중 (" + msg + ")");
                        callziroStateText.setTextColor(MUTED);
                    }
                    Toast.makeText(this, "콜지로 연결 실패. 기존 콜포인트 DB는 그대로 사용해.", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void sortCallziroPoints() {
        Collections.sort(callziroPoints, (a, b) -> {
            boolean af = isCallziroFavorite(a), bf = isCallziroFavorite(b);
            if (af != bf) return af ? -1 : 1;
            return Double.compare(a.roadKm, b.roadKm);
        });
    }

    private String callziroFavoriteKey(CallziroAdapter.Point cp) {
        String id = cp.id == null || cp.id.isEmpty() ? (cp.name + "_" + String.format(Locale.US, "%.4f_%.4f", cp.lat, cp.lon)) : cp.id;
        return "callziro_fav_" + id;
    }

    private boolean isCallziroFavorite(CallziroAdapter.Point cp) {
        return prefs.getBoolean(callziroFavoriteKey(cp), false);
    }

    private void toggleCallziroFavorite(CallziroAdapter.Point cp) {
        boolean next = !isCallziroFavorite(cp);
        prefs.edit().putBoolean(callziroFavoriteKey(cp), next).apply();
        refreshCallziroCounts();
        Toast.makeText(this, next ? "★ 즐겨찾기에 저장했어" : "즐겨찾기에서 뺐어", Toast.LENGTH_SHORT).show();
    }

    private void refreshCallziroCounts() {
        if (callziroCountText == null) return;
        int fav = 0;
        for (CallziroAdapter.Point cp : callziroPoints) if (isCallziroFavorite(cp)) fav++;
        callziroCountText.setText("콜밭 " + callziroPoints.size() + "개 · 즐겨찾기 " + fav + "개");
    }

    private void showCallziroPointsDialog(boolean favoritesOnly) {
        ArrayList<CallziroAdapter.Point> copy = new ArrayList<>();
        for (CallziroAdapter.Point cp : callziroPoints) if (!favoritesOnly || isCallziroFavorite(cp)) copy.add(cp);
        Collections.sort(copy, (a, b) -> {
            boolean af = isCallziroFavorite(a), bf = isCallziroFavorite(b);
            if (af != bf) return af ? -1 : 1;
            return Double.compare(a.roadKm, b.roadKm);
        });
        showCallziroFilteredDialog(copy, favoritesOnly ? "즐겨찾기 콜밭" : "콜지로 주변 콜밭");
    }

    private void showCallziroFilteredDialog(ArrayList<CallziroAdapter.Point> copy, String title) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(2), dp(4), dp(8));

        TextView attribution = text("콜지로와 공유한다 · 콜지로 제공 데이터", 12, ACCENT, true);
        attribution.setPadding(dp(8), dp(4), dp(8), dp(8));
        body.addView(attribution);

        if (copy.isEmpty()) {
            TextView none = text("표시할 콜밭이 없어", 14, MUTED, false);
            none.setPadding(dp(10), dp(18), dp(10), dp(18));
            body.addView(none);
        }

        int count = Math.min(60, copy.size());
        for (int i = 0; i < count; i++) {
            CallziroAdapter.Point cp = copy.get(i);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(11), dp(12), dp(11));
            item.setBackground(rounded(Color.rgb(35, 39, 47), 12));

            String star = isCallziroFavorite(cp) ? "★ " : "☆ ";
            item.addView(text(star + (i + 1) + ". " + cp.name, 16, TEXT, true));
            String place = !cp.addr.isEmpty() ? cp.addr : cp.jibun;
            if (place.isEmpty()) place = (cp.sido + " " + cp.sigungu).trim();
            String station = cp.station.isEmpty() ? "" : " · " + cp.station + (cp.stationLine.isEmpty() ? "" : " " + cp.stationLine);
            TextView meta = text(String.format(Locale.KOREA, "약 %.1fkm%s", cp.roadKm, station), 12, ACCENT, true);
            meta.setPadding(0, dp(4), 0, 0);
            item.addView(meta);
            if (!place.isEmpty()) item.addView(text(place, 12, MUTED, false));

            String quick = buildCallziroQuickMeta(cp);
            if (!quick.isEmpty()) {
                TextView q = text(quick, 11, Color.rgb(196, 203, 213), false);
                q.setPadding(0, dp(4), 0, 0);
                item.addView(q);
            }

            item.setOnClickListener(v -> showCallziroDetail(cp));
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) ilp.topMargin = dp(8);
            body.addView(item, ilp);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle(title + " · " + copy.size() + "개")
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private String buildCallziroQuickMeta(CallziroAdapter.Point cp) {
        ArrayList<String> parts = new ArrayList<>();
        if (!cp.rank.isEmpty()) parts.add("등급 " + cp.rank);
        if (!cp.spot.isEmpty()) parts.add("스팟 " + cp.spot);
        if (!cp.callTime.isEmpty()) parts.add("시간 " + cp.callTime);
        if (!cp.frequency.isEmpty()) parts.add("빈도 " + cp.frequency);
        if (!cp.price.isEmpty()) parts.add("가격 " + cp.price);
        return joinParts(parts, " · ");
    }

    private String joinParts(List<String> parts, String sep) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    private void showCallziroDetail(CallziroAdapter.Point cp) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(8), dp(16), dp(10));
        body.addView(text("콜지로와 공유한다", 12, ACCENT, true));
        body.addView(text(cp.name, 22, TEXT, true), topMargin(6));

        String place = !cp.addr.isEmpty() ? cp.addr : cp.jibun;
        if (!place.isEmpty()) body.addView(detailLine("주소", place));
        if (!cp.station.isEmpty()) body.addView(detailLine("역", cp.station + (cp.stationLine.isEmpty() ? "" : " · " + cp.stationLine)));
        body.addView(detailLine("거리", String.format(Locale.KOREA, "현재위치에서 약 %.1fkm", cp.roadKm)));
        if (!cp.rank.isEmpty()) body.addView(detailLine("등급", cp.rank));
        if (!cp.spot.isEmpty()) body.addView(detailLine("스팟", cp.spot));
        if (!cp.price.isEmpty()) body.addView(detailLine("가격", cp.price));
        if (!cp.frequency.isEmpty()) body.addView(detailLine("빈도", cp.frequency));
        if (!cp.callTime.isEmpty()) body.addView(detailLine("콜 시간", cp.callTime));
        if (!cp.callType.isEmpty()) body.addView(detailLine("콜 유형", cp.callType));
        if (!cp.competition.isEmpty()) body.addView(detailLine("경쟁", cp.competition));
        if (!cp.main.isEmpty()) body.addView(detailLine("메인", cp.main));
        if (!cp.size.isEmpty()) body.addView(detailLine("규모", cp.size));
        if (!cp.content.isEmpty()) {
            TextView content = text(cp.content, 13, Color.rgb(211, 216, 224), false);
            content.setPadding(0, dp(10), 0, dp(4));
            content.setLineSpacing(0, 1.25f);
            body.addView(content);
        }

        Button fav = secondaryButton(isCallziroFavorite(cp) ? "★ 즐겨찾기 해제" : "☆ 즐겨찾기 저장");
        body.addView(fav, topMargin(10));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        Button naver = primaryButton("네이버지도");
        Button kakao = secondaryButton("카카오맵");
        nav.addView(naver, weightLp(1));
        LinearLayout.LayoutParams klp = weightLp(1); klp.leftMargin = dp(6);
        nav.addView(kakao, klp);
        body.addView(nav, topMargin(8));
        naver.setOnClickListener(v -> openNaverRoute(cp.name, cp.lat, cp.lon));
        kakao.setOnClickListener(v -> openKakaoRoute(cp.name, cp.lat, cp.lon));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("콜밭 상세")
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .create();
        fav.setOnClickListener(v -> {
            toggleCallziroFavorite(cp);
            fav.setText(isCallziroFavorite(cp) ? "★ 즐겨찾기 해제" : "☆ 즐겨찾기 저장");
        });
        dialog.show();
    }

    private TextView detailLine(String label, String value) {
        TextView v = text(label + "  " + value, 13, Color.rgb(211, 216, 224), false);
        v.setPadding(0, dp(6), 0, 0);
        return v;
    }

    private void showCallziroSearchDialog() {
        final EditText input = new EditText(this);
        input.setHint("지역·콜밭명·주소·역 검색");
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(Color.rgb(125, 133, 145));
        input.setPadding(dp(12), dp(6), dp(12), dp(6));
        input.setBackground(rounded(Color.rgb(35, 39, 47), 12));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("콜지로 콜밭 검색")
                .setMessage("현재 불러온 " + callziroPoints.size() + "개 콜밭에서 검색")
                .setView(input)
                .setNegativeButton("취소", null)
                .setPositiveButton("검색", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String q = input.getText().toString().trim().toLowerCase(Locale.KOREA);
            if (q.isEmpty()) { Toast.makeText(this, "검색어를 입력해줘", Toast.LENGTH_SHORT).show(); return; }
            ArrayList<CallziroAdapter.Point> found = new ArrayList<>();
            for (CallziroAdapter.Point cp : callziroPoints) {
                String hay = (cp.name + " " + cp.addr + " " + cp.jibun + " " + cp.sido + " " + cp.sigungu + " " + cp.station + " " + cp.stationLine + " " + cp.content).toLowerCase(Locale.KOREA);
                if (hay.contains(q)) found.add(cp);
            }
            d.dismiss();
            showCallziroFilteredDialog(found, "검색: " + q);
        }));
        d.show();
    }

    private void showCallziroMapDialog() {
        ArrayList<CallziroAdapter.Point> copy = new ArrayList<>(callziroPoints);
        if (copy.isEmpty()) { Toast.makeText(this, "표시할 콜밭이 없어", Toast.LENGTH_SHORT).show(); return; }

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView hint = text("콜지로와 공유한다 · 원을 터치하면 가장 가까운 콜밭 상세를 열어", 12, ACCENT, true);
        hint.setPadding(dp(4), 0, dp(4), dp(8));
        body.addView(hint);

        CallziroRadarView radar = new CallziroRadarView(this, copy, currentLat, currentLon, callziroDistanceKm);
        body.addView(radar, new LinearLayout.LayoutParams(-1, dp(430)));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle("콜지로 콜밭 지도 · " + copy.size() + "개")
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private void fetchCallziroNotices() {
        if (callziroStateText != null) {
            callziroStateText.setText("콜지로 공지 불러오는 중…");
            callziroStateText.setTextColor(ACCENT);
        }
        new Thread(() -> {
            try {
                ArrayList<CallziroAdapter.Notice> parsed = callziroAdapter.fetchNotices();
                runOnUiThread(() -> {
                    callziroNotices.clear();
                    callziroNotices.addAll(parsed);
                    if (callziroStateText != null) {
                        callziroStateText.setText("콜지로 공지 " + parsed.size() + "개 불러옴");
                        callziroStateText.setTextColor(parsed.isEmpty() ? MUTED : Color.rgb(113, 210, 147));
                    }
                    showCallziroNoticesDialog(parsed);
                });
            } catch (CallziroAdapter.AdapterException e) {
                final String msg = e.authRequired ? "인증 필요" : (e.getMessage() == null ? "연결 오류" : e.getMessage());
                runOnUiThread(() -> {
                    if (callziroStateText != null) {
                        callziroStateText.setText("공지 불러오기 실패 (" + msg + ")");
                        callziroStateText.setTextColor(MUTED);
                    }
                    Toast.makeText(this, "공지 서버 응답을 확인하지 못했어", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                runOnUiThread(() -> {
                    if (callziroStateText != null) {
                        callziroStateText.setText("공지 불러오기 실패 (" + msg + ")");
                        callziroStateText.setTextColor(MUTED);
                    }
                    Toast.makeText(this, "공지 서버 응답을 확인하지 못했어", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void showCallziroNoticesDialog(ArrayList<CallziroAdapter.Notice> notices) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(6), dp(2), dp(6), dp(8));
        body.addView(text("콜지로와 공유한다 · 공지 출처: 콜지로", 12, ACCENT, true));
        if (notices.isEmpty()) body.addView(text("표시할 공지가 없어", 14, MUTED, false), topMargin(12));
        int count = Math.min(30, notices.size());
        for (int i = 0; i < count; i++) {
            CallziroAdapter.Notice n = notices.get(i);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(rounded(Color.rgb(35,39,47), 12));
            card.addView(text(n.subject, 15, TEXT, true));
            if (!n.date.isEmpty()) card.addView(text(n.date, 11, ACCENT, false));
            if (!n.content.isEmpty()) {
                String preview = n.content.length() > 180 ? n.content.substring(0, 180) + "…" : n.content;
                TextView pv = text(preview, 12, MUTED, false); pv.setPadding(0, dp(5), 0, 0); card.addView(pv);
            }
            card.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(n.subject).setMessage(n.content.isEmpty() ? "내용 없음" : n.content).setPositiveButton("닫기", null).show());
            body.addView(card, topMargin(8));
        }
        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        new AlertDialog.Builder(this).setTitle("콜지로 공지 · " + notices.size() + "개").setView(scroll).setNegativeButton("닫기", null).show();
    }

    private void openCallziroOriginalApp() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.callziro.app");
            if (launch != null) { startActivity(launch); return; }
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.callziro.app")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.callziro.app")));
        }
    }

    private void openNaverRoute(String name, double lat, double lon) {
        try {
            Uri uri = Uri.parse("nmap://route/car").buildUpon()
                    .appendQueryParameter("slat", String.format(Locale.US, "%.7f", currentLat))
                    .appendQueryParameter("slng", String.format(Locale.US, "%.7f", currentLon))
                    .appendQueryParameter("sname", "현재위치")
                    .appendQueryParameter("dlat", String.format(Locale.US, "%.7f", lat))
                    .appendQueryParameter("dlng", String.format(Locale.US, "%.7f", lon))
                    .appendQueryParameter("dname", name)
                    .appendQueryParameter("appname", getPackageName())
                    .build();
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.nhn.android.nmap");
            startActivity(intent);
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.nhn.android.nmap"))); }
            catch (Exception ignored) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.nhn.android.nmap"))); }
            Toast.makeText(this, "네이버지도가 없어서 설치 화면을 열었어", Toast.LENGTH_LONG).show();
        }
    }

    private void openKakaoRoute(String name, double lat, double lon) {
        try {
            String uri = "kakaomap://route?sp=" + String.format(Locale.US, "%.7f,%.7f", currentLat, currentLon)
                    + "&ep=" + String.format(Locale.US, "%.7f,%.7f", lat, lon) + "&by=CAR";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri)));
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=net.daum.android.map"))); }
            catch (Exception ignored) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=net.daum.android.map"))); }
            Toast.makeText(this, "카카오맵이 없어서 설치 화면을 열었어", Toast.LENGTH_LONG).show();
        }
    }

    private void addNationwideCallpointCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("전국 콜포인트 찾기", 18, TEXT, true));
        TextView helper = text("예: 용인 양지 · 평택 고덕 · 원주 단계동 · 부산 서면\n서울 59개 + 인천·경기 57개, 총 116개 실전 DB를 앱에 내장했어. DB에 있는 지역은 먼저 보여주고, 없는 지역만 전국 모방추천/네이버 API로 이어져.", 11, MUTED, false);
        helper.setPadding(0, dp(4), 0, 0);
        helper.setLineSpacing(0, 1.2f);
        c.addView(helper);

        nationwideQueryInput = new EditText(this);
        nationwideQueryInput.setHint("지역 검색 · 예: 용인 양지");
        nationwideQueryInput.setHintTextColor(Color.rgb(125, 133, 145));
        nationwideQueryInput.setTextColor(TEXT);
        nationwideQueryInput.setTextSize(15);
        nationwideQueryInput.setSingleLine(true);
        String lastNationwideQuery = prefs.getString("last_nationwide_query", "");
        if (!lastNationwideQuery.isEmpty()) {
            nationwideQueryInput.setText(lastNationwideQuery);
            nationwideQueryInput.setSelection(lastNationwideQuery.length());
        }
        nationwideQueryInput.setPadding(dp(12), 0, dp(12), 0);
        nationwideQueryInput.setBackground(rounded(Color.rgb(35, 39, 47), 12));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, dp(48));
        qlp.topMargin = dp(10);
        c.addView(nationwideQueryInput, qlp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button current = secondaryButton("현재위치 넣기");
        Button api = secondaryButton("네이버 API 연결");
        tools.addView(current, weightLp(1));
        LinearLayout.LayoutParams alp = weightLp(1); alp.leftMargin = dp(6);
        tools.addView(api, alp);
        c.addView(tools, topMargin(8));

        Button search = primaryButton("실전DB + 전국 추천 찾기");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(50));
        slp.topMargin = dp(8);
        c.addView(search, slp);

        nationwideApiStateText = text(apiConnected()
                ? "서울·수도권 실전DB " + seedCallpoints.size() + "개 내장 · 네이버 API도 연결됨"
                : "서울·수도권 실전DB " + seedCallpoints.size() + "개 내장 · 없는 지역은 전국 모방추천", 11,
                apiConnected() ? Color.rgb(113, 210, 147) : MUTED, false);
        nationwideApiStateText.setPadding(0, dp(7), 0, 0);
        c.addView(nationwideApiStateText);

        current.setOnClickListener(v -> fillNationwideQueryFromCurrentLocation());
        api.setOnClickListener(v -> showNaverApiSettings());
        search.setOnClickListener(v -> {
            String q = nationwideQueryInput.getText().toString().trim();
            if (q.isEmpty()) {
                Toast.makeText(this, "지역을 입력하거나 현재위치 넣기를 눌러줘", Toast.LENGTH_SHORT).show();
                return;
            }
            searchNationwideCallpoints(q);
        });
        root.addView(c, topMargin(12));
    }


    private void loadSeedCallpoints() {
        seedCallpoints.clear();
        try (InputStream in = getAssets().open("metro_callpoints_seed_v2.json");
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) b.append(line);
            JSONObject root = new JSONObject(b.toString());
            JSONArray arr = root.optJSONArray("hotspots");
            if (arr == null) return;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                double lat = o.isNull("lat") ? Double.NaN : o.optDouble("lat", Double.NaN);
                double lon = o.isNull("lng") ? Double.NaN : o.optDouble("lng", Double.NaN);
                seedCallpoints.add(new SeedCallpoint(
                        o.optString("id", "seed_" + i),
                        o.optString("sido", ""),
                        o.optString("sigungu", ""),
                        o.optString("eupmyeondong", ""),
                        o.optString("name", ""),
                        o.optString("naverQuery", ""),
                        o.optString("type", ""),
                        o.optString("timeHint", ""),
                        o.optString("note", ""),
                        o.optString("evidenceGrade", "C"),
                        o.optString("evidenceYear", ""),
                        o.optString("sourceUrl", ""),
                        lat, lon));
            }
        } catch (Exception e) {
            Toast.makeText(this, "내장 콜포인트 DB를 읽지 못했어", Toast.LENGTH_LONG).show();
        }
    }

    private String normSeed(String s) {
        return s == null ? "" : s.replaceAll("[\\s·/\\-_,.()]+", "").toLowerCase(Locale.KOREA);
    }

    private ArrayList<String> seedQueryTokens(String query) {
        ArrayList<String> out = new ArrayList<>();
        if (query == null) return out;
        for (String raw : query.split("[\\s,./·_-]+")) {
            String t = normSeed(raw);
            if (t.length() >= 2 && !out.contains(t)) out.add(t);
        }
        return out;
    }

    private int seedEvidenceStars(SeedCallpoint cp) {
        if ("A".equalsIgnoreCase(cp.evidenceGrade)) return 5;
        if ("B".equalsIgnoreCase(cp.evidenceGrade)) return 4;
        return 3;
    }

    private int seedFeedback(SeedCallpoint cp) {
        return prefs.getInt("seed_feedback_" + cp.id, 0);
    }

    private void saveSeedFeedback(SeedCallpoint cp, int delta) {
        String key = "seed_feedback_" + cp.id;
        int now = prefs.getInt(key, 0);
        int next = Math.max(-3, Math.min(3, now + delta));
        prefs.edit().putInt(key, next).apply();
        Toast.makeText(this, delta > 0 ? "좋은 콜포인트로 기억했어" : "선호도를 낮춰서 기억했어", Toast.LENGTH_SHORT).show();
    }

    private double seedTimeBonus(SeedCallpoint cp) {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String k = cp.type + " " + cp.timeHint;
        if (k.contains("술집") || k.contains("심야") || k.contains("번화가")) return (h >= 20 || h <= 3) ? 12.0 : 3.0;
        if (k.contains("회식") || k.contains("먹자")) return (h >= 17 && h <= 23) ? 10.0 : 3.0;
        if (k.contains("골프")) return (h >= 13 && h <= 21) ? 10.0 : 4.0;
        if (k.contains("산단") || k.contains("산업") || k.contains("업무")) return (h >= 16 && h <= 22) ? 8.0 : 2.0;
        return 4.0;
    }

    private boolean validSeedCoord(double lat, double lon) {
        return !Double.isNaN(lat) && !Double.isNaN(lon) && lat >= 31.0 && lat <= 44.5 && lon >= 122.0 && lon <= 132.5;
    }

    private double seedLat(SeedCallpoint cp) {
        if (validSeedCoord(cp.lat, cp.lon)) return cp.lat;
        long bits = prefs.getLong("seed_lat_" + cp.id, Double.doubleToLongBits(Double.NaN));
        return Double.longBitsToDouble(bits);
    }

    private double seedLon(SeedCallpoint cp) {
        if (validSeedCoord(cp.lat, cp.lon)) return cp.lon;
        long bits = prefs.getLong("seed_lon_" + cp.id, Double.doubleToLongBits(Double.NaN));
        return Double.longBitsToDouble(bits);
    }

    private void cacheSeedCoord(SeedCallpoint cp, double lat, double lon) {
        prefs.edit()
                .putLong("seed_lat_" + cp.id, Double.doubleToLongBits(lat))
                .putLong("seed_lon_" + cp.id, Double.doubleToLongBits(lon))
                .apply();
    }

    private String seedAreaGroupKey(SeedCallpoint cp) {
        if ("서울".equals(cp.sido) || "인천".equals(cp.sido)) return cp.sido;
        String sg = cp.sigungu == null ? "" : cp.sigungu.trim();
        int sp = sg.indexOf(' ');
        if (sp > 0 && sg.substring(0, sp).endsWith("시")) return sg.substring(0, sp);
        return sg;
    }

    private ArrayList<SeedRank> findSeedMatches(String query) {
        ArrayList<SeedRank> found = new ArrayList<>();
        ArrayList<String> tokens = seedQueryTokens(query);
        if (tokens.isEmpty()) return found;
        String nq = normSeed(query);

        for (SeedCallpoint cp : seedCallpoints) {
            String loc = normSeed(cp.sido + cp.sigungu + cp.eupmyeondong);
            String name = normSeed(cp.name);
            String nav = normSeed(cp.naverQuery);
            String all = loc + name + nav;
            int matched = 0;
            double score = 0;
            for (String t : tokens) {
                boolean hit = false;
                if (loc.contains(t)) { score += 34; hit = true; }
                else if (name.contains(t)) { score += 27; hit = true; }
                else if (nav.contains(t)) { score += 22; hit = true; }
                else if (all.contains(t)) { score += 15; hit = true; }
                if (hit) matched++;
            }
            if (matched == 0) continue;
            // "용인 양지"처럼 두 단어 이상이면 모든 단어가 맞는 항목만 1차 결과로 사용한다.
            // 한 단어만 우연히 포함된 다른 지역이 끼어드는 것을 막는다.
            if (tokens.size() >= 2 && matched < tokens.size()) continue;
            if (matched == tokens.size()) score += 55;
            if (!nq.isEmpty() && all.contains(nq)) score += 30;
            score += seedFeedback(cp) * 9.0 + seedTimeBonus(cp);
            if ("A".equalsIgnoreCase(cp.evidenceGrade)) score += 8;
            else if ("B".equalsIgnoreCase(cp.evidenceGrade)) score += 4;

            // 검색어 일치도가 핵심. 현재 GPS와 섞지 않아 "용인 양지"를 서울에서 검색해도
            // 용인 양지가 최우선으로 유지된다.
            found.add(new SeedRank(cp, score, -1));
        }
        Collections.sort(found, (a, b) -> Double.compare(b.score, a.score));

        // 구체적인 동/읍면 검색에서 결과가 1~2개뿐이면 같은 시군구의 후보도 뒤에 붙여준다.
        if (!found.isEmpty() && found.size() < 8) {
            String group = seedAreaGroupKey(found.get(0).callpoint);
            HashSet<String> ids = new HashSet<>();
            for (SeedRank r : found) ids.add(r.callpoint.id);
            for (SeedCallpoint cp : seedCallpoints) {
                if (found.size() >= 8) break;
                if (!group.isEmpty() && group.equals(seedAreaGroupKey(cp)) && !ids.contains(cp.id)) {
                    found.add(new SeedRank(cp, 5.0 + seedFeedback(cp) * 3.0, -1));
                    ids.add(cp.id);
                }
            }
        }
        return found;
    }

    private void showSeedSearchResults(String query, ArrayList<SeedRank> matches) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(2), dp(4), dp(8));

        TextView explain = text("내장 DB에서 '" + query + "'와 맞는 콜포인트를 먼저 찾았어. 검색어가 구체적이면 그 지점을 최우선으로, 부족한 수는 같은 시군구 후보로 채워 보여줘.", 11, MUTED, false);
        explain.setPadding(dp(8), dp(3), dp(8), dp(9));
        explain.setLineSpacing(0, 1.2f);
        body.addView(explain);

        int count = Math.min(8, matches.size());
        for (int i = 0; i < count; i++) {
            SeedRank rr = matches.get(i);
            SeedCallpoint cp = rr.callpoint;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(11), dp(12), dp(11));
            item.setBackground(rounded(Color.rgb(35, 39, 47), 12));

            int stars = Math.max(3, Math.min(5, seedEvidenceStars(cp) + (seedFeedback(cp) > 0 ? 1 : 0)));
            item.addView(text((i + 1) + ". " + cp.name + "  " + starText(stars), 16, TEXT, true));
            String area = (cp.sido + " " + cp.sigungu + " " + cp.eupmyeondong).trim().replaceAll("\\s+", " ");
            String dist = rr.roadKm >= 0 ? String.format(Locale.KOREA, " · 검색 중심 약 %.1fkm", rr.roadKm) : "";
            TextView meta = text(area + dist + " · " + cp.type, 12, ACCENT, true);
            meta.setPadding(0, dp(4), 0, 0);
            item.addView(meta);
            String detail = cp.timeHint + (cp.note.isEmpty() ? "" : "\n" + cp.note)
                    + "\n근거 " + cp.evidenceGrade + (cp.evidenceYear.isEmpty() ? "" : " · " + cp.evidenceYear);
            TextView dv = text(detail, 11, MUTED, false);
            dv.setPadding(0, dp(3), 0, 0);
            dv.setLineSpacing(0, 1.15f);
            item.addView(dv);

            LinearLayout fb = new LinearLayout(this);
            fb.setOrientation(LinearLayout.HORIZONTAL);
            Button good = secondaryButton("👍 좋음");
            Button bad = secondaryButton("👎 별로");
            fb.addView(good, weightLp(1));
            LinearLayout.LayoutParams bp = weightLp(1); bp.leftMargin = dp(6);
            fb.addView(bad, bp);
            item.addView(fb, topMargin(7));
            good.setOnClickListener(v -> saveSeedFeedback(cp, 1));
            bad.setOnClickListener(v -> saveSeedFeedback(cp, -1));

            Button nav = primaryButton("네이버지도 길찾기");
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, dp(44));
            nlp.topMargin = dp(7);
            item.addView(nav, nlp);
            nav.setOnClickListener(v -> openSeedNaverRoute(cp));

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) ilp.topMargin = dp(8);
            body.addView(item, ilp);
        }

        TextView note = text("※ DB 자체는 실시간 대리 호출량이 아니야. 공개자료로 만든 개인용 시드이며, 좌표가 아직 없는 지점은 길찾기를 누를 때 지역명으로 좌표를 확인하고 이 휴대폰에 캐시해.", 11, MUTED, false);
        note.setPadding(dp(8), dp(10), dp(8), 0);
        note.setLineSpacing(0, 1.2f);
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle(query + " · 내장DB TOP " + count)
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private void openSeedNaverRoute(SeedCallpoint cp) {
        double lat = seedLat(cp), lon = seedLon(cp);
        if (validSeedCoord(lat, lon)) {
            openNaverRoute(new Hotspot(cp.name, lat, lon, seedEvidenceStars(cp), cp.type));
            return;
        }
        Toast.makeText(this, cp.name + " 좌표를 확인하는 중이야…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            double rLat = Double.NaN, rLon = Double.NaN;
            try {
                Geocoder g = new Geocoder(this, Locale.KOREA);
                String q = cp.naverQuery.isEmpty() ? (cp.sido + " " + cp.sigungu + " " + cp.eupmyeondong + " " + cp.name) : cp.naverQuery;
                List<Address> list = g.getFromLocationName(q, 1);
                if ((list == null || list.isEmpty()) && !cp.name.isEmpty()) {
                    list = g.getFromLocationName(cp.sido + " " + cp.sigungu + " " + cp.name, 1);
                }
                if (list != null && !list.isEmpty()) {
                    rLat = list.get(0).getLatitude();
                    rLon = list.get(0).getLongitude();
                }
            } catch (Exception ignored) {}
            final double fLat = rLat, fLon = rLon;
            runOnUiThread(() -> {
                if (validSeedCoord(fLat, fLon)) {
                    cacheSeedCoord(cp, fLat, fLon);
                    openNaverRoute(new Hotspot(cp.name, fLat, fLon, seedEvidenceStars(cp), cp.type));
                } else {
                    Toast.makeText(this, "정확한 좌표를 못 잡아서 네이버지도 검색으로 열게", Toast.LENGTH_LONG).show();
                    openNaverSearch(cp.naverQuery.isEmpty() ? cp.name : cp.naverQuery);
                }
            });
        }).start();
    }

    private String currentAreaForSeed() {
        StringBuilder b = new StringBuilder();
        try {
            Geocoder g = new Geocoder(this, Locale.KOREA);
            List<Address> list = g.getFromLocation(currentLat, currentLon, 1);
            if (list != null && !list.isEmpty()) {
                Address a = list.get(0);
                if (a.getAddressLine(0) != null) b.append(a.getAddressLine(0)).append(' ');
                if (a.getAdminArea() != null) b.append(a.getAdminArea()).append(' ');
                if (a.getSubAdminArea() != null) b.append(a.getSubAdminArea()).append(' ');
                if (a.getLocality() != null) b.append(a.getLocality()).append(' ');
                if (a.getSubLocality() != null) b.append(a.getSubLocality()).append(' ');
                if (a.getFeatureName() != null) b.append(a.getFeatureName());
            }
        } catch (Exception ignored) {}
        if (b.length() == 0 && locationText != null) b.append(locationText.getText().toString());
        return b.toString();
    }

    private void showSeedAwareHotspotRecommendations() {
        Toast.makeText(this, "현재 위치 주변 실전 DB를 찾는 중이야…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String area = currentAreaForSeed();
            String nArea = normSeed(area);
            ArrayList<SeedRank> ranked = new ArrayList<>();
            for (SeedCallpoint cp : seedCallpoints) {
                double score = seedTimeBonus(cp) + seedFeedback(cp) * 10.0;
                if ("A".equalsIgnoreCase(cp.evidenceGrade)) score += 8;
                else if ("B".equalsIgnoreCase(cp.evidenceGrade)) score += 4;

                if (!cp.sido.isEmpty() && nArea.contains(normSeed(cp.sido))) score += 18;
                if (!cp.sigungu.isEmpty() && nArea.contains(normSeed(cp.sigungu))) score += 42;
                if (!cp.eupmyeondong.isEmpty() && nArea.contains(normSeed(cp.eupmyeondong))) score += 65;

                double lat = seedLat(cp), lon = seedLon(cp);
                double dist = -1;
                if (validSeedCoord(lat, lon)) {
                    dist = haversineKm(currentLat, currentLon, lat, lon) * 1.18;
                    score += Math.max(-25.0, 45.0 - Math.min(dist, 60.0) * 1.5);
                } else if (score < 25) {
                    // 현재 행정구역과도 안 맞고 좌표도 없는 항목은 근처 추천에서 제외
                    continue;
                }
                ranked.add(new SeedRank(cp, score, dist));
            }
            Collections.sort(ranked, (a, b) -> Double.compare(b.score, a.score));
            final String fArea = area;
            runOnUiThread(() -> {
                if (ranked.isEmpty() || ranked.get(0).score < 18) {
                    showHotspotRecommendations();
                } else {
                    showSeedNearbyDialog(fArea, ranked);
                }
            });
        }).start();
    }

    private void showSeedNearbyDialog(String area, ArrayList<SeedRank> ranked) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(2), dp(4), dp(8));
        TextView from = text("현재 지역: " + (area.isEmpty() ? "GPS 위치" : area), 12, MUTED, false);
        from.setPadding(dp(8), dp(4), dp(8), dp(8));
        body.addView(from);

        int count = Math.min(5, ranked.size());
        for (int i = 0; i < count; i++) {
            SeedRank rr = ranked.get(i);
            SeedCallpoint cp = rr.callpoint;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(11), dp(12), dp(11));
            item.setBackground(rounded(Color.rgb(35, 39, 47), 12));
            int stars = Math.max(3, Math.min(5, seedEvidenceStars(cp) + (seedFeedback(cp) > 0 ? 1 : 0)));
            item.addView(text((i + 1) + ". " + cp.name + "  " + starText(stars), 16, TEXT, true));
            String distText = rr.roadKm >= 0 ? String.format(Locale.KOREA, "약 %.1fkm", rr.roadKm) : "현재 지역 우선";
            TextView meta = text(distText + " · " + cp.type + " · " + cp.timeHint, 12, MUTED, false);
            meta.setPadding(0, dp(4), 0, 0);
            item.addView(meta);
            Button nav = primaryButton("네이버지도 길찾기");
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, dp(44));
            nlp.topMargin = dp(8);
            item.addView(nav, nlp);
            nav.setOnClickListener(v -> openSeedNaverRoute(cp));
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) ilp.topMargin = dp(8);
            body.addView(item, ilp);
        }

        TextView note = text("※ 현재 행정구역 일치 + 확인된 좌표 거리 + 시간대 + 내 좋음/별로 평가로 정렬해. 실시간 호출량은 아니야.", 11, MUTED, false);
        note.setPadding(dp(8), dp(10), dp(8), 0);
        body.addView(note);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle("도착 후 어디로? · 실전DB TOP " + count)
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private boolean apiConnected() {
        if (apiPrefs == null) return false;
        return !apiPrefs.getString("client_id", "").trim().isEmpty()
                && !apiPrefs.getString("client_secret", "").trim().isEmpty();
    }

    private void refreshNationwideApiState() {
        if (nationwideApiStateText == null) return;
        boolean connected = apiConnected();
        nationwideApiStateText.setText(connected
                ? "서울·수도권 실전DB " + seedCallpoints.size() + "개 내장 · 네이버 API도 연결됨"
                : "서울·수도권 실전DB " + seedCallpoints.size() + "개 내장 · 없는 지역은 전국 모방추천");
        nationwideApiStateText.setTextColor(connected ? Color.rgb(113, 210, 147) : MUTED);
    }

    private void showNaverApiSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(4), dp(4), 0);

        TextView note = text("선택 기능이야. 네이버 개발자센터에서 발급받은 Search API Client ID/Secret을 넣으면 실제 업체·기관명을 전국 검색해서 추천해.\n\n키는 APK에 하드코딩하지 않고 이 휴대폰에만 저장해. 개인용에는 쓸 수 있지만 APK를 배포할 계획이면 서버 중계 방식이 더 안전해.", 12, MUTED, false);
        note.setLineSpacing(0, 1.2f);
        box.addView(note);

        EditText id = new EditText(this);
        id.setHint("Client ID");
        id.setText(apiPrefs.getString("client_id", ""));
        id.setTextColor(TEXT);
        id.setHintTextColor(MUTED);
        id.setSingleLine(true);
        id.setBackground(rounded(Color.rgb(35, 39, 47), 10));
        id.setPadding(dp(10), 0, dp(10), 0);
        box.addView(id, topMargin(10));

        EditText secret = new EditText(this);
        secret.setHint("Client Secret");
        secret.setText(apiPrefs.getString("client_secret", ""));
        secret.setTextColor(TEXT);
        secret.setHintTextColor(MUTED);
        secret.setSingleLine(true);
        secret.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        secret.setBackground(rounded(Color.rgb(35, 39, 47), 10));
        secret.setPadding(dp(10), 0, dp(10), 0);
        box.addView(secret, topMargin(8));

        new AlertDialog.Builder(this)
                .setTitle("네이버 공식 지역검색 API")
                .setView(box)
                .setPositiveButton("저장", (d, w) -> {
                    apiPrefs.edit()
                            .putString("client_id", id.getText().toString().trim())
                            .putString("client_secret", secret.getText().toString().trim())
                            .apply();
                    refreshNationwideApiState();
                    Toast.makeText(this, apiConnected() ? "API 연결 정보를 저장했어" : "값이 비어 있어 모방 추천 모드로 사용할게", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("연결 해제", (d, w) -> {
                    apiPrefs.edit().clear().apply();
                    refreshNationwideApiState();
                    Toast.makeText(this, "API 연결을 해제했어", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void fillNationwideQueryFromCurrentLocation() {
        Toast.makeText(this, "현재 지역 이름을 찾는 중이야", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String q = "";
            try {
                Geocoder geocoder = new Geocoder(this, Locale.KOREA);
                List<Address> list = geocoder.getFromLocation(currentLat, currentLon, 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    ArrayList<String> parts = new ArrayList<>();
                    addUniquePart(parts, clean(a.getSubAdminArea()));
                    addUniquePart(parts, clean(a.getLocality()));
                    addUniquePart(parts, clean(a.getSubLocality()));
                    addUniquePart(parts, clean(a.getFeatureName()));
                    if (parts.isEmpty()) addUniquePart(parts, clean(a.getAdminArea()));
                    StringBuilder b = new StringBuilder();
                    for (String part : parts) {
                        if (part.matches(".*(번지|[0-9]+)$") && parts.size() > 1) continue;
                        if (b.length() > 0) b.append(' ');
                        b.append(part);
                        if (b.toString().length() > 24) break;
                    }
                    q = b.toString().trim();
                }
            } catch (Exception ignored) {}
            final String fq = q.isEmpty() ? "현재위치" : q;
            runOnUiThread(() -> {
                nationwideQueryInput.setText(fq);
                nationwideQueryInput.setSelection(fq.length());
            });
        }).start();
    }

    private void addUniquePart(ArrayList<String> parts, String value) {
        if (value == null || value.isEmpty()) return;
        for (String p : parts) if (p.equals(value)) return;
        parts.add(value);
    }

    private void searchNationwideCallpoints(String query) {
        prefs.edit().putString("last_nationwide_query", query).apply();

        // v2.3: 먼저 서울·수도권 확장 내장 DB를 검색한다. 예: "용인 양지"는 현재 GPS와 무관하게
        // 용인시 처인구 양지면 항목이 최우선으로 나온다.
        ArrayList<SeedRank> seedMatches = findSeedMatches(query);
        if (!seedMatches.isEmpty()) {
            showSeedSearchResults(query, seedMatches);
            return;
        }

        if (!apiConnected()) {
            showModeledNationwideRecommendations(query);
            return;
        }

        Toast.makeText(this, "전국 실제 장소 후보를 찾는 중이야…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            GeoCenter center = geocodeQueryCenter(query);
            ArrayList<CallpointCandidate> all = new ArrayList<>();
            HashSet<String> dedupe = new HashSet<>();
            SearchSpec[] specs = nationwideSpecs();
            String clientId = apiPrefs.getString("client_id", "");
            String clientSecret = apiPrefs.getString("client_secret", "");
            String error = "";

            for (SearchSpec spec : specs) {
                try {
                    ArrayList<CallpointCandidate> got = fetchNaverLocal(query + " " + spec.keyword, spec, clientId, clientSecret, center);
                    for (CallpointCandidate c : got) {
                        String key = normalizePlaceKey(c.name + "|" + c.address);
                        if (dedupe.add(key)) all.add(c);
                    }
                } catch (Exception e) {
                    if (error.isEmpty()) error = e.getMessage() == null ? "API 요청 실패" : e.getMessage();
                }
            }

            Collections.sort(all, (a, b) -> Double.compare(b.score, a.score));
            final String finalError = error;
            runOnUiThread(() -> {
                if (all.isEmpty()) {
                    Toast.makeText(this, finalError.isEmpty() ? "실제 장소 결과가 없어서 모방 추천으로 보여줄게" : "API 검색이 안 돼서 모방 추천으로 보여줄게", Toast.LENGTH_LONG).show();
                    showModeledNationwideRecommendations(query);
                } else {
                    showNationwideApiResults(query, center, all);
                }
            });
        }).start();
    }

    private GeoCenter geocodeQueryCenter(String query) {
        try {
            if (!"현재위치".equals(query)) {
                Geocoder g = new Geocoder(this, Locale.KOREA);
                List<Address> list = g.getFromLocationName(query, 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    return new GeoCenter(a.getLatitude(), a.getLongitude(), query);
                }
            }
        } catch (Exception ignored) {}
        return new GeoCenter(currentLat, currentLon, query);
    }

    private SearchSpec[] nationwideSpecs() {
        return new SearchSpec[] {
                new SearchSpec("회식·먹자", "맛집", 4.8, "회식/먹자"),
                new SearchSpec("술집·심야", "술집", 5.0, "술집/심야"),
                new SearchSpec("골프·장거리", "골프장", 4.7, "골프/장거리"),
                new SearchSpec("호텔·리조트", "호텔", 4.4, "숙박/장거리"),
                new SearchSpec("장례식장", "장례식장", 4.2, "장례/이동수요"),
                new SearchSpec("산업·퇴근", "산업단지", 4.0, "산업/퇴근")
        };
    }

    private ArrayList<CallpointCandidate> fetchNaverLocal(String fullQuery, SearchSpec spec,
                                                           String clientId, String clientSecret,
                                                           GeoCenter center) throws Exception {
        String url = "https://openapi.naver.com/v1/search/local.json?query="
                + URLEncoder.encode(fullQuery, "UTF-8")
                + "&display=5&start=1&sort=comment";
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        conn.setRequestProperty("X-Naver-Client-Id", clientId);
        conn.setRequestProperty("X-Naver-Client-Secret", clientSecret);
        conn.setRequestProperty("Accept", "application/json");
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder body = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) body.append(line);
        br.close();
        conn.disconnect();
        if (code < 200 || code >= 300) throw new Exception("네이버 API " + code);

        JSONObject root = new JSONObject(body.toString());
        JSONArray items = root.optJSONArray("items");
        ArrayList<CallpointCandidate> out = new ArrayList<>();
        if (items == null) return out;

        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            String name = cleanNaverTitle(item.optString("title"));
            String category = item.optString("category", "").replace('>', '·');
            String address = item.optString("roadAddress", "");
            if (address.isEmpty()) address = item.optString("address", "");
            double lon = scaledNaverCoord(item.optString("mapx"));
            double lat = scaledNaverCoord(item.optString("mapy"));
            if (name.isEmpty() || lat < 31.0 || lat > 44.5 || lon < 122.0 || lon > 132.5) continue;

            double dist = haversineKm(center.lat, center.lon, lat, lon) * 1.18;
            int fb = prefs.getInt(callpointFeedbackKey(name, address), 0);
            double time = timeBonusForSpec(spec.key);
            double score = spec.baseStars * 20.0 + time * 6.0 + fb * 9.0 - Math.min(dist, 40.0) * 1.45;
            int stars = (int) Math.round(spec.baseStars + time * 0.25 + fb * 0.25);
            stars = Math.max(3, Math.min(5, stars));
            out.add(new CallpointCandidate(name, lat, lon, stars, spec.tag, category, address, dist, score, fullQuery));
        }
        return out;
    }

    private double scaledNaverCoord(String raw) {
        try {
            long v = Long.parseLong(raw.trim());
            if (Math.abs(v) > 10000000L) return v / 10000000.0;
            return Double.parseDouble(raw);
        } catch (Exception e) {
            return 0.0;
        }
    }

    private String cleanNaverTitle(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", "")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .trim();
    }

    private double timeBonusForSpec(String key) {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if ("술집·심야".equals(key)) return (h >= 20 || h <= 3) ? 1.0 : 0.1;
        if ("회식·먹자".equals(key)) return (h >= 17 && h <= 23) ? 0.9 : 0.3;
        if ("골프·장거리".equals(key)) return (h >= 14 && h <= 21) ? 0.8 : 0.25;
        if ("호텔·리조트".equals(key)) return (h >= 18 || h <= 2) ? 0.7 : 0.3;
        if ("산업·퇴근".equals(key)) return (h >= 16 && h <= 21) ? 0.8 : 0.2;
        return 0.4;
    }

    private String normalizePlaceKey(String s) {
        return s == null ? "" : s.replaceAll("\\s+", "").toLowerCase(Locale.KOREA);
    }

    private String callpointFeedbackKey(String name, String address) {
        return "cp_feedback_" + (name + "|" + address).hashCode();
    }

    private void saveCallpointFeedback(CallpointCandidate c, int delta) {
        String key = callpointFeedbackKey(c.name, c.address);
        int now = prefs.getInt(key, 0);
        int next = Math.max(-3, Math.min(3, now + delta));
        prefs.edit().putInt(key, next).apply();
        Toast.makeText(this, delta > 0 ? "좋은 콜포인트로 기억했어" : "선호도를 낮춰서 기억했어", Toast.LENGTH_SHORT).show();
    }

    private void showNationwideApiResults(String query, GeoCenter center, List<CallpointCandidate> all) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(2), dp(4), dp(8));

        TextView explain = text("검색: " + query + " · 공식 네이버 지역검색 결과를 그대로 복사하지 않고, 장소 후보를 유형/거리/시간대/내 평가로 다시 점수화한 추천이야.", 11, MUTED, false);
        explain.setPadding(dp(8), dp(3), dp(8), dp(9));
        explain.setLineSpacing(0, 1.2f);
        body.addView(explain);

        int count = Math.min(8, all.size());
        for (int i = 0; i < count; i++) {
            CallpointCandidate c = all.get(i);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(11), dp(12), dp(11));
            item.setBackground(rounded(Color.rgb(35, 39, 47), 12));

            item.addView(text((i + 1) + ". " + c.name + "  " + starText(c.stars), 16, TEXT, true));
            TextView meta = text(String.format(Locale.KOREA, "검색 중심 약 %.1fkm · %s", c.distanceKm, c.tag), 12, ACCENT, true);
            meta.setPadding(0, dp(4), 0, 0);
            item.addView(meta);
            String detail = c.category + (c.address.isEmpty() ? "" : "\n" + c.address);
            TextView detailView = text(detail, 11, MUTED, false);
            detailView.setPadding(0, dp(3), 0, 0);
            detailView.setLineSpacing(0, 1.15f);
            item.addView(detailView);

            LinearLayout feedback = new LinearLayout(this);
            feedback.setOrientation(LinearLayout.HORIZONTAL);
            Button good = secondaryButton("👍 좋음");
            Button bad = secondaryButton("👎 별로");
            feedback.addView(good, weightLp(1));
            LinearLayout.LayoutParams blp = weightLp(1); blp.leftMargin = dp(6);
            feedback.addView(bad, blp);
            item.addView(feedback, topMargin(7));
            good.setOnClickListener(v -> saveCallpointFeedback(c, 1));
            bad.setOnClickListener(v -> saveCallpointFeedback(c, -1));

            Button nav = primaryButton("네이버지도 길찾기");
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, dp(44));
            nlp.topMargin = dp(7);
            item.addView(nav, nlp);
            nav.setOnClickListener(v -> openNaverRoute(new Hotspot(c.name, c.lat, c.lon, c.stars, c.tag)));

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) ilp.topMargin = dp(8);
            body.addView(item, ilp);
        }

        TextView note = text("※ 이 추천은 실시간 대리 호출량이 아니야. 네이버 공식 지역검색의 공개 업체/기관 후보에 우리 앱의 시간대·거리·유형·개인평가 점수를 적용한 참고용 추천이야.", 11, MUTED, false);
        note.setPadding(dp(8), dp(10), dp(8), 0);
        note.setLineSpacing(0, 1.2f);
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle(query + " · 전국 콜포인트 TOP " + count)
                .setView(scroll)
                .setNegativeButton("닫기", null)
                .show();
    }

    private void showModeledNationwideRecommendations(String query) {
        new Thread(() -> {
            GeoCenter center = geocodeQueryCenter(query);
            ArrayList<ModeledSuggestion> modeled = buildModeledSuggestions(query);
            runOnUiThread(() -> {
                LinearLayout body = new LinearLayout(this);
                body.setOrientation(LinearLayout.VERTICAL);
                body.setPadding(dp(4), dp(2), dp(4), dp(8));

                TextView explain = text("실제 장소 데이터를 긁어오지 않는 모방 추천 모드야. " + query + "의 위치와 현재 시간대를 기준으로 콜이 생기기 쉬운 장소 유형을 우선순위로 보여주고, 네이버지도에서 해당 유형의 실제 장소를 바로 검색해.", 11, MUTED, false);
                explain.setPadding(dp(8), dp(3), dp(8), dp(8));
                explain.setLineSpacing(0, 1.2f);
                body.addView(explain);

                for (int i = 0; i < modeled.size(); i++) {
                    ModeledSuggestion m = modeled.get(i);
                    LinearLayout item = new LinearLayout(this);
                    item.setOrientation(LinearLayout.VERTICAL);
                    item.setPadding(dp(12), dp(11), dp(12), dp(11));
                    item.setBackground(rounded(Color.rgb(35, 39, 47), 12));
                    item.addView(text((i + 1) + ". " + m.title + "  " + starText(m.stars), 16, TEXT, true));
                    TextView meta = text(m.tag + " · " + m.reason, 12, MUTED, false);
                    meta.setPadding(0, dp(4), 0, 0);
                    item.addView(meta);
                    Button map = primaryButton("네이버지도에서 실제 장소 보기");
                    LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, dp(44));
                    mlp.topMargin = dp(8);
                    item.addView(map, mlp);
                    map.setOnClickListener(v -> openNaverSearch(m.naverQuery));
                    LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
                    if (i > 0) ilp.topMargin = dp(8);
                    body.addView(item, ilp);
                }

                Button connect = secondaryButton("실제 장소 TOP 8을 보려면 네이버 API 연결");
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(46));
                clp.topMargin = dp(10);
                body.addView(connect, clp);
                connect.setOnClickListener(v -> showNaverApiSettings());

                ScrollView scroll = new ScrollView(this);
                scroll.addView(body);
                new AlertDialog.Builder(this)
                        .setTitle(query + " · 전국 모방 추천")
                        .setView(scroll)
                        .setNegativeButton("닫기", null)
                        .show();
            });
        }).start();
    }

    private ArrayList<ModeledSuggestion> buildModeledSuggestions(String query) {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        ArrayList<ModeledSuggestion> list = new ArrayList<>();
        list.add(new ModeledSuggestion(query + " 먹자·회식 상권", 5, "식당/회식", (h >= 17 && h <= 23) ? "지금 시간대 우선" : "저녁 수요형", query + " 맛집"));
        list.add(new ModeledSuggestion(query + " 술집·심야 상권", (h >= 20 || h <= 3) ? 5 : 4, "술집/심야", (h >= 20 || h <= 3) ? "지금 시간대 강점" : "밤 시간대 강점", query + " 술집"));
        list.add(new ModeledSuggestion(query + " 골프장 주변", 5, "골프/장거리", "라운딩 종료 뒤 이동 수요를 노리는 유형", query + " 골프장"));
        list.add(new ModeledSuggestion(query + " 호텔·리조트 주변", 4, "숙박/장거리", "저녁·야간 이동 후보", query + " 호텔 리조트"));
        list.add(new ModeledSuggestion(query + " 장례식장 주변", 4, "장례/이동수요", "시간대 영향이 비교적 적은 후보", query + " 장례식장"));
        list.add(new ModeledSuggestion(query + " 산업단지·퇴근축", (h >= 16 && h <= 21) ? 5 : 4, "산업/퇴근", (h >= 16 && h <= 21) ? "퇴근 시간대 우선" : "평일 저녁형", query + " 산업단지"));
        Collections.sort(list, (a, b) -> Integer.compare(b.stars, a.stars));
        if (list.size() > 5) return new ArrayList<>(list.subList(0, 5));
        return list;
    }

    private void openNaverSearch(String query) {
        try {
            Uri uri = Uri.parse("nmap://search").buildUpon()
                    .appendQueryParameter("query", query)
                    .appendQueryParameter("appname", getPackageName())
                    .build();
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setPackage("com.nhn.android.nmap");
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.nhn.android.nmap")));
            } catch (Exception ignored) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.nhn.android.nmap")));
            }
        }
    }

    private Target[] combineTargets(Target[]... groups) {
        int total = 0;
        for (Target[] group : groups) total += group.length;
        Target[] merged = new Target[total];
        int offset = 0;
        for (Target[] group : groups) {
            System.arraycopy(group, 0, merged, offset, group.length);
            offset += group.length;
        }
        return merged;
    }

    private void addSection(LinearLayout root, String title, String copyLabel, Target[] targets) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text(title, 18, TEXT, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        Button favoriteButton = new Button(this);
        favoriteButton.setAllCaps(false);
        favoriteButton.setTextSize(20);
        favoriteButton.setPadding(0, 0, 0, 0);
        favoriteButton.setMinWidth(0);
        favoriteButton.setTextColor(ACCENT);
        favoriteButton.setBackgroundColor(Color.TRANSPARENT);
        titleRow.addView(favoriteButton, new LinearLayout.LayoutParams(dp(44), dp(40)));
        c.addView(titleRow);
        TextView helper = text("자동 계산 후 필요한 금액만 직접 고쳐서 복사", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        int savedSectionDelta = prefs.getInt(sectionPrefKey(title), 0);

        LinearLayout adjustRow = new LinearLayout(this);
        adjustRow.setOrientation(LinearLayout.HORIZONTAL);
        adjustRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView adjustLabel = text("이 카드 보정", 12, MUTED, true);
        adjustRow.addView(adjustLabel, new LinearLayout.LayoutParams(0, dp(42), 1.3f));
        Button minus = smallAdjustButton("−");
        adjustRow.addView(minus, new LinearLayout.LayoutParams(dp(48), dp(40)));
        TextView adjustValue = text(formatDelta(savedSectionDelta), 14, ACCENT, true);
        adjustValue.setGravity(Gravity.CENTER);
        adjustRow.addView(adjustValue, new LinearLayout.LayoutParams(0, dp(40), 1f));
        Button plus = smallAdjustButton("+");
        adjustRow.addView(plus, new LinearLayout.LayoutParams(dp(48), dp(40)));
        LinearLayout.LayoutParams adjustLp = new LinearLayout.LayoutParams(-1, dp(44));
        adjustLp.topMargin = dp(6);
        c.addView(adjustRow, adjustLp);

        EditText edit = new EditText(this);
        edit.setTextColor(TEXT);
        edit.setHintTextColor(MUTED);
        edit.setTextSize(14);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setPadding(dp(10), dp(10), dp(10), dp(10));
        edit.setMinLines(3);
        edit.setMaxLines(8);
        edit.setSingleLine(false);
        edit.setHorizontallyScrolling(false);
        edit.setBackground(rounded(Color.rgb(35, 39, 47), 12));
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(-1, -2);
        editLp.topMargin = dp(8);
        c.addView(edit, editLp);

        Button copy = primaryButton(copyLabel);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(-1, dp(46));
        copyLp.topMargin = dp(10);
        c.addView(copy, copyLp);
        copy.setOnClickListener(v -> copyText(title, edit.getText().toString()));

        LinearLayout slot = new LinearLayout(this);
        slot.setOrientation(LinearLayout.VERTICAL);
        root.addView(slot, topMargin(12));

        boolean favorite = prefs.getBoolean(favoritePrefKey(title), false);
        Section section = new Section(title, edit, targets, savedSectionDelta, adjustValue, c, slot, favoriteButton, favorite);
        sections.put(title, section);
        minus.setOnClickListener(v -> adjustSection(section, -1));
        plus.setOnClickListener(v -> adjustSection(section, 1));
        favoriteButton.setOnClickListener(v -> toggleFavorite(section));
        placeSectionCard(section);
    }

    private void addAdjustmentCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("단가 보정 · 1천원씩 즉시 조정", 17, TEXT, true));

        returnDeltaText = addAdjustmentRow(c, "복귀콜", "return");
        runDeltaText = addAdjustmentRow(c, "달려콜", "run");
        happyDeltaText = addAdjustmentRow(c, "해피타임", "happy");

        Button reset = new Button(this);
        reset.setAllCaps(false);
        reset.setText("보정값 기본으로 복원 (-5 / 0 / +5)");
        reset.setTextSize(13);
        reset.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reset.setTextColor(TEXT);
        reset.setBackground(rounded(Color.rgb(42,47,56), 12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48));
        rp.topMargin = dp(10);
        c.addView(reset, rp);
        reset.setOnClickListener(v -> {
            returnDeltaK = -5; runDeltaK = 0; happyDeltaK = 5;
            saveAdjustments();
            modeDeltaK = deltaForMode(currentMode);
            refreshModeUi();
            recalculateAll();
            Toast.makeText(this, "보정값을 기본값으로 복원했어", Toast.LENGTH_SHORT).show();
        });

        root.addView(c, topMargin(12));
    }

    private TextView addAdjustmentRow(LinearLayout card, String label, String mode) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 14, TEXT, true);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(50), 1.2f));

        Button minus = smallAdjustButton("−");
        row.addView(minus, new LinearLayout.LayoutParams(dp(54), dp(46)));

        TextView value = text(formatDelta(deltaForMode(mode)), 16, ACCENT, true);
        value.setGravity(Gravity.CENTER);
        row.addView(value, new LinearLayout.LayoutParams(0, dp(46), 1f));

        Button plus = smallAdjustButton("+");
        row.addView(plus, new LinearLayout.LayoutParams(dp(54), dp(46)));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(54));
        rowLp.topMargin = dp(4);
        card.addView(row, rowLp);

        minus.setOnClickListener(v -> adjustMode(mode, -1));
        plus.setOnClickListener(v -> adjustMode(mode, 1));
        return value;
    }

    private Button smallAdjustButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(20);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(TEXT);
        b.setPadding(0,0,0,0);
        b.setBackground(rounded(Color.rgb(42,47,56), 12));
        return b;
    }

    private void adjustMode(String mode, int step) {
        if ("return".equals(mode)) returnDeltaK = clampDelta(returnDeltaK + step);
        else if ("happy".equals(mode)) happyDeltaK = clampDelta(happyDeltaK + step);
        else runDeltaK = clampDelta(runDeltaK + step);
        saveAdjustments();
        if (mode.equals(currentMode)) modeDeltaK = deltaForMode(mode);
        refreshModeUi();
        recalculateAll();
    }

    private int clampDelta(int value) { return Math.max(-20, Math.min(20, value)); }

    private void saveAdjustments() {
        prefs.edit().putInt("returnK", returnDeltaK).putInt("runK", runDeltaK).putInt("happyK", happyDeltaK).apply();
    }

    private int deltaForMode(String mode) {
        if ("return".equals(mode)) return returnDeltaK;
        if ("happy".equals(mode)) return happyDeltaK;
        return runDeltaK;
    }

    private String formatDelta(int value) {
        return value == 0 ? "기준" : (value > 0 ? "+" : "") + value + "천";
    }

    private void setMode(String mode) {
        currentMode = mode;
        prefs.edit().putString("currentMode", currentMode).apply();
        modeDeltaK = deltaForMode(mode);
        refreshModeUi();
        recalculateAll();
        Toast.makeText(this, "전 권역을 " + modeName() + " 기준으로 다시 계산했어", Toast.LENGTH_SHORT).show();
    }

    private void refreshModeUi() {
        returnButton.setBackground(rounded("return".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        runButton.setBackground(rounded("run".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        happyButton.setBackground(rounded("happy".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        returnButton.setTextColor("return".equals(currentMode) ? Color.BLACK : TEXT);
        runButton.setTextColor("run".equals(currentMode) ? Color.BLACK : TEXT);
        happyButton.setTextColor("happy".equals(currentMode) ? Color.BLACK : TEXT);
        returnButton.setText("복귀콜\n" + formatDelta(returnDeltaK));
        runButton.setText("달려콜\n" + formatDelta(runDeltaK));
        happyButton.setText("해피타임\n" + formatDelta(happyDeltaK));
        if (returnDeltaText != null) returnDeltaText.setText(formatDelta(returnDeltaK));
        if (runDeltaText != null) runDeltaText.setText(formatDelta(runDeltaK));
        if (happyDeltaText != null) happyDeltaText.setText(formatDelta(happyDeltaK));
        modeStateText.setText("현재: " + modeName() + " · " + formatDelta(modeDeltaK));
    }

    private String modeName() {
        if ("return".equals(currentMode)) return "복귀콜";
        if ("happy".equals(currentMode)) return "해피타임";
        return "달려콜";
    }

    private void addTimePresetCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("시간대 프리셋", 17, TEXT, true));
        TextView helper = text("한 번 선택하면 전 권역에 시간대 보정이 같이 적용돼", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        weekdayPresetButton = compactPresetButton();
        friSatPresetButton = compactPresetButton();
        lateNightPresetButton = compactPresetButton();
        dawnPresetButton = compactPresetButton();
        buttons.addView(weekdayPresetButton, weightLp(1));
        LinearLayout.LayoutParams p2 = weightLp(1); p2.leftMargin = dp(4);
        buttons.addView(friSatPresetButton, p2);
        LinearLayout.LayoutParams p3 = weightLp(1); p3.leftMargin = dp(4);
        buttons.addView(lateNightPresetButton, p3);
        LinearLayout.LayoutParams p4 = weightLp(1); p4.leftMargin = dp(4);
        buttons.addView(dawnPresetButton, p4);
        c.addView(buttons, topMargin(8));

        presetStateText = text("", 12, ACCENT, true);
        c.addView(presetStateText, topMargin(6));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text("선택 프리셋 보정", 13, TEXT, true), new LinearLayout.LayoutParams(0, dp(46), 1.5f));
        Button minus = smallAdjustButton("−");
        row.addView(minus, new LinearLayout.LayoutParams(dp(52), dp(42)));
        presetAdjustValueText = text(formatDelta(presetDeltaK), 15, ACCENT, true);
        presetAdjustValueText.setGravity(Gravity.CENTER);
        row.addView(presetAdjustValueText, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Button plus = smallAdjustButton("+");
        row.addView(plus, new LinearLayout.LayoutParams(dp(52), dp(42)));
        c.addView(row, topMargin(6));

        Button reset = new Button(this);
        reset.setAllCaps(false);
        reset.setText("시간대 기본값 복원 (0 / +2 / +3 / +1)");
        reset.setTextSize(12);
        reset.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reset.setTextColor(TEXT);
        reset.setBackground(rounded(Color.rgb(42,47,56), 12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(44));
        rp.topMargin = dp(8);
        c.addView(reset, rp);

        weekdayPresetButton.setOnClickListener(v -> setPreset("weekday"));
        friSatPresetButton.setOnClickListener(v -> setPreset("frisat"));
        lateNightPresetButton.setOnClickListener(v -> setPreset("latenight"));
        dawnPresetButton.setOnClickListener(v -> setPreset("dawn"));
        minus.setOnClickListener(v -> adjustCurrentPreset(-1));
        plus.setOnClickListener(v -> adjustCurrentPreset(1));
        reset.setOnClickListener(v -> {
            weekdayPresetK = 0; friSatPresetK = 2; lateNightPresetK = 3; dawnPresetK = 1;
            presetDeltaK = deltaForPreset(currentPreset);
            savePresetSettings();
            refreshPresetUi();
            recalculateAll();
            Toast.makeText(this, "시간대 프리셋을 기본값으로 복원했어", Toast.LENGTH_SHORT).show();
        });

        refreshPresetUi();
        root.addView(c, topMargin(12));
    }

    private Button compactPresetButton() {
        Button b = modeButton("");
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setPadding(dp(2), dp(3), dp(2), dp(3));
        return b;
    }

    private void setPreset(String preset) {
        currentPreset = preset;
        presetDeltaK = deltaForPreset(preset);
        savePresetSettings();
        refreshPresetUi();
        recalculateAll();
        Toast.makeText(this, presetName(preset) + " 프리셋 적용", Toast.LENGTH_SHORT).show();
    }

    private void adjustCurrentPreset(int step) {
        if ("frisat".equals(currentPreset)) friSatPresetK = clampDelta(friSatPresetK + step);
        else if ("latenight".equals(currentPreset)) lateNightPresetK = clampDelta(lateNightPresetK + step);
        else if ("dawn".equals(currentPreset)) dawnPresetK = clampDelta(dawnPresetK + step);
        else weekdayPresetK = clampDelta(weekdayPresetK + step);
        presetDeltaK = deltaForPreset(currentPreset);
        savePresetSettings();
        refreshPresetUi();
        recalculateAll();
    }

    private int deltaForPreset(String preset) {
        if ("frisat".equals(preset)) return friSatPresetK;
        if ("latenight".equals(preset)) return lateNightPresetK;
        if ("dawn".equals(preset)) return dawnPresetK;
        return weekdayPresetK;
    }

    private String presetName(String preset) {
        if ("frisat".equals(preset)) return "금토";
        if ("latenight".equals(preset)) return "심야";
        if ("dawn".equals(preset)) return "새벽";
        return "평일";
    }

    private void savePresetSettings() {
        prefs.edit()
                .putString("currentPreset", currentPreset)
                .putInt("preset_weekdayK", weekdayPresetK)
                .putInt("preset_frisatK", friSatPresetK)
                .putInt("preset_latenightK", lateNightPresetK)
                .putInt("preset_dawnK", dawnPresetK)
                .apply();
    }

    private void refreshPresetUi() {
        if (weekdayPresetButton == null) return;
        updatePresetButton(weekdayPresetButton, "weekday", "평일", weekdayPresetK);
        updatePresetButton(friSatPresetButton, "frisat", "금토", friSatPresetK);
        updatePresetButton(lateNightPresetButton, "latenight", "심야", lateNightPresetK);
        updatePresetButton(dawnPresetButton, "dawn", "새벽", dawnPresetK);
        presetDeltaK = deltaForPreset(currentPreset);
        if (presetAdjustValueText != null) presetAdjustValueText.setText(formatDelta(presetDeltaK));
        if (presetStateText != null) presetStateText.setText("현재: " + presetName(currentPreset) + " · " + formatDelta(presetDeltaK));
    }

    private void updatePresetButton(Button b, String id, String label, int value) {
        boolean selected = id.equals(currentPreset);
        b.setBackground(rounded(selected ? ACCENT : Color.rgb(42,47,56), 12));
        b.setTextColor(selected ? Color.BLACK : TEXT);
        b.setText(label + "\n" + formatDelta(value));
    }

    private void adjustSection(Section section, int step) {
        section.deltaK = clampDelta(section.deltaK + step);
        prefs.edit().putInt(sectionPrefKey(section.title), section.deltaK).apply();
        section.deltaView.setText(formatDelta(section.deltaK));
        recalculateSection(section);
    }

    private String sectionPrefKey(String title) {
        return "section_delta_" + title;
    }

    private void recalculateSection(Section section) {
        section.edit.setText(buildOneLine(section));
    }


    private void addFloatingCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("미니 플로팅", 17, TEXT, true));
        TextView helper = text("다른 기사앱 위에서 모드·시간대 전환, 최근 가격표 재복사를 빠르게", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);
        floatingToggleButton = primaryButton("미니 플로팅 켜기");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        c.addView(floatingToggleButton, lp);
        floatingToggleButton.setOnClickListener(v -> toggleFloating());
        root.addView(c, topMargin(12));
        refreshFloatingUi();
    }

    private void toggleFloating() {
        boolean enabled = prefs.getBoolean("floating_enabled", false);
        if (enabled) {
            stopService(new Intent(this, FloatingService.class));
            prefs.edit().putBoolean("floating_enabled", false).apply();
            refreshFloatingUi();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            overlayRequestPending = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            Toast.makeText(this, "다른 앱 위에 표시를 허용한 뒤 돌아오면 자동으로 켤게", Toast.LENGTH_LONG).show();
            return;
        }
        startFloatingService();
    }

    private void startFloatingService() {
        try {
            startForegroundService(new Intent(this, FloatingService.class));
            prefs.edit().putBoolean("floating_enabled", true).apply();
            refreshFloatingUi();
            Toast.makeText(this, "미니 플로팅을 켰어", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            prefs.edit().putBoolean("floating_enabled", false).apply();
            refreshFloatingUi();
            Toast.makeText(this, "플로팅을 시작하지 못했어", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshFloatingUi() {
        if (floatingToggleButton == null) return;
        boolean enabled = prefs != null && prefs.getBoolean("floating_enabled", false) && Settings.canDrawOverlays(this);
        floatingToggleButton.setText(enabled ? "미니 플로팅 끄기" : "미니 플로팅 켜기");
        floatingToggleButton.setBackground(rounded(enabled ? Color.rgb(89, 185, 120) : ACCENT, 12));
    }

    private void addRecentUsageCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("최근 사용", 17, TEXT, true));
        TextView helper = text("최근 복사 20개 저장 · 당시 상태 복원 또는 가격표 재복사", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        recentPreviewContainer = new LinearLayout(this);
        recentPreviewContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams recentLp = new LinearLayout.LayoutParams(-1, -2);
        recentLp.topMargin = dp(8);
        c.addView(recentPreviewContainer, recentLp);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button showAll = primaryButton("최근 20개 보기");
        Button clear = new Button(this);
        clear.setAllCaps(false);
        clear.setText("기록 지우기");
        clear.setTextSize(12);
        clear.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        clear.setTextColor(TEXT);
        clear.setBackground(rounded(Color.rgb(42,47,56), 12));
        buttons.addView(showAll, new LinearLayout.LayoutParams(0, dp(44), 1.5f));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(44), 1f); cp.leftMargin = dp(6);
        buttons.addView(clear, cp);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(44)); blp.topMargin = dp(8);
        c.addView(buttons, blp);
        showAll.setOnClickListener(v -> showRecentDialog());
        clear.setOnClickListener(v -> {
            prefs.edit().remove("recent_usage_json").apply();
            refreshRecentPreview();
            Toast.makeText(this, "최근 사용 기록을 지웠어", Toast.LENGTH_SHORT).show();
        });
        root.addView(c, topMargin(12));
        refreshRecentPreview();
    }

    private void addRecentRecord(String label, String value) {
        JSONArray old = loadRecentArray();
        JSONArray next = new JSONArray();
        try {
            JSONObject item = new JSONObject();
            item.put("time", System.currentTimeMillis());
            item.put("label", label);
            item.put("value", value);
            item.put("mode", modeName());
            item.put("modeId", currentMode);
            item.put("modeK", modeDeltaK);
            item.put("preset", presetName(currentPreset));
            item.put("presetId", currentPreset);
            item.put("presetK", presetDeltaK);
            Section section = sections.get(label);
            item.put("cardDelta", section == null ? 0 : section.deltaK);
            next.put(item);
            for (int i = 0; i < old.length() && next.length() < 20; i++) next.put(old.getJSONObject(i));
        } catch (Exception ignored) {}
        prefs.edit().putString("recent_usage_json", next.toString()).apply();
        refreshRecentPreview();
    }

    private JSONArray loadRecentArray() {
        try { return new JSONArray(prefs.getString("recent_usage_json", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void refreshRecentPreview() {
        if (recentPreviewContainer == null || prefs == null) return;
        recentPreviewContainer.removeAllViews();
        JSONArray arr = loadRecentArray();
        if (arr.length() == 0) {
            TextView empty = text("아직 복사한 가격표가 없어", 12, MUTED, false);
            empty.setPadding(0, dp(6), 0, dp(4));
            recentPreviewContainer.addView(empty);
            return;
        }
        int count = Math.min(3, arr.length());
        for (int i = 0; i < count; i++) {
            try {
                JSONObject o = arr.getJSONObject(i);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                String summary = formatRecentSummary(o);
                TextView t = text(summary, 12, TEXT, false);
                row.addView(t, new LinearLayout.LayoutParams(0, dp(44), 1f));
                Button again = new Button(this);
                again.setAllCaps(false); again.setText("상태복원"); again.setTextSize(10); again.setTextColor(Color.BLACK);
                again.setBackground(rounded(ACCENT, 10));
                again.setOnClickListener(v -> restoreRecentState(o));
                row.addView(again, new LinearLayout.LayoutParams(dp(82), dp(38)));
                recentPreviewContainer.addView(row);
            } catch (Exception ignored) {}
        }
    }

    private String formatRecentSummary(JSONObject o) {
        long time = o.optLong("time", 0L);
        java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("HH:mm", Locale.KOREA);
        String hhmm = time > 0 ? fmt.format(new java.util.Date(time)) : "--:--";
        String label = o.optString("label", "최근");
        String mode = o.optString("mode", "");
        String preset = o.optString("preset", "");
        int cardDelta = o.optInt("cardDelta", 0);
        return hhmm + " · " + label + "\n" + mode + " / " + preset + (cardDelta == 0 ? "" : " / 카드 " + formatDelta(cardDelta));
    }

    private void showRecentDialog() {
        JSONArray arr = loadRecentArray();
        if (arr.length() == 0) {
            Toast.makeText(this, "최근 사용 기록이 없어", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] items = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            items[i] = o == null ? "최근 기록" : formatRecentSummary(o).replace("\n", " · ");
        }
        new AlertDialog.Builder(this)
                .setTitle("최근 사용 · 최대 20개")
                .setItems(items, (dialog, which) -> {
                    JSONObject o = arr.optJSONObject(which);
                    if (o != null) showRecentActions(o);
                })
                .setNegativeButton("닫기", null)
                .show();
    }

    private void showRecentActions(JSONObject o) {
        String[] actions = new String[]{"당시 상태 복원", "그때 가격표 그대로 재복사"};
        new AlertDialog.Builder(this)
                .setTitle(o.optString("label", "최근 사용"))
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) restoreRecentState(o);
                    else recopyRecentExactly(o);
                })
                .setNegativeButton("닫기", null)
                .show();
    }

    private void recopyRecentExactly(JSONObject o) {
        String label = o.optString("label", "최근");
        String value = o.optString("value", "");
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
        prefs.edit().putString("lastCopiedLabel", label).putString("lastCopiedValue", value).apply();
        try {
            JSONArray old = loadRecentArray();
            JSONArray next = new JSONArray();
            JSONObject clone = new JSONObject(o.toString());
            clone.put("time", System.currentTimeMillis());
            next.put(clone);
            for (int i = 0; i < old.length() && next.length() < 20; i++) next.put(old.getJSONObject(i));
            prefs.edit().putString("recent_usage_json", next.toString()).apply();
            refreshRecentPreview();
        } catch (Exception ignored) {}
        Toast.makeText(this, label + " 그때 가격표를 그대로 재복사했어", Toast.LENGTH_SHORT).show();
    }

    private void restoreRecentState(JSONObject o) {
        String modeId = o.optString("modeId", modeIdFromName(o.optString("mode", "달려콜")));
        String presetId = o.optString("presetId", presetIdFromName(o.optString("preset", "평일")));
        int savedModeK = o.has("modeK") ? o.optInt("modeK", deltaForMode(modeId)) : deltaForMode(modeId);
        int savedPresetK = o.has("presetK") ? o.optInt("presetK", deltaForPreset(presetId)) : deltaForPreset(presetId);
        int savedCardK = o.optInt("cardDelta", 0);
        String label = o.optString("label", "");

        if ("return".equals(modeId)) returnDeltaK = clampDelta(savedModeK);
        else if ("happy".equals(modeId)) happyDeltaK = clampDelta(savedModeK);
        else runDeltaK = clampDelta(savedModeK);
        currentMode = modeId;
        modeDeltaK = deltaForMode(currentMode);

        if ("frisat".equals(presetId)) friSatPresetK = clampDelta(savedPresetK);
        else if ("latenight".equals(presetId)) lateNightPresetK = clampDelta(savedPresetK);
        else if ("dawn".equals(presetId)) dawnPresetK = clampDelta(savedPresetK);
        else weekdayPresetK = clampDelta(savedPresetK);
        currentPreset = presetId;
        presetDeltaK = deltaForPreset(currentPreset);

        Section section = sections.get(label);
        if (section != null) {
            section.deltaK = clampDelta(savedCardK);
            section.deltaView.setText(formatDelta(section.deltaK));
            prefs.edit().putInt(sectionPrefKey(section.title), section.deltaK).apply();
        }

        saveAdjustments();
        savePresetSettings();
        prefs.edit().putString("currentMode", currentMode).apply();
        refreshModeUi();
        refreshPresetUi();
        recalculateAll();
        Toast.makeText(this, "당시 운행모드 · 시간대 · 카드보정을 복원했어", Toast.LENGTH_SHORT).show();
    }

    private String modeIdFromName(String name) {
        if (name.contains("복귀")) return "return";
        if (name.contains("해피")) return "happy";
        return "run";
    }

    private String presetIdFromName(String name) {
        if (name.contains("금토")) return "frisat";
        if (name.contains("심야")) return "latenight";
        if (name.contains("새벽")) return "dawn";
        return "weekday";
    }

    private void addBackupRestoreCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("설정 백업 · 복원", 17, TEXT, true));
        TextView helper = text("프리셋 · 카드보정 · 즐겨찾기 · 최근사용 · 플로팅 설정을 파일 하나로 보관", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button backup = primaryButton("백업 파일 저장");
        Button restore = new Button(this);
        restore.setAllCaps(false);
        restore.setText("백업 불러오기");
        restore.setTextSize(13);
        restore.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        restore.setTextColor(TEXT);
        restore.setBackground(rounded(Color.rgb(42,47,56), 12));
        row.addView(backup, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, dp(46), 1f); rp.leftMargin = dp(6);
        row.addView(restore, rp);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(46)); rowLp.topMargin = dp(10);
        c.addView(row, rowLp);
        backup.setOnClickListener(v -> createBackupFile());
        restore.setOnClickListener(v -> chooseBackupFile());
        root.addView(c, topMargin(12));
    }

    private void createBackupFile() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "SeoulReturnCall_backup_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmm", Locale.KOREA).format(new java.util.Date()) + ".json");
        startActivityForResult(intent, REQ_BACKUP_CREATE);
    }

    private void chooseBackupFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_BACKUP_OPEN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_BACKUP_CREATE) writeBackupToUri(uri);
        else if (requestCode == REQ_BACKUP_OPEN) confirmRestoreFromUri(uri);
    }

    private void writeBackupToUri(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new Exception("output stream");
            JSONObject root = new JSONObject();
            root.put("app", "SeoulReturnCall");
            root.put("schema", 1);
            root.put("version", "2.1.0");
            root.put("createdAt", System.currentTimeMillis());
            JSONObject all = new JSONObject();
            for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
                Object value = e.getValue();
                JSONObject item = new JSONObject();
                if (value instanceof String) { item.put("type", "string"); item.put("value", value); }
                else if (value instanceof Integer) { item.put("type", "int"); item.put("value", value); }
                else if (value instanceof Long) { item.put("type", "long"); item.put("value", value); }
                else if (value instanceof Float) { item.put("type", "float"); item.put("value", ((Float) value).doubleValue()); }
                else if (value instanceof Boolean) { item.put("type", "boolean"); item.put("value", value); }
                else if (value instanceof Set) {
                    item.put("type", "stringSet");
                    JSONArray a = new JSONArray();
                    for (Object v : (Set<?>) value) if (v != null) a.put(String.valueOf(v));
                    item.put("value", a);
                } else continue;
                all.put(e.getKey(), item);
            }
            root.put("preferences", all);
            out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "설정 백업 파일을 저장했어", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "백업 저장에 실패했어", Toast.LENGTH_LONG).show();
        }
    }

    private void confirmRestoreFromUri(Uri uri) {
        new AlertDialog.Builder(this)
                .setTitle("백업 복원")
                .setMessage("현재 설정을 백업 파일의 설정으로 바꿀까? 복원 뒤 앱 화면을 다시 불러와.")
                .setPositiveButton("복원", (d, w) -> restoreBackupFromUri(uri))
                .setNegativeButton("취소", null)
                .show();
    }

    private void restoreBackupFromUri(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("input stream");
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[4096];
            int n;
            while ((n = in.read(bytes)) > 0) buffer.write(bytes, 0, n);
            JSONObject root = new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            if (!"SeoulReturnCall".equals(root.optString("app"))) throw new Exception("wrong backup");
            JSONObject all = root.getJSONObject("preferences");
            SharedPreferences.Editor editor = prefs.edit().clear();
            java.util.Iterator<String> keys = all.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject item = all.getJSONObject(key);
                String type = item.optString("type");
                if ("string".equals(type)) editor.putString(key, item.optString("value", ""));
                else if ("int".equals(type)) editor.putInt(key, item.optInt("value", 0));
                else if ("long".equals(type)) editor.putLong(key, item.optLong("value", 0L));
                else if ("float".equals(type)) editor.putFloat(key, (float) item.optDouble("value", 0.0));
                else if ("boolean".equals(type)) editor.putBoolean(key, item.optBoolean("value", false));
                else if ("stringSet".equals(type)) {
                    JSONArray a = item.optJSONArray("value");
                    java.util.HashSet<String> set = new java.util.HashSet<>();
                    if (a != null) for (int i = 0; i < a.length(); i++) set.add(a.optString(i));
                    editor.putStringSet(key, set);
                }
            }
            editor.commit();
            syncFloatingAfterRestore();
            Toast.makeText(this, "백업을 복원했어", Toast.LENGTH_SHORT).show();
            recreate();
        } catch (Exception e) {
            Toast.makeText(this, "백업 파일을 읽지 못했어", Toast.LENGTH_LONG).show();
        }
    }

    private void syncFloatingAfterRestore() {
        boolean enabled = prefs.getBoolean("floating_enabled", false);
        if (!enabled || !Settings.canDrawOverlays(this)) {
            stopService(new Intent(this, FloatingService.class));
            if (!Settings.canDrawOverlays(this)) prefs.edit().putBoolean("floating_enabled", false).apply();
            return;
        }
        try {
            startForegroundService(new Intent(this, FloatingService.class));
        } catch (Exception ignored) {}
    }

    private String favoritePrefKey(String title) { return "favorite_" + title; }

    private void toggleFavorite(Section section) {
        section.favorite = !section.favorite;
        prefs.edit().putBoolean(favoritePrefKey(section.title), section.favorite).apply();
        placeSectionCard(section);
        Toast.makeText(this, section.favorite ? "즐겨찾기 상단에 고정했어" : "즐겨찾기에서 뺐어", Toast.LENGTH_SHORT).show();
    }

    private void placeSectionCard(Section section) {
        if (section.cardView.getParent() instanceof android.view.ViewGroup) {
            ((android.view.ViewGroup) section.cardView.getParent()).removeView(section.cardView);
        }
        section.favoriteButton.setText(section.favorite ? "★" : "☆");
        if (section.favorite && favoritesContainer != null) {
            section.homeSlot.setVisibility(View.GONE);
            favoritesContainer.addView(section.cardView, topMargin(8));
        } else {
            section.homeSlot.setVisibility(View.VISIBLE);
            section.homeSlot.addView(section.cardView);
        }
        refreshFavoritesVisibility();
    }

    private void refreshFavoritesVisibility() {
        if (favoritesContainer == null || favoritesHeader == null) return;
        boolean any = false;
        for (Section s : sections.values()) if (s.favorite) { any = true; break; }
        favoritesContainer.setVisibility(any ? View.VISIBLE : View.GONE);
        favoritesHeader.setVisibility(any ? View.VISIBLE : View.GONE);
    }

    private void requestCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        fetchLocation();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocation();
        } else {
            Toast.makeText(this, "위치 권한이 필요해", Toast.LENGTH_SHORT).show();
        }
    }

    private void fetchLocation() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        try {
            Location gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (gps != null) best = gps;
            if (net != null && (best == null || net.getTime() > best.getTime())) best = net;
        } catch (SecurityException ignored) {}

        if (best != null) useLocation(best, false);

        LocationListener listener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                useLocation(location, true);
                try { lm.removeUpdates(this); } catch (SecurityException ignored) {}
            }
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
        };

        try {
            boolean requested = false;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
                requested = true;
            }
            if (!requested && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener);
                requested = true;
            }
            if (!requested && best == null) Toast.makeText(this, "휴대폰 위치 서비스를 켜줘", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "GPS 위치를 가져오지 못했어", Toast.LENGTH_SHORT).show();
        }
    }

    private void useLocation(Location location, boolean fresh) {
        currentLat = location.getLatitude();
        currentLon = location.getLongitude();
        prefs.edit()
                .putLong("lastLatBits", Double.doubleToRawLongBits(currentLat))
                .putLong("lastLonBits", Double.doubleToRawLongBits(currentLon))
                .apply();
        String gpsLabel = String.format(Locale.KOREA, "GPS %.5f, %.5f%s", currentLat, currentLon, fresh ? " · 최신" : "");
        if (locationText != null) locationText.setText(gpsLabel);
        if (callziroLocationText != null) callziroLocationText.setText(gpsLabel);
        recalculateAll();
        reverseGeocode(currentLat, currentLon);
        if (fresh) Toast.makeText(this, "전 권역 계산 완료", Toast.LENGTH_SHORT).show();
    }

    private void reverseGeocode(double lat, double lon) {
        new Thread(() -> {
            try {
                Geocoder geocoder = new Geocoder(this, Locale.KOREA);
                List<Address> list = geocoder.getFromLocation(lat, lon, 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    String area = clean(a.getSubLocality());
                    String feature = clean(a.getFeatureName());
                    String locality = clean(a.getLocality());
                    String label = "";
                    if (!area.isEmpty()) label = area;
                    if (!feature.isEmpty() && !feature.equals(area)) label += (label.isEmpty() ? "" : " ") + feature;
                    if (label.isEmpty()) label = locality;
                    if (!label.isEmpty()) {
                        String finalLabel = label + String.format(Locale.KOREA, " · %.5f, %.5f", lat, lon);
                        runOnUiThread(() -> {
                            if (locationText != null) locationText.setText(finalLabel);
                            if (callziroLocationText != null) callziroLocationText.setText(finalLabel);
                        });
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private String clean(String s) { return s == null ? "" : s.trim(); }

    private void recalculateAll() {
        for (Map.Entry<String, Section> e : sections.entrySet()) {
            recalculateSection(e.getValue());
        }
    }

    private String buildOneLine(Section section) {
        Target[] targets = section.targets;
        List<Result> results = new ArrayList<>();
        for (Target t : targets) {
            double refRoad = haversineKm(REF_LAT, REF_LON, t.lat, t.lon) * ROAD_FACTOR;
            double nowRoad = haversineKm(currentLat, currentLon, t.lat, t.lon) * ROAD_FACTOR;
            double deltaKm = nowRoad - refRoad;
            int adjustedK = t.anchorK
                    + (int) Math.round((deltaKm * WON_PER_KM_DELTA) / 1000.0)
                    + modeDeltaK + presetDeltaK + section.deltaK;
            adjustedK = Math.max(10, adjustedK);
            results.add(new Result(t.name, adjustedK));
        }
        Collections.sort(results, Comparator.comparingInt((Result r) -> r.priceK).thenComparing(r -> r.name));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < results.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(results.get(i).name).append('#').append(results.get(i).priceK);
        }
        return sb.toString();
    }

    private void copyText(String label, String value) {
        copyRaw(label, value, true);
    }

    private void copyRaw(String label, String value, boolean addRecent) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
        prefs.edit().putString("lastCopiedLabel", label).putString("lastCopiedValue", value).apply();
        if (addRecent) addRecentRecord(label, value);
        Toast.makeText(this, label + " 가격표 복사 완료", Toast.LENGTH_SHORT).show();
    }

    private double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0088;
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1);
        double dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(rounded(CARD, 16));
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button primaryButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(48, 40, 25));
        b.setBackground(rounded(ACCENT, 12));
        return b;
    }

    private Button secondaryButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(TEXT);
        b.setPadding(dp(4), dp(4), dp(4), dp(4));
        b.setBackground(rounded(SOFT, 12));
        return b;
    }

    private Button modeButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(3), dp(4), dp(3), dp(4));
        return b;
    }

    private LinearLayout.LayoutParams topMargin(int dpVal) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(dpVal);
        return p;
    }

    private LinearLayout.LayoutParams weightLp(float weight) {
        return new LinearLayout.LayoutParams(0, dp(56), weight);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        // Keep older screen components visually consistent with the new theme.
        if (color == Color.rgb(35, 39, 47) || color == Color.rgb(42, 47, 56)) {
            color = SOFT;
        }
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (color == CARD || color == SOFT) {
            g.setStroke(dp(1), BORDER);
        }
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static Hotspot h(String name, double lat, double lon, int stars, String tag) {
        return new Hotspot(name, lat, lon, stars, tag);
    }

    private static Target t(String name, double lat, double lon, int anchorK) {
        return new Target(name, lat, lon, anchorK);
    }

    static class Hotspot {
        String name; double lat, lon; int stars; String tag;
        Hotspot(String name, double lat, double lon, int stars, String tag) {
            this.name = name; this.lat = lat; this.lon = lon; this.stars = stars; this.tag = tag;
        }
    }

    static class HotspotRank {
        Hotspot hotspot; double roadKm, score;
        HotspotRank(Hotspot hotspot, double roadKm, double score) {
            this.hotspot = hotspot; this.roadKm = roadKm; this.score = score;
        }
    }

    static class GeoCenter {
        double lat, lon; String label;
        GeoCenter(double lat, double lon, String label) { this.lat = lat; this.lon = lon; this.label = label; }
    }

    static class SearchSpec {
        String key, keyword, tag; double baseStars;
        SearchSpec(String key, String keyword, double baseStars, String tag) {
            this.key = key; this.keyword = keyword; this.baseStars = baseStars; this.tag = tag;
        }
    }

    static class CallpointCandidate {
        String name, tag, category, address, sourceQuery;
        double lat, lon, distanceKm, score; int stars;
        CallpointCandidate(String name, double lat, double lon, int stars, String tag, String category,
                           String address, double distanceKm, double score, String sourceQuery) {
            this.name = name; this.lat = lat; this.lon = lon; this.stars = stars; this.tag = tag;
            this.category = category; this.address = address; this.distanceKm = distanceKm; this.score = score; this.sourceQuery = sourceQuery;
        }
    }

    static class ModeledSuggestion {
        String title, tag, reason, naverQuery; int stars;
        ModeledSuggestion(String title, int stars, String tag, String reason, String naverQuery) {
            this.title = title; this.stars = stars; this.tag = tag; this.reason = reason; this.naverQuery = naverQuery;
        }
    }


    class CallziroRadarView extends View {
        final ArrayList<CallziroAdapter.Point> points;
        final double centerLat, centerLon;
        final int radiusKm;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<float[]> hitPoints = new ArrayList<>();

        CallziroRadarView(Context context, ArrayList<CallziroAdapter.Point> points, double centerLat, double centerLon, int radiusKm) {
            super(context); this.points = points; this.centerLat = centerLat; this.centerLon = centerLon; this.radiusKm = Math.max(5, radiusKm);
            setBackgroundColor(Color.rgb(20, 23, 28));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) * 0.42f;
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1)); paint.setColor(Color.rgb(66,72,82));
            for (int i=1;i<=4;i++) canvas.drawCircle(cx, cy, r*i/4f, paint);
            canvas.drawLine(cx-r,cy,cx+r,cy,paint); canvas.drawLine(cx,cy-r,cx,cy+r,paint);

            paint.setStyle(Paint.Style.FILL); paint.setColor(ACCENT); canvas.drawCircle(cx,cy,dp(6),paint);
            paint.setTextSize(dp(11)); paint.setColor(Color.rgb(165,173,184));
            canvas.drawText("현재위치", cx + dp(9), cy - dp(7), paint);
            canvas.drawText(radiusKm + "km", cx + r - dp(34), cy - dp(6), paint);

            hitPoints.clear();
            double cos = Math.cos(Math.toRadians(centerLat));
            int labelled = 0;
            for (CallziroAdapter.Point cp : points) {
                double east = (cp.lon - centerLon) * 111.32 * cos;
                double north = (cp.lat - centerLat) * 110.57;
                double d = Math.sqrt(east*east+north*north);
                if (d > radiusKm*1.25) continue;
                float x = cx + (float)(east / radiusKm * r);
                float y = cy - (float)(north / radiusKm * r);
                boolean fav = isCallziroFavorite(cp);
                paint.setColor(fav ? Color.rgb(246,201,69) : Color.rgb(107,184,255));
                canvas.drawCircle(x,y, fav ? dp(6) : dp(5), paint);
                hitPoints.add(new float[]{x,y,points.indexOf(cp)});
                if (labelled < 14 && (fav || cp.roadKm < Math.max(4, radiusKm*0.35))) {
                    paint.setTextSize(dp(10)); paint.setColor(TEXT);
                    String nm = cp.name.length()>8 ? cp.name.substring(0,8) : cp.name;
                    canvas.drawText(nm, x+dp(6), y-dp(5), paint); labelled++;
                }
            }
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction()!=MotionEvent.ACTION_UP) return true;
            float best = Float.MAX_VALUE; CallziroAdapter.Point selected = null;
            for (float[] hp : hitPoints) {
                float dx=event.getX()-hp[0], dy=event.getY()-hp[1]; float d=dx*dx+dy*dy;
                if (d<best) { best=d; int idx=(int)hp[2]; if (idx>=0 && idx<points.size()) selected=points.get(idx); }
            }
            if (selected!=null && best < dp(35)*dp(35)) showCallziroDetail(selected);
            return true;
        }
    }

    static class SeedCallpoint {
        String id, sido, sigungu, eupmyeondong, name, naverQuery, type, timeHint, note, evidenceGrade, evidenceYear, sourceUrl;
        double lat, lon;
        SeedCallpoint(String id, String sido, String sigungu, String eupmyeondong, String name,
                      String naverQuery, String type, String timeHint, String note,
                      String evidenceGrade, String evidenceYear, String sourceUrl,
                      double lat, double lon) {
            this.id = id; this.sido = sido; this.sigungu = sigungu; this.eupmyeondong = eupmyeondong;
            this.name = name; this.naverQuery = naverQuery; this.type = type; this.timeHint = timeHint;
            this.note = note; this.evidenceGrade = evidenceGrade; this.evidenceYear = evidenceYear;
            this.sourceUrl = sourceUrl; this.lat = lat; this.lon = lon;
        }
    }

    static class SeedRank {
        SeedCallpoint callpoint; double score, roadKm;
        SeedRank(SeedCallpoint callpoint, double score, double roadKm) {
            this.callpoint = callpoint; this.score = score; this.roadKm = roadKm;
        }
    }

    static class Target {
        String name; double lat, lon; int anchorK;
        Target(String name, double lat, double lon, int anchorK) {
            this.name = name; this.lat = lat; this.lon = lon; this.anchorK = anchorK;
        }
    }

    static class Result {
        String name; int priceK;
        Result(String name, int priceK) { this.name = name; this.priceK = priceK; }
    }

    static class Section {
        String title; EditText edit; Target[] targets; int deltaK; TextView deltaView;
        LinearLayout cardView; LinearLayout homeSlot; Button favoriteButton; boolean favorite;
        Section(String title, EditText edit, Target[] targets, int deltaK, TextView deltaView,
                LinearLayout cardView, LinearLayout homeSlot, Button favoriteButton, boolean favorite) {
            this.title = title; this.edit = edit; this.targets = targets; this.deltaK = deltaK; this.deltaView = deltaView;
            this.cardView = cardView; this.homeSlot = homeSlot; this.favoriteButton = favoriteButton; this.favorite = favorite;
        }
    }
}
