package com.sangmin.seoulreturncall;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private static final double REF_LAT = 37.5689;
    private static final double REF_LON = 126.8408;
    private static final double ROAD_FACTOR = 1.22;
    private static final double WON_PER_KM_DELTA = 700.0;

    private static final int BG = Color.rgb(15, 17, 21);
    private static final int CARD = Color.rgb(25, 28, 34);
    private static final int TEXT = Color.rgb(244, 246, 248);
    private static final int MUTED = Color.rgb(167, 175, 186);
    private static final int ACCENT = Color.rgb(246, 201, 69);

    private double currentLat = REF_LAT;
    private double currentLon = REF_LON;
    private String currentMode = "run";
    private int returnDeltaK = -5;
    private int runDeltaK = 0;
    private int happyDeltaK = 5;
    private int modeDeltaK = 0;

    // 시간대 프리셋 보정(천원 단위)
    private String currentPreset = "weekday";
    private int weekdayPresetK = 0;
    private int friSatPresetK = 2;
    private int lateNightPresetK = 3;
    private int dawnPresetK = 1;
    private int presetDeltaK = 0;
    private SharedPreferences prefs;

    private TextView locationText;
    private TextView modeStateText;
    private Button returnButton;
    private Button runButton;
    private Button happyButton;
    private TextView returnDeltaText;
    private TextView runDeltaText;
    private TextView happyDeltaText;

    private Button weekdayPresetButton;
    private Button friSatPresetButton;
    private Button lateNightPresetButton;
    private Button dawnPresetButton;
    private TextView presetStateText;
    private TextView presetAdjustValueText;

    private final Map<String, Section> sections = new LinkedHashMap<>();

    private final Target[] seoulTargets = new Target[] {
        // 강서
        t("마곡",37.5509,126.8495,22), t("발산",37.5509,126.8495,22), t("가양",37.5509,126.8495,22),
        t("등촌",37.5509,126.8495,22), t("화곡",37.5509,126.8495,23), t("염창",37.5509,126.8495,23), t("방화",37.5509,126.8495,24),
        // 양천
        t("목동",37.5169,126.8665,22), t("신정",37.5169,126.8665,23), t("신월",37.5169,126.8665,24),
        // 마포
        t("상암",37.5663,126.9018,22), t("성산",37.5663,126.9018,23), t("망원",37.5663,126.9018,23), t("합정",37.5663,126.9018,23),
        t("서교",37.5663,126.9018,24), t("공덕",37.5663,126.9018,25), t("도화",37.5663,126.9018,25),
        // 영등포
        t("양평",37.5264,126.8963,23), t("당산",37.5264,126.8963,23), t("문래",37.5264,126.8963,24), t("영등포",37.5264,126.8963,24),
        t("신길",37.5264,126.8963,25), t("대림",37.5264,126.8963,26), t("여의도",37.5264,126.8963,27),
        // 서대문
        t("북가좌",37.5791,126.9368,26), t("남가좌",37.5791,126.9368,26), t("연희",37.5791,126.9368,27), t("신촌",37.5791,126.9368,29), t("충정로",37.5791,126.9368,30),
        // 동작
        t("노량진",37.5124,126.9393,28), t("대방",37.5124,126.9393,28), t("신대방",37.5124,126.9393,29), t("상도",37.5124,126.9393,29), t("흑석",37.5124,126.9393,30), t("사당",37.5124,126.9393,31),
        // 종로
        t("종로",37.5735,126.9790,30), t("혜화",37.5735,126.9790,32),
        // 용산
        t("원효로",37.5326,126.9905,31), t("용산",37.5326,126.9905,33), t("이촌",37.5326,126.9905,34), t("한남",37.5326,126.9905,35),
        // 중구
        t("충무로",37.5636,126.9976,34), t("을지로",37.5636,126.9976,34), t("신당",37.5636,126.9976,35), t("약수",37.5636,126.9976,35),
        // 성동
        t("금호",37.5633,127.0368,36), t("옥수",37.5633,127.0368,36), t("왕십리",37.5633,127.0368,37), t("행당",37.5633,127.0368,37), t("성수",37.5633,127.0368,39), t("서울숲",37.5633,127.0368,39),
        // 동대문
        t("신설",37.5744,127.0396,37), t("청량리",37.5744,127.0396,39), t("답십리",37.5744,127.0396,40), t("장안",37.5744,127.0396,41),
        // 강남
        t("논현",37.5172,127.0473,39), t("강남신사",37.5172,127.0473,39), t("역삼",37.5172,127.0473,40), t("압구정",37.5172,127.0473,40),
        t("청담",37.5172,127.0473,41), t("삼성",37.5172,127.0473,41), t("대치",37.5172,127.0473,42), t("도곡",37.5172,127.0473,42),
        // 서초
        t("반포",37.4837,127.0324,38), t("잠원",37.4837,127.0324,39), t("서초",37.4837,127.0324,40), t("방배",37.4837,127.0324,40), t("양재",37.4837,127.0324,42),
        // 광진
        t("자양",37.5385,127.0823,42), t("구의",37.5385,127.0823,43), t("화양",37.5385,127.0823,44), t("군자",37.5385,127.0823,45),
        // 송파
        t("잠실",37.5145,127.1059,46), t("신천",37.5145,127.1059,47), t("삼전",37.5145,127.1059,47), t("석촌",37.5145,127.1059,48),
        t("송파",37.5145,127.1059,48), t("가락",37.5145,127.1059,49), t("문정",37.5145,127.1059,50), t("방이",37.5145,127.1059,50), t("오금",37.5145,127.1059,51),
        // 강동
        t("천호",37.5301,127.1238,49), t("성내",37.5301,127.1238,49), t("암사",37.5301,127.1238,50), t("길동",37.5301,127.1238,51),
        t("둔촌",37.5301,127.1238,52), t("명일",37.5301,127.1238,52), t("고덕",37.5301,127.1238,54)
    };

    private final Target[] metroTargets = new Target[] {
        t("인천",37.4563,126.7052,32), t("김포",37.6152,126.7156,28), t("고양",37.6584,126.8320,30), t("파주",37.7599,126.7800,38),
        t("양주",37.7853,127.0458,48), t("의정부",37.7381,127.0337,45), t("남양주",37.6360,127.2165,52), t("구리",37.5943,127.1296,44),
        t("광주",37.4095,127.2550,55), t("하남",37.5393,127.2148,48), t("이천",37.2720,127.4350,70), t("안성",37.0080,127.2790,75),
        t("평택",36.9921,127.1129,70), t("화성",37.1995,126.8312,58), t("오산",37.1498,127.0772,58), t("의왕",37.3447,126.9683,43),
        t("군포",37.3617,126.9352,42), t("과천",37.4292,126.9876,38), t("시흥",37.3802,126.8029,36), t("광명",37.4786,126.8644,28), t("부천",37.5034,126.7660,25)
    };

    private final Target[] suwonBundleTargets = new Target[] {
        // 수원
        t("구운",37.2636,127.0286,45), t("서둔",37.2636,127.0286,46), t("화서",37.2636,127.0286,46), t("매산",37.2636,127.0286,46),
        t("매교",37.2636,127.0286,47), t("세류",37.2636,127.0286,47), t("권선",37.2636,127.0286,48), t("인계",37.2636,127.0286,48),
        t("우만",37.2636,127.0286,48), t("지동",37.2636,127.0286,48), t("매탄",37.2636,127.0286,49), t("망포",37.2636,127.0286,50),
        t("영통",37.2636,127.0286,50), t("원천",37.2636,127.0286,50), t("광교",37.2636,127.0286,52), t("호매실",37.2636,127.0286,50), t("금곡",37.2636,127.0286,50),
        // 분당
        t("야탑",37.3828,127.1189,50), t("이매",37.3828,127.1189,51), t("서현",37.3828,127.1189,52), t("수내",37.3828,127.1189,52),
        t("정자",37.3828,127.1189,53), t("판교",37.3828,127.1189,52), t("백현",37.3828,127.1189,52), t("삼평",37.3828,127.1189,52),
        t("미금",37.3828,127.1189,54), t("구미",37.3828,127.1189,54), t("오리",37.3828,127.1189,55),
        // 용인 수지권
        t("수지",37.3222,127.0976,55), t("풍덕천",37.3222,127.0976,55), t("성복",37.3222,127.0976,56), t("상현",37.3222,127.0976,56), t("죽전",37.3222,127.0976,57),
        // 용인 기흥권
        t("보정",37.2740,127.1158,57), t("구성",37.2740,127.1158,58), t("마북",37.2740,127.1158,58), t("신갈",37.2740,127.1158,58),
        t("구갈",37.2740,127.1158,59), t("상갈",37.2740,127.1158,59), t("기흥",37.2740,127.1158,59), t("동백",37.2740,127.1158,61),
        t("중동",37.2740,127.1158,61), t("서천",37.2740,127.1158,60), t("흥덕",37.2740,127.1158,60),
        // 용인 처인권 주요지만
        t("역북",37.2342,127.2013,64), t("김량장",37.2342,127.2013,65), t("삼가",37.2342,127.2013,64)
    };

    private final Target[] anyangBundleTargets = new Target[] {
        // 안양
        t("안양",37.3943,126.9568,38), t("명학",37.3943,126.9568,39), t("비산",37.3943,126.9568,39), t("관양",37.3943,126.9568,40),
        t("인덕원",37.3943,126.9568,40), t("평촌",37.3943,126.9568,40), t("범계",37.3943,126.9568,40), t("호계",37.3943,126.9568,41),
        t("석수",37.3943,126.9568,39), t("박달",37.3943,126.9568,40),
        // 안산
        t("고잔",37.3219,126.8309,44), t("중앙",37.3219,126.8309,44), t("초지",37.3219,126.8309,45), t("선부",37.3219,126.8309,45),
        t("와동",37.3219,126.8309,46), t("월피",37.3219,126.8309,46), t("성포",37.3219,126.8309,45), t("사동",37.3219,126.8309,46),
        t("본오",37.3219,126.8309,47), t("상록수",37.3219,126.8309,47)
    };

    private final Target[] chungcheongTargets = new Target[] {
        t("천안",36.8151,127.1139,85), t("아산",36.7898,127.0018,90), t("진천",36.8554,127.4356,95),
        t("청주",36.6424,127.4890,100), t("세종",36.4800,127.2890,110), t("대전",36.3504,127.3845,120)
    };

    private final Target[] gangwonTargets = new Target[] {
        t("춘천",37.8813,127.7298,95), t("원주",37.3422,127.9202,105), t("홍천",37.6972,127.8886,110),
        t("횡성",37.4917,127.9850,115), t("평창",37.3705,128.3903,135), t("강릉",37.7519,128.8761,155), t("속초",38.2070,128.5918,160)
    };


    // 세부 지역: 기존 권역표는 그대로 두고 앱별로 필요한 지역만 따로 복사할 수 있게 분리
    private final Target[] seoulGuTargets = new Target[] {
        t("강서",37.5509,126.8495,23), t("양천",37.5169,126.8665,23), t("마포",37.5663,126.9018,23),
        t("영등포",37.5264,126.8963,24), t("서대문",37.5791,126.9368,28), t("은평",37.6027,126.9291,28),
        t("동작",37.5124,126.9393,29), t("종로",37.5735,126.9790,30), t("용산",37.5326,126.9905,33),
        t("중구",37.5636,126.9976,34), t("성동",37.5633,127.0368,38), t("동대문",37.5744,127.0396,39),
        t("강남",37.5172,127.0473,40), t("서초",37.4837,127.0324,40), t("광진",37.5385,127.0823,44),
        t("중랑",37.6063,127.0927,46), t("송파",37.5145,127.1059,49), t("강동",37.5301,127.1238,51)
    };

    private final Target[] gimpoTargets = new Target[] {
        t("고촌",37.6030,126.7705,27), t("풍무",37.6060,126.7240,28), t("사우",37.6200,126.7200,29),
        t("걸포",37.6320,126.7040,29), t("운양",37.6530,126.6840,30), t("장기",37.6440,126.6700,30),
        t("구래",37.6450,126.6290,32), t("마산",37.6400,126.6450,32)
    };

    private final Target[] goyangPajuTargets = new Target[] {
        t("능곡",37.6200,126.8200,28), t("행신",37.6150,126.8340,29), t("화정",37.6350,126.8320,30),
        t("원흥",37.6500,126.8750,31), t("삼송",37.6530,126.8950,31), t("백석",37.6430,126.7870,32),
        t("마두",37.6530,126.7770,32), t("정발산",37.6600,126.7730,33), t("주엽",37.6700,126.7580,33),
        t("대화",37.6750,126.7470,34), t("야당",37.7120,126.7610,36), t("운정",37.7150,126.7440,36),
        t("금촌",37.7590,126.7730,39)
    };

    private final Target[] incheonBucheonTargets = new Target[] {
        t("부천",37.5034,126.7660,25), t("중동",37.5010,126.7750,25), t("상동",37.5050,126.7530,26),
        t("송내",37.4870,126.7540,26), t("역곡",37.4850,126.8110,26), t("부평",37.4930,126.7240,31),
        t("구월",37.4490,126.7020,32), t("주안",37.4630,126.6800,32), t("간석",37.4670,126.7070,32),
        t("계산",37.5430,126.7280,33), t("작전",37.5300,126.7220,33), t("청라",37.5330,126.6450,34),
        t("송도",37.3820,126.6560,36)
    };

    private final Target[] anyangTargets = new Target[] {
        t("안양",37.3943,126.9568,38), t("명학",37.3943,126.9568,39), t("비산",37.3943,126.9568,39),
        t("석수",37.3943,126.9568,39), t("박달",37.3943,126.9568,40), t("관양",37.3943,126.9568,40),
        t("인덕원",37.3943,126.9568,40), t("평촌",37.3943,126.9568,40), t("범계",37.3943,126.9568,40),
        t("호계",37.3943,126.9568,41)
    };

    private final Target[] ansanTargets = new Target[] {
        t("고잔",37.3219,126.8309,44), t("중앙",37.3219,126.8309,44), t("초지",37.3219,126.8309,45),
        t("선부",37.3219,126.8309,45), t("성포",37.3219,126.8309,45), t("와동",37.3219,126.8309,46),
        t("월피",37.3219,126.8309,46), t("사동",37.3219,126.8309,46), t("본오",37.3219,126.8309,47),
        t("상록수",37.3219,126.8309,47)
    };

    private final Target[] suwonTargets = new Target[] {
        t("구운",37.2636,127.0286,45), t("서둔",37.2636,127.0286,46), t("화서",37.2636,127.0286,46),
        t("매산",37.2636,127.0286,46), t("매교",37.2636,127.0286,47), t("세류",37.2636,127.0286,47),
        t("권선",37.2636,127.0286,48), t("인계",37.2636,127.0286,48), t("우만",37.2636,127.0286,48),
        t("지동",37.2636,127.0286,48), t("매탄",37.2636,127.0286,49), t("망포",37.2636,127.0286,50),
        t("영통",37.2636,127.0286,50), t("원천",37.2636,127.0286,50), t("호매실",37.2636,127.0286,50),
        t("금곡",37.2636,127.0286,50), t("광교",37.2636,127.0286,52)
    };

    private final Target[] seongnamTargets = new Target[] {
        t("모란",37.4310,127.1290,48), t("수진",37.4370,127.1290,49), t("신흥",37.4400,127.1450,49),
        t("태평",37.4400,127.1270,49), t("단대",37.4500,127.1550,50), t("하대원",37.4280,127.1480,50),
        t("상대원",37.4330,127.1640,50)
    };

    private final Target[] bundangTargets = new Target[] {
        t("야탑",37.3828,127.1189,50), t("이매",37.3828,127.1189,51), t("서현",37.3828,127.1189,52),
        t("수내",37.3828,127.1189,52), t("판교",37.3828,127.1189,52), t("백현",37.3828,127.1189,52),
        t("삼평",37.3828,127.1189,52), t("정자",37.3828,127.1189,53), t("미금",37.3828,127.1189,54),
        t("구미",37.3828,127.1189,54), t("오리",37.3828,127.1189,55)
    };

    private final Target[] yonginTargets = new Target[] {
        t("수지",37.3222,127.0976,55), t("풍덕천",37.3222,127.0976,55), t("성복",37.3222,127.0976,56),
        t("상현",37.3222,127.0976,56), t("죽전",37.3222,127.0976,57), t("보정",37.2740,127.1158,57),
        t("구성",37.2740,127.1158,58), t("마북",37.2740,127.1158,58), t("신갈",37.2740,127.1158,58),
        t("구갈",37.2740,127.1158,59), t("상갈",37.2740,127.1158,59), t("기흥",37.2740,127.1158,59),
        t("서천",37.2740,127.1158,60), t("흥덕",37.2740,127.1158,60), t("동백",37.2740,127.1158,61),
        t("중동",37.2740,127.1158,61), t("역북",37.2342,127.2013,64), t("삼가",37.2342,127.2013,64),
        t("김량장",37.2342,127.2013,65)
    };

    private final Target[] namyangjuGuriTargets = new Target[] {
        t("구리",37.5943,127.1296,44), t("갈매",37.6340,127.1180,45), t("다산",37.6260,127.1550,48),
        t("별내",37.6500,127.1160,50), t("평내",37.6480,127.2380,53), t("호평",37.6540,127.2440,53),
        t("진접",37.7260,127.1900,55)
    };

    private final Target[] hanamGwangjuTargets = new Target[] {
        t("미사",37.5600,127.1900,48), t("덕풍",37.5520,127.2040,49), t("신장",37.5380,127.2050,49),
        t("감일",37.5080,127.1620,50), t("광주",37.4095,127.2550,55), t("경안",37.4100,127.2580,55),
        t("태전",37.3890,127.2290,56), t("오포",37.3660,127.2280,56)
    };

    private final Target[] uijeongbuYangjuTargets = new Target[] {
        t("의정부",37.7381,127.0337,45), t("가능",37.7480,127.0420,46), t("호원",37.7100,127.0470,46),
        t("민락",37.7450,127.0950,47), t("신곡",37.7310,127.0570,47), t("양주",37.7853,127.0458,48),
        t("옥정",37.8200,127.0940,50), t("덕정",37.8430,127.0610,51)
    };

    private final Target[] pyeongtaekAnseongTargets = new Target[] {
        t("평택",36.9921,127.1129,70), t("비전",36.9900,127.1030,70), t("소사벌",36.9950,127.1210,71),
        t("공도",36.9980,127.1720,72), t("고덕",37.0430,127.0490,72), t("송탄",37.0810,127.0550,72),
        t("안중",36.9860,126.9310,74), t("안성",37.0080,127.2790,75)
    };

    private final Target[] hwaseongOsanTargets = new Target[] {
        t("병점",37.2060,127.0340,55), t("동탄",37.2000,127.0720,56), t("반월",37.2240,127.0600,56),
        t("봉담",37.2200,126.9490,58), t("오산",37.1498,127.0772,58), t("세교",37.1810,127.0440,59),
        t("향남",37.1320,126.9200,60)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("pricing_adjust", MODE_PRIVATE);
        returnDeltaK = prefs.getInt("returnK", -5);
        runDeltaK = prefs.getInt("runK", 0);
        happyDeltaK = prefs.getInt("happyK", 5);
        currentPreset = prefs.getString("currentPreset", "weekday");
        weekdayPresetK = prefs.getInt("preset_weekdayK", 0);
        friSatPresetK = prefs.getInt("preset_frisatK", 2);
        lateNightPresetK = prefs.getInt("preset_latenightK", 3);
        dawnPresetK = prefs.getInt("preset_dawnK", 1);
        modeDeltaK = runDeltaK;
        presetDeltaK = deltaForPreset(currentPreset);
        setContentView(buildUi());
        recalculateAll();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = text("콜지가격 자동계산", 28, TEXT, true);
        root.addView(title);
        TextView sub = text("GPS 한 번 → 권역별 가격표 전부 계산 · 각 칸은 직접 수정 가능", 13, MUTED, false);
        sub.setPadding(0, dp(4), 0, 0);
        root.addView(sub);

        LinearLayout locCard = card();
        locCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView locLabel = text("현재 출발 위치", 12, MUTED, false);
        locCard.addView(locLabel);
        locationText = text("강서로 490 · 기준 위치", 18, TEXT, true);
        locationText.setPadding(0, dp(4), 0, 0);
        locCard.addView(locationText);
        Button gps = primaryButton("GPS 새로고침 · 전 권역 재계산");
        LinearLayout.LayoutParams gpsLp = new LinearLayout.LayoutParams(-1, dp(50));
        gpsLp.topMargin = dp(12);
        locCard.addView(gps, gpsLp);
        gps.setOnClickListener(v -> requestCurrentLocation());
        root.addView(locCard, topMargin(14));

        TextView modeTitle = text("운행 모드", 17, TEXT, true);
        root.addView(modeTitle, topMargin(16));
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        returnButton = modeButton("복귀콜\n-5천");
        runButton = modeButton("달려콜\n기준");
        happyButton = modeButton("해피타임\n+5천");
        modes.addView(returnButton, weightLp(1));
        LinearLayout.LayoutParams mid = weightLp(1); mid.leftMargin = dp(6); mid.rightMargin = dp(6);
        modes.addView(runButton, mid);
        modes.addView(happyButton, weightLp(1));
        root.addView(modes, topMargin(8));
        modeStateText = text("현재: 달려콜 · 기준", 13, ACCENT, true);
        root.addView(modeStateText, topMargin(6));
        returnButton.setOnClickListener(v -> setMode("return"));
        runButton.setOnClickListener(v -> setMode("run"));
        happyButton.setOnClickListener(v -> setMode("happy"));
        refreshModeUi();

        addAdjustmentCard(root);
        addTimePresetCard(root);

        addSection(root, "서울", "서울 복사", seoulTargets);
        addSection(root, "수도권", "수도권 복사", metroTargets);
        addSection(root, "수원 · 분당 · 용인", "수원세트 복사", suwonBundleTargets);
        addSection(root, "안양 · 안산", "안양세트 복사", anyangBundleTargets);
        addSection(root, "충청권", "충청권 복사", chungcheongTargets);
        addSection(root, "강원권", "강원권 복사", gangwonTargets);

        TextView detailTitle = text("세부 지역", 20, TEXT, true);
        detailTitle.setPadding(0, dp(10), 0, 0);
        root.addView(detailTitle, topMargin(18));
        TextView detailSub = text("앱마다 적용 방식이 다를 때 필요한 지역만 골라서 복사", 12, MUTED, false);
        detailSub.setPadding(0, dp(3), 0, dp(2));
        root.addView(detailSub);

        addSection(root, "서울(구)", "서울(구) 복사", seoulGuTargets);
        addSection(root, "김포 · 고양 · 파주 · 인천 · 부천", "이 묶음 복사",
                combineTargets(gimpoTargets, goyangPajuTargets, incheonBucheonTargets));
        addSection(root, "안양 · 안산 · 수원 · 용인 · 화성 · 오산", "이 묶음 복사",
                combineTargets(anyangTargets, ansanTargets, suwonTargets, yonginTargets, hwaseongOsanTargets));
        addSection(root, "성남 · 분당 · 남양주 · 구리", "이 묶음 복사",
                combineTargets(seongnamTargets, bundangTargets, namyangjuGuriTargets));
        addSection(root, "하남 · 광주 · 의정부 · 양주 · 평택 · 안성", "이 묶음 복사",
                combineTargets(hanamGwangjuTargets, uijeongbuYangjuTargets, pyeongtaekAnseongTargets));

        TextView foot = text("※ 강서로 490 기준표에 현재 GPS와 목적지 거리 차이를 보정하는 개인용 최소수락가 계산표야. 실시간 플랫폼 제시가가 아니야.", 11, MUTED, false);
        foot.setLineSpacing(0, 1.25f);
        root.addView(foot, topMargin(16));

        return scroll;
    }

    private Target[] combineTargets(Target[]... groups) {
        int total = 0;
        for (Target[] group : groups) total += group.length;
        Target[] merged = new Target[total];
        int offset = 0;
        for (Target[] group : groups) {
            System.arraycopy(group, 0, merged, offset, group.length);
            offset += group.length;
        }
        return merged;
    }

    private void addSection(LinearLayout root, String title, String copyLabel, Target[] targets) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView heading = text(title, 18, TEXT, true);
        c.addView(heading);
        TextView helper = text("자동 계산 후 필요한 금액만 직접 고쳐서 복사", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        int savedSectionDelta = prefs.getInt(sectionPrefKey(title), 0);

        LinearLayout adjustRow = new LinearLayout(this);
        adjustRow.setOrientation(LinearLayout.HORIZONTAL);
        adjustRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView adjustLabel = text("이 카드 보정", 12, MUTED, true);
        adjustRow.addView(adjustLabel, new LinearLayout.LayoutParams(0, dp(42), 1.3f));
        Button minus = smallAdjustButton("−");
        adjustRow.addView(minus, new LinearLayout.LayoutParams(dp(48), dp(40)));
        TextView adjustValue = text(formatDelta(savedSectionDelta), 14, ACCENT, true);
        adjustValue.setGravity(Gravity.CENTER);
        adjustRow.addView(adjustValue, new LinearLayout.LayoutParams(0, dp(40), 1f));
        Button plus = smallAdjustButton("+");
        adjustRow.addView(plus, new LinearLayout.LayoutParams(dp(48), dp(40)));
        LinearLayout.LayoutParams adjustLp = new LinearLayout.LayoutParams(-1, dp(44));
        adjustLp.topMargin = dp(6);
        c.addView(adjustRow, adjustLp);

        EditText edit = new EditText(this);
        edit.setTextColor(TEXT);
        edit.setHintTextColor(MUTED);
        edit.setTextSize(14);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setPadding(dp(10), dp(10), dp(10), dp(10));
        edit.setMinLines(3);
        edit.setMaxLines(8);
        edit.setSingleLine(false);
        edit.setHorizontallyScrolling(false);
        edit.setBackground(rounded(Color.rgb(35, 39, 47), 12));
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(-1, -2);
        editLp.topMargin = dp(8);
        c.addView(edit, editLp);

        Button copy = primaryButton(copyLabel);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(-1, dp(46));
        copyLp.topMargin = dp(10);
        c.addView(copy, copyLp);
        copy.setOnClickListener(v -> copyText(title, edit.getText().toString()));

        Section section = new Section(title, edit, targets, savedSectionDelta, adjustValue);
        sections.put(title, section);
        minus.setOnClickListener(v -> adjustSection(section, -1));
        plus.setOnClickListener(v -> adjustSection(section, 1));
        root.addView(c, topMargin(12));
    }

    private void addAdjustmentCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("단가 보정 · 1천원씩 즉시 조정", 17, TEXT, true));

        returnDeltaText = addAdjustmentRow(c, "복귀콜", "return");
        runDeltaText = addAdjustmentRow(c, "달려콜", "run");
        happyDeltaText = addAdjustmentRow(c, "해피타임", "happy");

        Button reset = new Button(this);
        reset.setAllCaps(false);
        reset.setText("보정값 기본으로 복원 (-5 / 0 / +5)");
        reset.setTextSize(13);
        reset.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reset.setTextColor(TEXT);
        reset.setBackground(rounded(Color.rgb(42,47,56), 12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48));
        rp.topMargin = dp(10);
        c.addView(reset, rp);
        reset.setOnClickListener(v -> {
            returnDeltaK = -5; runDeltaK = 0; happyDeltaK = 5;
            saveAdjustments();
            modeDeltaK = deltaForMode(currentMode);
            refreshModeUi();
            recalculateAll();
            Toast.makeText(this, "보정값을 기본값으로 복원했어", Toast.LENGTH_SHORT).show();
        });

        root.addView(c, topMargin(12));
    }

    private TextView addAdjustmentRow(LinearLayout card, String label, String mode) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 14, TEXT, true);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(50), 1.2f));

        Button minus = smallAdjustButton("−");
        row.addView(minus, new LinearLayout.LayoutParams(dp(54), dp(46)));

        TextView value = text(formatDelta(deltaForMode(mode)), 16, ACCENT, true);
        value.setGravity(Gravity.CENTER);
        row.addView(value, new LinearLayout.LayoutParams(0, dp(46), 1f));

        Button plus = smallAdjustButton("+");
        row.addView(plus, new LinearLayout.LayoutParams(dp(54), dp(46)));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(54));
        rowLp.topMargin = dp(4);
        card.addView(row, rowLp);

        minus.setOnClickListener(v -> adjustMode(mode, -1));
        plus.setOnClickListener(v -> adjustMode(mode, 1));
        return value;
    }

    private Button smallAdjustButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(20);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(TEXT);
        b.setPadding(0,0,0,0);
        b.setBackground(rounded(Color.rgb(42,47,56), 12));
        return b;
    }

    private void adjustMode(String mode, int step) {
        if ("return".equals(mode)) returnDeltaK = clampDelta(returnDeltaK + step);
        else if ("happy".equals(mode)) happyDeltaK = clampDelta(happyDeltaK + step);
        else runDeltaK = clampDelta(runDeltaK + step);
        saveAdjustments();
        if (mode.equals(currentMode)) modeDeltaK = deltaForMode(mode);
        refreshModeUi();
        recalculateAll();
    }

    private int clampDelta(int value) { return Math.max(-20, Math.min(20, value)); }

    private void saveAdjustments() {
        prefs.edit().putInt("returnK", returnDeltaK).putInt("runK", runDeltaK).putInt("happyK", happyDeltaK).apply();
    }

    private int deltaForMode(String mode) {
        if ("return".equals(mode)) return returnDeltaK;
        if ("happy".equals(mode)) return happyDeltaK;
        return runDeltaK;
    }

    private String formatDelta(int value) {
        return value == 0 ? "기준" : (value > 0 ? "+" : "") + value + "천";
    }

    private void setMode(String mode) {
        currentMode = mode;
        modeDeltaK = deltaForMode(mode);
        refreshModeUi();
        recalculateAll();
        Toast.makeText(this, "전 권역을 " + modeName() + " 기준으로 다시 계산했어", Toast.LENGTH_SHORT).show();
    }

    private void refreshModeUi() {
        returnButton.setBackground(rounded("return".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        runButton.setBackground(rounded("run".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        happyButton.setBackground(rounded("happy".equals(currentMode) ? ACCENT : Color.rgb(42,47,56), 12));
        returnButton.setTextColor("return".equals(currentMode) ? Color.BLACK : TEXT);
        runButton.setTextColor("run".equals(currentMode) ? Color.BLACK : TEXT);
        happyButton.setTextColor("happy".equals(currentMode) ? Color.BLACK : TEXT);
        returnButton.setText("복귀콜\n" + formatDelta(returnDeltaK));
        runButton.setText("달려콜\n" + formatDelta(runDeltaK));
        happyButton.setText("해피타임\n" + formatDelta(happyDeltaK));
        if (returnDeltaText != null) returnDeltaText.setText(formatDelta(returnDeltaK));
        if (runDeltaText != null) runDeltaText.setText(formatDelta(runDeltaK));
        if (happyDeltaText != null) happyDeltaText.setText(formatDelta(happyDeltaK));
        modeStateText.setText("현재: " + modeName() + " · " + formatDelta(modeDeltaK));
    }

    private String modeName() {
        if ("return".equals(currentMode)) return "복귀콜";
        if ("happy".equals(currentMode)) return "해피타임";
        return "달려콜";
    }

    private void addTimePresetCard(LinearLayout root) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.addView(text("시간대 프리셋", 17, TEXT, true));
        TextView helper = text("한 번 선택하면 전 권역에 시간대 보정이 같이 적용돼", 11, MUTED, false);
        helper.setPadding(0, dp(3), 0, 0);
        c.addView(helper);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        weekdayPresetButton = compactPresetButton();
        friSatPresetButton = compactPresetButton();
        lateNightPresetButton = compactPresetButton();
        dawnPresetButton = compactPresetButton();
        buttons.addView(weekdayPresetButton, weightLp(1));
        LinearLayout.LayoutParams p2 = weightLp(1); p2.leftMargin = dp(4);
        buttons.addView(friSatPresetButton, p2);
        LinearLayout.LayoutParams p3 = weightLp(1); p3.leftMargin = dp(4);
        buttons.addView(lateNightPresetButton, p3);
        LinearLayout.LayoutParams p4 = weightLp(1); p4.leftMargin = dp(4);
        buttons.addView(dawnPresetButton, p4);
        c.addView(buttons, topMargin(8));

        presetStateText = text("", 12, ACCENT, true);
        c.addView(presetStateText, topMargin(6));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text("선택 프리셋 보정", 13, TEXT, true), new LinearLayout.LayoutParams(0, dp(46), 1.5f));
        Button minus = smallAdjustButton("−");
        row.addView(minus, new LinearLayout.LayoutParams(dp(52), dp(42)));
        presetAdjustValueText = text(formatDelta(presetDeltaK), 15, ACCENT, true);
        presetAdjustValueText.setGravity(Gravity.CENTER);
        row.addView(presetAdjustValueText, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Button plus = smallAdjustButton("+");
        row.addView(plus, new LinearLayout.LayoutParams(dp(52), dp(42)));
        c.addView(row, topMargin(6));

        Button reset = new Button(this);
        reset.setAllCaps(false);
        reset.setText("시간대 기본값 복원 (0 / +2 / +3 / +1)");
        reset.setTextSize(12);
        reset.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reset.setTextColor(TEXT);
        reset.setBackground(rounded(Color.rgb(42,47,56), 12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(44));
        rp.topMargin = dp(8);
        c.addView(reset, rp);

        weekdayPresetButton.setOnClickListener(v -> setPreset("weekday"));
        friSatPresetButton.setOnClickListener(v -> setPreset("frisat"));
        lateNightPresetButton.setOnClickListener(v -> setPreset("latenight"));
        dawnPresetButton.setOnClickListener(v -> setPreset("dawn"));
        minus.setOnClickListener(v -> adjustCurrentPreset(-1));
        plus.setOnClickListener(v -> adjustCurrentPreset(1));
        reset.setOnClickListener(v -> {
            weekdayPresetK = 0; friSatPresetK = 2; lateNightPresetK = 3; dawnPresetK = 1;
            presetDeltaK = deltaForPreset(currentPreset);
            savePresetSettings();
            refreshPresetUi();
            recalculateAll();
            Toast.makeText(this, "시간대 프리셋을 기본값으로 복원했어", Toast.LENGTH_SHORT).show();
        });

        refreshPresetUi();
        root.addView(c, topMargin(12));
    }

    private Button compactPresetButton() {
        Button b = modeButton("");
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setPadding(dp(2), dp(3), dp(2), dp(3));
        return b;
    }

    private void setPreset(String preset) {
        currentPreset = preset;
        presetDeltaK = deltaForPreset(preset);
        savePresetSettings();
        refreshPresetUi();
        recalculateAll();
        Toast.makeText(this, presetName(preset) + " 프리셋 적용", Toast.LENGTH_SHORT).show();
    }

    private void adjustCurrentPreset(int step) {
        if ("frisat".equals(currentPreset)) friSatPresetK = clampDelta(friSatPresetK + step);
        else if ("latenight".equals(currentPreset)) lateNightPresetK = clampDelta(lateNightPresetK + step);
        else if ("dawn".equals(currentPreset)) dawnPresetK = clampDelta(dawnPresetK + step);
        else weekdayPresetK = clampDelta(weekdayPresetK + step);
        presetDeltaK = deltaForPreset(currentPreset);
        savePresetSettings();
        refreshPresetUi();
        recalculateAll();
    }

    private int deltaForPreset(String preset) {
        if ("frisat".equals(preset)) return friSatPresetK;
        if ("latenight".equals(preset)) return lateNightPresetK;
        if ("dawn".equals(preset)) return dawnPresetK;
        return weekdayPresetK;
    }

    private String presetName(String preset) {
        if ("frisat".equals(preset)) return "금토";
        if ("latenight".equals(preset)) return "심야";
        if ("dawn".equals(preset)) return "새벽";
        return "평일";
    }

    private void savePresetSettings() {
        prefs.edit()
                .putString("currentPreset", currentPreset)
                .putInt("preset_weekdayK", weekdayPresetK)
                .putInt("preset_frisatK", friSatPresetK)
                .putInt("preset_latenightK", lateNightPresetK)
                .putInt("preset_dawnK", dawnPresetK)
                .apply();
    }

    private void refreshPresetUi() {
        if (weekdayPresetButton == null) return;
        updatePresetButton(weekdayPresetButton, "weekday", "평일", weekdayPresetK);
        updatePresetButton(friSatPresetButton, "frisat", "금토", friSatPresetK);
        updatePresetButton(lateNightPresetButton, "latenight", "심야", lateNightPresetK);
        updatePresetButton(dawnPresetButton, "dawn", "새벽", dawnPresetK);
        presetDeltaK = deltaForPreset(currentPreset);
        if (presetAdjustValueText != null) presetAdjustValueText.setText(formatDelta(presetDeltaK));
        if (presetStateText != null) presetStateText.setText("현재: " + presetName(currentPreset) + " · " + formatDelta(presetDeltaK));
    }

    private void updatePresetButton(Button b, String id, String label, int value) {
        boolean selected = id.equals(currentPreset);
        b.setBackground(rounded(selected ? ACCENT : Color.rgb(42,47,56), 12));
        b.setTextColor(selected ? Color.BLACK : TEXT);
        b.setText(label + "\n" + formatDelta(value));
    }

    private void adjustSection(Section section, int step) {
        section.deltaK = clampDelta(section.deltaK + step);
        prefs.edit().putInt(sectionPrefKey(section.title), section.deltaK).apply();
        section.deltaView.setText(formatDelta(section.deltaK));
        recalculateSection(section);
    }

    private String sectionPrefKey(String title) {
        return "section_delta_" + title;
    }

    private void recalculateSection(Section section) {
        section.edit.setText(buildOneLine(section));
    }

    private void requestCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        fetchLocation();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocation();
        } else {
            Toast.makeText(this, "위치 권한이 필요해", Toast.LENGTH_SHORT).show();
        }
    }

    private void fetchLocation() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        try {
            Location gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (gps != null) best = gps;
            if (net != null && (best == null || net.getTime() > best.getTime())) best = net;
        } catch (SecurityException ignored) {}

        if (best != null) useLocation(best, false);

        LocationListener listener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                useLocation(location, true);
                try { lm.removeUpdates(this); } catch (SecurityException ignored) {}
            }
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
        };

        try {
            boolean requested = false;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
                requested = true;
            }
            if (!requested && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener);
                requested = true;
            }
            if (!requested && best == null) Toast.makeText(this, "휴대폰 위치 서비스를 켜줘", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "GPS 위치를 가져오지 못했어", Toast.LENGTH_SHORT).show();
        }
    }

    private void useLocation(Location location, boolean fresh) {
        currentLat = location.getLatitude();
        currentLon = location.getLongitude();
        locationText.setText(String.format(Locale.KOREA, "GPS %.5f, %.5f%s", currentLat, currentLon, fresh ? " · 최신" : ""));
        recalculateAll();
        reverseGeocode(currentLat, currentLon);
        if (fresh) Toast.makeText(this, "전 권역 계산 완료", Toast.LENGTH_SHORT).show();
    }

    private void reverseGeocode(double lat, double lon) {
        new Thread(() -> {
            try {
                Geocoder geocoder = new Geocoder(this, Locale.KOREA);
                List<Address> list = geocoder.getFromLocation(lat, lon, 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    String area = clean(a.getSubLocality());
                    String feature = clean(a.getFeatureName());
                    String locality = clean(a.getLocality());
                    String label = "";
                    if (!area.isEmpty()) label = area;
                    if (!feature.isEmpty() && !feature.equals(area)) label += (label.isEmpty() ? "" : " ") + feature;
                    if (label.isEmpty()) label = locality;
                    if (!label.isEmpty()) {
                        String finalLabel = label + String.format(Locale.KOREA, " · %.5f, %.5f", lat, lon);
                        runOnUiThread(() -> locationText.setText(finalLabel));
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private String clean(String s) { return s == null ? "" : s.trim(); }

    private void recalculateAll() {
        for (Map.Entry<String, Section> e : sections.entrySet()) {
            recalculateSection(e.getValue());
        }
    }

    private String buildOneLine(Section section) {
        Target[] targets = section.targets;
        List<Result> results = new ArrayList<>();
        for (Target t : targets) {
            double refRoad = haversineKm(REF_LAT, REF_LON, t.lat, t.lon) * ROAD_FACTOR;
            double nowRoad = haversineKm(currentLat, currentLon, t.lat, t.lon) * ROAD_FACTOR;
            double deltaKm = nowRoad - refRoad;
            int adjustedK = t.anchorK
                    + (int) Math.round((deltaKm * WON_PER_KM_DELTA) / 1000.0)
                    + modeDeltaK + presetDeltaK + section.deltaK;
            adjustedK = Math.max(10, adjustedK);
            results.add(new Result(t.name, adjustedK));
        }
        Collections.sort(results, Comparator.comparingInt((Result r) -> r.priceK).thenComparing(r -> r.name));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < results.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(results.get(i).name).append('#').append(results.get(i).priceK);
        }
        return sb.toString();
    }

    private void copyText(String label, String value) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
        Toast.makeText(this, label + " 가격표 복사 완료", Toast.LENGTH_SHORT).show();
    }

    private double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0088;
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1);
        double dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(rounded(CARD, 16));
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button primaryButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.BLACK);
        b.setBackground(rounded(ACCENT, 12));
        return b;
    }

    private Button modeButton(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(3), dp(4), dp(3), dp(4));
        return b;
    }

    private LinearLayout.LayoutParams topMargin(int dpVal) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(dpVal);
        return p;
    }

    private LinearLayout.LayoutParams weightLp(float weight) {
        return new LinearLayout.LayoutParams(0, dp(56), weight);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static Target t(String name, double lat, double lon, int anchorK) {
        return new Target(name, lat, lon, anchorK);
    }

    static class Target {
        String name; double lat, lon; int anchorK;
        Target(String name, double lat, double lon, int anchorK) {
            this.name = name; this.lat = lat; this.lon = lon; this.anchorK = anchorK;
        }
    }

    static class Result {
        String name; int priceK;
        Result(String name, int priceK) { this.name = name; this.priceK = priceK; }
    }

    static class Section {
        String title; EditText edit; Target[] targets; int deltaK; TextView deltaView;
        Section(String title, EditText edit, Target[] targets, int deltaK, TextView deltaView) {
            this.title = title; this.edit = edit; this.targets = targets; this.deltaK = deltaK; this.deltaView = deltaView;
        }
    }
}
