package com.sangmin.driversplit;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.util.DisplayMetrics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WindowController {
    public static final String LOGI = "com.logisoft.Logi4";
    public static final String KAKAO = "com.kakao.wheel.driver";
    public static final String TMAP = "com.tmapmobility.drive.driver";

    private final Context context;
    private final StringBuilder log = new StringBuilder();

    public WindowController(Context context) {
        this.context = context.getApplicationContext();
    }

    public String getLog() { return log.toString(); }
    public void clearLog() { log.setLength(0); }

    private void add(String s) {
        log.append(s).append('\n');
    }

    public boolean hasRoot() {
        RootShell.Result r = RootShell.run("id");
        add("ROOT: code=" + r.code + " / " + r.output);
        return r.ok() && r.output.contains("uid=0");
    }

    public boolean isInstalled(String pkg) {
        try {
            context.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String componentFor(String pkg) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null || i.getComponent() == null) return null;
            ComponentName c = i.getComponent();
            return c.flattenToShortString();
        } catch (Exception e) {
            return null;
        }
    }

    public boolean prepareFreeform() {
        RootShell.Result r1 = RootShell.run("settings put global enable_freeform_support 1");
        RootShell.Result r2 = RootShell.run("settings put global force_resizable_activities 1");
        RootShell.Result r3 = RootShell.run("settings put secure force_resizable_activities 1");
        add("freeform global: " + r1.code + " " + r1.output);
        add("force-resizable global: " + r2.code + " " + r2.output);
        add("force-resizable secure: " + r3.code + " " + r3.output);
        return r1.ok() || r2.ok() || r3.ok();
    }

    public boolean launchAndArrange(boolean onePlusTwo) {
        clearLog();
        if (!hasRoot()) {
            add("ROOT 권한이 없어 중단.");
            return false;
        }
        prepareFreeform();

        int[] size = physicalSize();
        int w = size[0];
        int h = size[1];
        add("screen=" + w + "x" + h);

        Rect[] rects = onePlusTwo ? layoutOnePlusTwo(w, h) : layoutThreeRows(w, h);
        String[] pkgs = {LOGI, KAKAO, TMAP};
        String[] names = {"로지D1", "카카오T 대리", "티맵 대리"};

        boolean all = true;
        for (int i = 0; i < pkgs.length; i++) {
            String pkg = pkgs[i];
            if (!isInstalled(pkg)) {
                add(names[i] + ": 설치 안 됨 - " + pkg);
                all = false;
                continue;
            }
            String comp = componentFor(pkg);
            if (comp == null) {
                add(names[i] + ": 실행 Activity를 찾지 못함");
                all = false;
                continue;
            }
            add(names[i] + " component=" + comp);
            String start = "am start -W --windowingMode 5 -n " + shellQuote(comp) + " -f 0x10000000";
            RootShell.Result sr = RootShell.run(start);
            add("launch " + names[i] + ": " + sr.code + " " + oneLine(sr.output));
            sleep(900);

            int taskId = findTaskId(pkg);
            add(names[i] + " taskId=" + taskId);
            if (taskId <= 0) {
                all = false;
                continue;
            }
            RootShell.run("am task resizeable " + taskId + " 2");
            Rect b = rects[i];
            RootShell.Result rr = RootShell.run(String.format(Locale.US,
                    "am task resize %d %d %d %d %d", taskId, b.left, b.top, b.right, b.bottom));
            add("resize " + names[i] + " " + b.toShortString() + ": " + rr.code + " " + oneLine(rr.output));
            if (!rr.ok()) all = false;
            sleep(500);
        }
        return all;
    }

    public boolean rearrangeExisting(boolean onePlusTwo) {
        clearLog();
        if (!hasRoot()) return false;
        int[] size = physicalSize();
        Rect[] rects = onePlusTwo ? layoutOnePlusTwo(size[0], size[1]) : layoutThreeRows(size[0], size[1]);
        String[] pkgs = {LOGI, KAKAO, TMAP};
        boolean all = true;
        for (int i = 0; i < pkgs.length; i++) {
            int taskId = findTaskId(pkgs[i]);
            add(pkgs[i] + " taskId=" + taskId);
            if (taskId <= 0) { all = false; continue; }
            RootShell.run("am task resizeable " + taskId + " 2");
            Rect b = rects[i];
            RootShell.Result rr = RootShell.run("am task resize " + taskId + " " + b.left + " " + b.top + " " + b.right + " " + b.bottom);
            add("resize=" + rr.code + " " + oneLine(rr.output));
            if (!rr.ok()) all = false;
        }
        return all;
    }

    public String diagnostics() {
        clearLog();
        hasRoot();
        add("Logi installed=" + isInstalled(LOGI) + " comp=" + componentFor(LOGI));
        add("Kakao installed=" + isInstalled(KAKAO) + " comp=" + componentFor(KAKAO));
        add("TMAP installed=" + isInstalled(TMAP) + " comp=" + componentFor(TMAP));
        RootShell.Result a = RootShell.run("settings get global enable_freeform_support; settings get global force_resizable_activities; settings get secure force_resizable_activities");
        add("settings:\n" + a.output);
        RootShell.Result b = RootShell.run("wm size; wm density");
        add("wm:\n" + b.output);
        for (String pkg : new String[]{LOGI, KAKAO, TMAP}) add(pkg + " task=" + findTaskId(pkg));
        return getLog();
    }

    private int[] physicalSize() {
        RootShell.Result r = RootShell.run("wm size");
        Matcher m = Pattern.compile("(?:Physical size|Override size):\\s*(\\d+)x(\\d+)").matcher(r.output);
        int w = 0, h = 0;
        while (m.find()) {
            w = Integer.parseInt(m.group(1));
            h = Integer.parseInt(m.group(2));
        }
        if (w <= 0 || h <= 0) {
            DisplayMetrics dm = context.getResources().getDisplayMetrics();
            w = dm.widthPixels;
            h = dm.heightPixels;
        }
        return new int[]{w, h};
    }

    private Rect[] layoutThreeRows(int w, int h) {
        int side = Math.max(6, w / 160);
        int top = Math.max(40, h / 70);
        int bottom = Math.max(70, h / 35);
        int gap = Math.max(8, h / 260);
        int usable = h - top - bottom - gap * 2;
        int row = usable / 3;
        Rect r1 = new Rect(side, top, w - side, top + row);
        Rect r2 = new Rect(side, r1.bottom + gap, w - side, r1.bottom + gap + row);
        Rect r3 = new Rect(side, r2.bottom + gap, w - side, h - bottom);
        return new Rect[]{r1, r2, r3};
    }

    private Rect[] layoutOnePlusTwo(int w, int h) {
        int side = Math.max(6, w / 160);
        int top = Math.max(40, h / 70);
        int bottom = Math.max(70, h / 35);
        int gap = Math.max(8, h / 260);
        int midY = top + (int)((h - top - bottom) * 0.52f);
        int midX = w / 2;
        Rect r1 = new Rect(side, top, w - side, midY - gap);
        Rect r2 = new Rect(side, midY, midX - gap / 2, h - bottom);
        Rect r3 = new Rect(midX + gap / 2, midY, w - side, h - bottom);
        return new Rect[]{r1, r2, r3};
    }

    private int findTaskId(String pkg) {
        RootShell.Result r = RootShell.run("dumpsys activity recents");
        String text = r.output;
        if (text == null || text.isEmpty()) return -1;

        String[] lines = text.split("\\n");
        List<String> candidates = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].contains(pkg)) {
                StringBuilder c = new StringBuilder(lines[i]);
                if (i > 0) c.insert(0, lines[i - 1] + " ");
                if (i > 1) c.insert(0, lines[i - 2] + " ");
                candidates.add(c.toString());
            }
        }
        Pattern[] patterns = new Pattern[]{
                Pattern.compile("#(\\d+)"),
                Pattern.compile("taskId=(\\d+)"),
                Pattern.compile("id=(\\d+)")
        };
        for (String c : candidates) {
            for (Pattern p : patterns) {
                Matcher m = p.matcher(c);
                if (m.find()) {
                    try { return Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
                }
            }
        }
        return -1;
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static String oneLine(String s) {
        if (s == null) return "";
        return s.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
