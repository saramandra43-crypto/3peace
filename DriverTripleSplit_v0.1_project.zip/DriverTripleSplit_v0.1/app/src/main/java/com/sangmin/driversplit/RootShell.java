package com.sangmin.driversplit;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

public final class RootShell {
    private RootShell() {}

    public static Result run(String command) {
        StringBuilder out = new StringBuilder();
        int code = -1;
        try {
            Process p = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) out.append(line).append('\n');
            }
            if (!p.waitFor(15, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return new Result(-2, out + "TIMEOUT");
            }
            code = p.exitValue();
        } catch (Exception e) {
            out.append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());
        }
        return new Result(code, out.toString().trim());
    }

    public static final class Result {
        public final int code;
        public final String output;
        public Result(int code, String output) {
            this.code = code;
            this.output = output == null ? "" : output;
        }
        public boolean ok() { return code == 0; }
    }
}
