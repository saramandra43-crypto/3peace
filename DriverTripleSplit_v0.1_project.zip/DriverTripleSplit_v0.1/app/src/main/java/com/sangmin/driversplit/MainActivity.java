package com.sangmin.driversplit;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private TextView rootStatus;
    private TextView appStatus;
    private TextView logText;
    private RadioButton layoutOnePlusTwo;
    private Button startButton;
    private Button relayoutButton;
    private Button checkButton;
    private Button copyLogButton;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        controller = new WindowController(this);
        rootStatus = findViewById(R.id.rootStatus);
        appStatus = findViewById(R.id.appStatus);
        logText = findViewById(R.id.logText);
        layoutOnePlusTwo = findViewById(R.id.layoutOnePlusTwo);
        startButton = findViewById(R.id.startButton);
        relayoutButton = findViewById(R.id.relayoutButton);
        checkButton = findViewById(R.id.checkButton);
        copyLogButton = findViewById(R.id.copyLogButton);

        startButton.setOnClickListener(v -> runLaunch());
        relayoutButton.setOnClickListener(v -> runRelayout());
        checkButton.setOnClickListener(v -> refreshStatus());
        copyLogButton.setOnClickListener(v -> copyLog());

        refreshStatus();
    }

    private void setBusy(boolean busy) {
        startButton.setEnabled(!busy);
        relayoutButton.setEnabled(!busy);
        checkButton.setEnabled(!busy);
        if (busy) logText.setText("작업 중... 첫 ROOT 요청이면 Magisk에서 허용해줘.");
    }

    private boolean useOnePlusTwo() {
        return layoutOnePlusTwo.isChecked();
    }

    private void runLaunch() {
        final boolean layout = useOnePlusTwo();
        setBusy(true);
        worker.execute(() -> {
            boolean ok = controller.launchAndArrange(layout);
            String log = controller.getLog();
            main.post(() -> {
                setBusy(false);
                logText.setText(log);
                Toast.makeText(this, ok ? "3분할 배치 완료" : "일부 배치 실패 · 진단 로그 확인", Toast.LENGTH_LONG).show();
                refreshStatusQuick();
            });
        });
    }

    private void runRelayout() {
        final boolean layout = useOnePlusTwo();
        setBusy(true);
        worker.execute(() -> {
            boolean ok = controller.rearrangeExisting(layout);
            String log = controller.getLog();
            main.post(() -> {
                setBusy(false);
                logText.setText(log);
                Toast.makeText(this, ok ? "다시 배치 완료" : "열려 있지 않은 앱이 있거나 배치 실패", Toast.LENGTH_LONG).show();
            });
        });
    }

    private void refreshStatus() {
        rootStatus.setText("ROOT 확인 중...");
        appStatus.setText("앱 설치 상태 확인 중...");
        worker.execute(() -> {
            String diag = controller.diagnostics();
            boolean root = diag.contains("uid=0");
            boolean l = controller.isInstalled(WindowController.LOGI);
            boolean k = controller.isInstalled(WindowController.KAKAO);
            boolean t = controller.isInstalled(WindowController.TMAP);
            main.post(() -> {
                rootStatus.setText(root ? "✓ ROOT 사용 가능" : "✕ ROOT 권한 없음 / 거부됨");
                rootStatus.setTextColor(Color.parseColor(root ? "#5ED08B" : "#FF7373"));
                appStatus.setText((l ? "✓" : "✕") + " 로지D1   " + (k ? "✓" : "✕") + " 카카오   " + (t ? "✓" : "✕") + " 티맵");
                logText.setText(diag);
            });
        });
    }

    private void refreshStatusQuick() {
        boolean l = controller.isInstalled(WindowController.LOGI);
        boolean k = controller.isInstalled(WindowController.KAKAO);
        boolean t = controller.isInstalled(WindowController.TMAP);
        appStatus.setText((l ? "✓" : "✕") + " 로지D1   " + (k ? "✓" : "✕") + " 카카오   " + (t ? "✓" : "✕") + " 티맵");
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("대리3분할 진단", logText.getText()));
        Toast.makeText(this, "진단 로그 복사됨", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
