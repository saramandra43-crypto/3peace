# 대리 3분할 v0.1.0

개인용 ROOT 멀티윈도우 실험 앱.

대상 앱:
- 로지D1: `com.logisoft.Logi4`
- 카카오 T 대리 기사: `com.kakao.wheel.driver`
- 티맵 대리 기사님: `com.tmapmobility.drive.driver`

## 동작
- ROOT의 Android ActivityManager shell 명령으로 세 앱을 freeform windowing mode로 실행
- 각 앱의 taskId를 찾아 `am task resize`로 지정 영역에 배치
- 기본 레이아웃: 세로 3단 (로지 / 카카오 / 티맵)
- 보조 레이아웃: 상단 로지 + 하단 카카오/티맵
- 자동배차/자동클릭/패킷 접근 없음

## 첫 테스트
1. 세 대상 앱 설치/로그인 상태 확인
2. 대리 3분할 실행
3. Magisk ROOT 팝업 허용
4. `3개 앱 동시에 분할 실행` 터치
5. 실패하면 `진단 로그 복사` 후 로그로 기기별 튜닝

## 주의
삼성/Android 버전에 따라 freeform/task resize 동작이 달라질 수 있어 0.1은 실제 기기 튜닝용 초안이다.
